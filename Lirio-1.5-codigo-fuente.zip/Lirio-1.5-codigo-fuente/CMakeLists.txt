cmake_minimum_required(VERSION 3.22)
if(APPLE)
    set(CMAKE_OSX_ARCHITECTURES "arm64;x86_64" CACHE STRING "Mac universal (Intel + Apple Silicon)")
    set(CMAKE_OSX_DEPLOYMENT_TARGET "10.13" CACHE STRING "macOS minimo")
endif()
project(Lirio VERSION 1.5.0)
set(CMAKE_CXX_STANDARD 17)
set(JUCE_DIR "/tmp/JUCE7" CACHE PATH "Ruta a JUCE 7")
add_subdirectory(${JUCE_DIR} juce)
if(APPLE)
    set(LIRIO_FORMATS VST3 AU Standalone)
else()
    set(LIRIO_FORMATS VST3 Standalone)
endif()

juce_add_binary_data(LirioData SOURCES fonts/Inter-SemiBold.otf fonts/InterDisplay-Black.otf fonts/DejaVuSansMono-Bold.ttf)

juce_add_plugin(Lirio
    COMPANY_NAME "Saavedrismo"
    COMPANY_WEBSITE "https://nicosaavedra.tech"
    BUNDLE_ID "tech.nicosaavedra.lirio"
    IS_SYNTH TRUE
    NEEDS_MIDI_INPUT TRUE
    NEEDS_MIDI_OUTPUT TRUE
    EDITOR_WANTS_KEYBOARD_FOCUS TRUE
    PLUGIN_MANUFACTURER_CODE Svdr
    PLUGIN_CODE Lri1
    FORMATS ${LIRIO_FORMATS}
    VST3_CATEGORIES Instrument Synth
    AU_MAIN_TYPE kAudioUnitType_MusicDevice
    PRODUCT_NAME "Lirio"
    ICON_BIG "${CMAKE_CURRENT_SOURCE_DIR}/icon.png"
    COPY_PLUGIN_AFTER_BUILD FALSE
    VST3_AUTO_MANIFEST FALSE)

target_sources(Lirio PRIVATE Source/PluginProcessor.cpp Source/PluginEditor.cpp)
target_compile_definitions(Lirio PUBLIC
    JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 JUCE_VST3_CAN_REPLACE_VST2=0
    JUCE_DISPLAY_SPLASH_SCREEN=0 JUCE_REPORT_APP_USAGE=0
    JUCE_USE_FLAC=0 JUCE_USE_OGGVORBIS=0 JUCE_USE_MP3AUDIOFORMAT=0 JUCE_USE_LAME_AUDIO_FORMAT=0 JUCE_USE_WINDOWS_MEDIA_FORMAT=0)
target_link_libraries(Lirio PRIVATE LirioData juce::juce_audio_utils juce::juce_audio_devices
    PUBLIC juce::juce_recommended_config_flags juce::juce_recommended_lto_flags)
if(MINGW)
    target_link_options(Lirio_VST3 PRIVATE -static -static-libgcc -static-libstdc++)
    target_link_options(Lirio_Standalone PRIVATE -static -static-libgcc -static-libstdc++ -mwindows)
endif()

# ---- herramienta de prueba (solo Linux): dibuja la interfaz a PNG sin abrir ventanas ----
if(NOT MINGW AND LIRIO_SNAP)
    juce_add_console_app(LirioSnap PRODUCT_NAME "LirioSnap")
    target_sources(LirioSnap PRIVATE tests/snap.cpp Source/PluginProcessor.cpp Source/PluginEditor.cpp)
    target_include_directories(LirioSnap PRIVATE Source)
    target_compile_definitions(LirioSnap PRIVATE JUCE_DISPLAY_SPLASH_SCREEN=0 JUCE_MODAL_LOOPS_PERMITTED=1 JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0)
    target_link_libraries(LirioSnap PRIVATE LirioData juce::juce_audio_utils juce::juce_audio_processors juce::juce_gui_extra PUBLIC juce::juce_recommended_config_flags)
endif()

# aplicación independiente propia (abre los teclados MIDI automáticamente)
target_sources(Lirio_Standalone PRIVATE Source/StandaloneApp.cpp)
target_compile_definitions(Lirio_Standalone PRIVATE JUCE_USE_CUSTOM_PLUGIN_STANDALONE_APP=1)
