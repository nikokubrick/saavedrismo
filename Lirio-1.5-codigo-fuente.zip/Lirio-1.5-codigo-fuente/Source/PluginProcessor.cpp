#include "PluginProcessor.h"
#include "PluginEditor.h"

using APVTS = juce::AudioProcessorValueTreeState;
static juce::String U (const char* s) { return juce::String::fromUTF8 (s); }
static juce::StringArray SA (std::initializer_list<const char*> l) { juce::StringArray a; for (auto* s : l) a.add (U (s)); return a; }

const char* const LirioProcessor::chordIds[9] = { "cMaj", "cMin", "cDim", "cSus2", "cSus4", "c6", "c7", "cMaj7", "add9" };
const juce::StringArray LirioProcessor::chordNames   = SA ({ "Mayor", "Menor", "Dim", "Sus2", "Sus4", "6", "7", "Maj7", "9" });
const juce::StringArray LirioProcessor::rhythmNames  = SA ({ "Negras", "Corcheas", "Charleston", "Tresillo", "Contratiempo", "Empuje pop", "Bossa", "Funk", "Galope", "Síncopa", "Balada" });
const juce::StringArray LirioProcessor::bassSoundNames = SA ({ "Redondo", "Sierra", "Cuadrado", "Sub", "FM", "Ácido" });
const juce::StringArray LirioProcessor::perfNames    = SA ({ "Acorde", "Strum", "Slop", "Arpegio", "Arpa", "Patrón" });
const juce::StringArray LirioProcessor::engineNames  = SA ({ "Analógico", "FM", "Lengüeta" });
const juce::StringArray LirioProcessor::keyNames     = SA ({ "Do", "Do#", "Re", "Re#", "Mi", "Fa", "Fa#", "Sol", "Sol#", "La", "La#", "Si" });
const juce::StringArray LirioProcessor::rateNames    = SA ({ "1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32" });
const juce::StringArray LirioProcessor::patternNames = SA ({ "Arriba", "Abajo", "Ida y vuelta", "Azar" });
const juce::StringArray LirioProcessor::drumPatternNames = SA ({ "Groove psicodélico", "Latido", "Motorik", "Lento con toms", "Electropop", "Breakbeat", "Tribal de toms", "Bossa", "One drop", "Hip hop lento", "Disco", "Funk", "Rock", "Shuffle", "Dembow", "Cumbia", "Samba", "Trip hop", "Milonga", "Vacío" });
const juce::StringArray LirioProcessor::laneNames = SA ({ "BOMBO", "HI-HAT", "REDOBLANTE", "TOM 1", "TOM 2", "TOM 3" });
const juce::StringArray LirioProcessor::delayNames   = SA ({ "1/4", "1/8.", "1/8", "1/16", "1/4T" });

APVTS::ParameterLayout LirioProcessor::createLayout()
{
    using namespace juce;
    std::vector<std::unique_ptr<RangedAudioParameter>> p;
    auto choice = [&] (const char* id, const char* name, const StringArray& opts, int def) { p.push_back (std::make_unique<AudioParameterChoice> (ParameterID { id, 1 }, U (name), opts, def)); };
    auto toggle = [&] (const char* id, const char* name, bool def) { p.push_back (std::make_unique<AudioParameterBool> (ParameterID { id, 1 }, U (name), def)); };
    auto integer = [&] (const char* id, const char* name, int lo, int hi, int def) { p.push_back (std::make_unique<AudioParameterInt> (ParameterID { id, 1 }, U (name), lo, hi, def)); };
    // formatos de valor: 0 porcentaje, 1 ms, 2 segundos, 3 BPM, 4 sin unidad
    auto fmtFn = [] (int k) { return [k] (float v, int) -> String {
        switch (k) { case 0: return String (roundToInt (v * 100.f)) + "%"; case 1: return String (roundToInt (v)) + " ms";
                     case 2: return v < 1.f ? String (roundToInt (v * 1000.f)) + " ms" : String (v, 2) + " s"; case 3: return String (roundToInt (v)) + " BPM";
                     default: return String (v, 2); } }; };
    auto real = [&] (const char* id, const char* name, float lo, float hi, float def, float skewMid = -1.f, int fmt = 0)
    {
        NormalisableRange<float> r (lo, hi);
        if (skewMid > 0) r.setSkewForCentre (skewMid);
        p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { id, 1 }, U (name), r, def, AudioParameterFloatAttributes().withStringFromValueFunction (fmtFn (fmt))));
    };

    choice ("mode", "Modo", StringArray { "Acordes", "Notas" }, 0);
    for (int k = 0; k < 9; ++k) toggle (chordIds[k], (juce::String ("Acorde ") + chordNames[k]).toRawUTF8(), false);
    toggle ("voiceLead", "Voice leading", false);
    choice ("complexity", "Complejidad", StringArray { "Simple", "Avanzado", "Libre" }, 1);
    toggle ("hold", "Mantener", false);
    toggle ("keyswitch", "Teclas de cambio", true);
    toggle ("followOct", "Octava de la tecla", true);
    choice ("key", "Tonalidad", keyNames, 9);
    choice ("scale", "Escala", StringArray { "Mayor", "Menor" }, 1);
    integer ("voicing", "Voicing", -4, 4, 0);
    integer ("octave", "Registro", -2, 2, 0);
    choice ("perf", "Interpretación", perfNames, 0);
    choice ("rhythm", "Patrón rítmico", rhythmNames, 0);
    real ("strum", "Velocidad strum", 5.f, 200.f, 40.f, 50.f, 1);
    real ("slop", "Humano", 0.f, 1.f, 0.5f);
    choice ("arpRate", "Ritmo arpegio", rateNames, 3);
    choice ("arpPattern", "Patrón arpegio", patternNames, 0);
    integer ("arpOct", "Octavas arpegio", 1, 4, 1);
    real ("arpGate", "Duración arpegio", 0.1f, 1.f, 0.6f);
    real ("tempo", "Tempo (programa independiente)", 40.f, 220.f, 100.f, -1.f, 3);
    choice ("engine", "Motor", engineNames, 0);
    real ("bright", "Brillo", 0.f, 1.f, 0.6f);
    real ("tone2", "Tono / Relación / Mecánica", 0.f, 1.f, 0.25f);
    real ("character", "Carácter", 0.f, 1.f, 0.5f);
    real ("movement", "Movimiento", 0.f, 1.f, 0.3f);
    real ("attack", "Ataque", 0.001f, 5.f, 0.005f, 0.3f, 2);
    real ("decay", "Caída", 0.05f, 10.f, 1.2f, 1.5f, 2);
    real ("sustain", "Sostén", 0.f, 1.f, 0.6f);
    real ("release", "Suelta", 0.01f, 10.f, 0.5f, 1.f, 2);
    real ("velsens", "Sensibilidad", 0.f, 1.f, 0.7f);
    toggle ("bassOn", "Bajo", false);
    real ("bassLevel", "Nivel bajo", 0.f, 1.f, 0.6f);
    choice ("bassOct", "Octava bajo", StringArray { "-1", "-2" }, 0);
    real ("bassTone", "Tono bajo", 0.f, 1.f, 0.4f);
    choice ("bassMode", "Modo bajo", StringArray { "Sigue", "Solo" }, 0);
    choice ("bassSound", "Sonido bajo", bassSoundNames, 0);
    real ("chorus", "Chorus", 0.f, 1.f, 0.4f);
    real ("delayMix", "Delay", 0.f, 1.f, 0.15f);
    real ("delayFb", "Repeticiones", 0.f, 0.92f, 0.35f);
    choice ("delayTime", "Tiempo delay", delayNames, 1);
    real ("reverbMix", "Reverb", 0.f, 1.f, 0.25f);
    real ("reverbSize", "Tamaño reverb", 0.f, 1.f, 0.7f);
    real ("volume", "Volumen", 0.f, 1.f, 0.78f);
    real ("drive", "Saturación", 0.f, 1.f, 0.f);
    real ("phaser", "Faser", 0.f, 1.f, 0.f);
    real ("flanger", "Flanger", 0.f, 1.f, 0.f);
    real ("cutoff", "Filtro", 0.f, 1.f, 1.f);
    choice ("loopBars", "Compases del looper", StringArray { "1", "2", "4", "8" }, 1);
    toggle ("loopQuant", "Cuantizar looper", true);
    toggle ("lockPerf", "Trabar interpretación", false);
    toggle ("lockFx", "Trabar efectos", false);
    toggle ("midiOut", "Salida MIDI", true);
    toggle ("drumsOn", "Ritmo encendido", false);
    toggle ("drumSync", "Ritmo sigue al DAW", true);
    choice ("drumPattern", "Patrón de ritmo", drumPatternNames, 0);
    real ("drumVol", "Volumen ritmo", 0.f, 1.f, 0.7f);
    real ("swing", "Swing", 0.f, 0.6f, 0.12f);
    real ("drumComp", "Compresión ritmo", 0.f, 1.f, 0.65f);
    real ("drumPhase", "Fase ritmo", 0.f, 1.f, 0.35f);
    real ("drumTone", "Tono ritmo", 0.f, 1.f, 0.55f);
    real ("drumVerb", "Reverb ritmo", 0.f, 1.f, 0.f);
    real ("drumDrive", "Saturador ritmo", 0.f, 1.f, 0.f);
    return { p.begin(), p.end() };
}

// ---------------- presets de fábrica ----------------
struct Preset { const char* name; std::vector<std::pair<const char*, float>> v; };
// lo que no dice un preset vuelve a estos valores (así los presets nuevos no arrastran efectos del anterior)
static const std::vector<std::pair<const char*, float>>& presetBase()
{
    static const std::vector<std::pair<const char*, float>> B {
        { "engine", 0 }, { "bright", .55f }, { "tone2", .25f }, { "character", .4f }, { "movement", .3f },
        { "attack", .005f }, { "decay", 1.2f }, { "sustain", .6f }, { "release", .5f },
        { "perf", 0 }, { "strum", 40.f }, { "slop", .5f }, { "arpRate", 3 }, { "arpPattern", 0 }, { "arpOct", 1 }, { "arpGate", .6f }, { "rhythm", 0 },
        { "bassOn", 0 }, { "bassLevel", .6f }, { "bassTone", .4f }, { "bassMode", 0 }, { "bassSound", 0 },
        { "chorus", .4f }, { "delayMix", .12f }, { "delayFb", .35f }, { "delayTime", 1 }, { "reverbMix", .25f }, { "reverbSize", .7f },
        { "drive", 0 }, { "phaser", 0 }, { "flanger", 0 }, { "cutoff", 1 }, { "volume", .78f } };
    return B;
}
static const std::vector<Preset>& presets()
{
    static const std::vector<Preset> P {
        { "Juno nublado",     { { "engine", 0 }, { "bright", .55f }, { "tone2", .2f }, { "character", .35f }, { "movement", .55f }, { "attack", .02f }, { "decay", 1.2f }, { "sustain", .7f }, { "release", .8f }, { "chorus", .75f }, { "reverbMix", .35f }, { "reverbSize", .75f }, { "delayMix", .12f }, { "perf", 0 }, { "bassOn", 0 }, { "volume", .78f } } },
        { "Lengüeta soul",    { { "engine", 2 }, { "bright", .62f }, { "tone2", .45f }, { "character", .55f }, { "movement", .35f }, { "attack", .002f }, { "decay", 2.5f }, { "sustain", .5f }, { "release", .25f }, { "chorus", .1f }, { "reverbMix", .2f }, { "delayMix", .0f }, { "perf", 0 }, { "bassOn", 0 }, { "volume", .78f } } },
        { "Campana FM",       { { "engine", 1 }, { "bright", .7f }, { "tone2", .55f }, { "character", .45f }, { "movement", .15f }, { "attack", .002f }, { "decay", 3.f }, { "sustain", .2f }, { "release", 1.2f }, { "chorus", .2f }, { "reverbMix", .4f }, { "reverbSize", .8f }, { "delayMix", .25f }, { "perf", 0 }, { "bassOn", 0 }, { "volume", .78f } } },
        { "Piano FM",         { { "engine", 1 }, { "bright", .5f }, { "tone2", .2f }, { "character", .3f }, { "movement", .25f }, { "attack", .002f }, { "decay", 2.2f }, { "sustain", .35f }, { "release", .4f }, { "chorus", .45f }, { "reverbMix", .25f }, { "delayMix", .1f }, { "perf", 0 }, { "bassOn", 0 }, { "volume", .78f } } },
        { "Strum de cristal", { { "engine", 1 }, { "bright", .75f }, { "tone2", .6f }, { "character", .4f }, { "movement", .2f }, { "attack", .002f }, { "decay", 3.5f }, { "sustain", .15f }, { "release", 1.5f }, { "chorus", .3f }, { "reverbMix", .45f }, { "reverbSize", .85f }, { "perf", 1 }, { "strum", 60.f }, { "bassOn", 0 }, { "volume", .78f } } },
        { "Arpegio 80s",      { { "engine", 0 }, { "bright", .45f }, { "tone2", .45f }, { "character", .6f }, { "movement", .3f }, { "attack", .002f }, { "decay", .35f }, { "sustain", .3f }, { "release", .2f }, { "chorus", .5f }, { "reverbMix", .25f }, { "delayMix", .3f }, { "delayFb", .45f }, { "perf", 3 }, { "arpRate", 3 }, { "arpPattern", 2 }, { "arpOct", 2 }, { "arpGate", .5f }, { "bassOn", 1 }, { "volume", .78f } } },
        { "Arpa nocturna",    { { "engine", 2 }, { "bright", .55f }, { "tone2", .2f }, { "character", .3f }, { "movement", .4f }, { "attack", .002f }, { "decay", 3.f }, { "sustain", .2f }, { "release", 1.f }, { "chorus", .35f }, { "reverbMix", .55f }, { "reverbSize", .9f }, { "delayMix", .2f }, { "perf", 4 }, { "strum", 50.f }, { "bassOn", 0 }, { "volume", .68f } } },
        { "Bajo + acordes",   { { "engine", 0 }, { "bright", .5f }, { "tone2", .3f }, { "character", .4f }, { "movement", .4f }, { "attack", .01f }, { "decay", 1.f }, { "sustain", .6f }, { "release", .4f }, { "chorus", .55f }, { "reverbMix", .2f }, { "perf", 0 }, { "bassOn", 1 }, { "bassLevel", .7f }, { "bassTone", .5f }, { "volume", .78f } } },
        { "Slop lo-fi",       { { "engine", 2 }, { "bright", .4f }, { "tone2", .6f }, { "character", .7f }, { "movement", .5f }, { "attack", .003f }, { "decay", 2.f }, { "sustain", .3f }, { "release", .3f }, { "chorus", .45f }, { "reverbMix", .3f }, { "delayMix", .15f }, { "perf", 2 }, { "slop", .75f }, { "bassOn", 0 }, { "volume", .78f } } },
        // ---- nuevos en 1.5 ----
        { "Bossa de living",  { { "engine", 2 }, { "bright", .5f }, { "tone2", .3f }, { "character", .45f }, { "movement", .3f }, { "attack", .002f }, { "decay", 1.4f }, { "sustain", .35f }, { "release", .25f }, { "chorus", .3f }, { "reverbMix", .22f }, { "perf", 5 }, { "rhythm", 6 }, { "bassOn", 1 }, { "bassSound", 0 }, { "bassLevel", .55f } } },
        { "Funk de pasillo",  { { "engine", 0 }, { "bright", .62f }, { "tone2", .5f }, { "character", .7f }, { "movement", .2f }, { "attack", .002f }, { "decay", .3f }, { "sustain", .25f }, { "release", .12f }, { "chorus", .2f }, { "reverbMix", .12f }, { "phaser", .35f }, { "perf", 5 }, { "rhythm", 7 }, { "bassOn", 1 }, { "bassSound", 2 }, { "bassTone", .55f } } },
        { "Galope western",   { { "engine", 1 }, { "bright", .55f }, { "tone2", .3f }, { "character", .35f }, { "movement", .2f }, { "attack", .002f }, { "decay", .8f }, { "sustain", .2f }, { "release", .2f }, { "delayMix", .22f }, { "delayTime", 2 }, { "reverbMix", .35f }, { "perf", 5 }, { "rhythm", 8 }, { "bassOn", 1 }, { "bassSound", 3 } } },
        { "Reggae de patio",  { { "engine", 2 }, { "bright", .55f }, { "tone2", .5f }, { "character", .5f }, { "attack", .002f }, { "decay", .4f }, { "sustain", .1f }, { "release", .1f }, { "chorus", .15f }, { "delayMix", .28f }, { "delayFb", .5f }, { "delayTime", 1 }, { "reverbMix", .2f }, { "perf", 5 }, { "rhythm", 4 }, { "bassOn", 1 }, { "bassSound", 3 }, { "bassLevel", .75f } } },
        { "Pad de faser",     { { "engine", 0 }, { "bright", .4f }, { "tone2", .2f }, { "character", .2f }, { "movement", .6f }, { "attack", .9f }, { "decay", 2.f }, { "sustain", .85f }, { "release", 2.5f }, { "chorus", .6f }, { "phaser", .7f }, { "reverbMix", .5f }, { "reverbSize", .9f } } },
        { "Flanger espacial", { { "engine", 0 }, { "bright", .6f }, { "tone2", .35f }, { "character", .3f }, { "movement", .5f }, { "attack", .3f }, { "decay", 2.f }, { "sustain", .7f }, { "release", 2.f }, { "chorus", .2f }, { "flanger", .7f }, { "delayMix", .25f }, { "reverbMix", .45f }, { "reverbSize", .85f } } },
        { "Órgano roto",      { { "engine", 1 }, { "bright", .45f }, { "tone2", .15f }, { "character", .25f }, { "movement", .45f }, { "attack", .01f }, { "decay", 1.f }, { "sustain", .9f }, { "release", .2f }, { "chorus", .5f }, { "drive", .55f }, { "reverbMix", .2f }, { "volume", .7f } } },
        { "Radio de cocina",  { { "engine", 2 }, { "bright", .5f }, { "tone2", .55f }, { "character", .6f }, { "movement", .4f }, { "attack", .002f }, { "decay", 1.8f }, { "sustain", .3f }, { "release", .3f }, { "chorus", .4f }, { "drive", .35f }, { "cutoff", .55f }, { "reverbMix", .15f }, { "perf", 2 }, { "slop", .6f } } },
        { "Ácido de noche",   { { "engine", 0 }, { "bright", .35f }, { "tone2", .5f }, { "character", .5f }, { "movement", .3f }, { "attack", .002f }, { "decay", .5f }, { "sustain", .4f }, { "release", .2f }, { "delayMix", .3f }, { "delayFb", .5f }, { "reverbMix", .2f }, { "perf", 5 }, { "rhythm", 1 }, { "bassOn", 1 }, { "bassSound", 5 }, { "bassTone", .65f }, { "bassLevel", .7f } } },
        { "Charleston",       { { "engine", 2 }, { "bright", .65f }, { "tone2", .4f }, { "character", .6f }, { "attack", .002f }, { "decay", 1.f }, { "sustain", .3f }, { "release", .2f }, { "chorus", .1f }, { "reverbMix", .25f }, { "cutoff", .7f }, { "perf", 5 }, { "rhythm", 2 }, { "bassOn", 1 }, { "bassSound", 4 } } },
        { "Bajo solo FM",     { { "engine", 1 }, { "bassOn", 1 }, { "bassMode", 1 }, { "bassSound", 4 }, { "bassLevel", .85f }, { "bassTone", .5f }, { "chorus", .1f }, { "reverbMix", .1f } } },
        { "Bajo solo sierra", { { "engine", 0 }, { "bassOn", 1 }, { "bassMode", 1 }, { "bassSound", 1 }, { "bassLevel", .85f }, { "bassTone", .6f }, { "chorus", .2f }, { "reverbMix", .1f } } },
        { "Arpa de flanger",  { { "engine", 1 }, { "bright", .7f }, { "tone2", .5f }, { "character", .35f }, { "attack", .002f }, { "decay", 2.5f }, { "sustain", .1f }, { "release", 1.2f }, { "flanger", .45f }, { "reverbMix", .45f }, { "reverbSize", .85f }, { "perf", 4 }, { "strum", 30.f } } },
        { "Arpegio tresillo", { { "engine", 2 }, { "bright", .55f }, { "tone2", .3f }, { "character", .4f }, { "attack", .002f }, { "decay", .9f }, { "sustain", .2f }, { "release", .3f }, { "chorus", .3f }, { "delayMix", .25f }, { "reverbMix", .3f }, { "perf", 3 }, { "arpRate", 4 }, { "arpPattern", 2 }, { "arpOct", 2 }, { "arpGate", .45f } } },
        { "Balada empañada",  { { "engine", 0 }, { "bright", .45f }, { "tone2", .2f }, { "character", .3f }, { "movement", .5f }, { "attack", .05f }, { "decay", 2.f }, { "sustain", .65f }, { "release", 1.2f }, { "chorus", .6f }, { "reverbMix", .4f }, { "reverbSize", .8f }, { "cutoff", .75f }, { "perf", 5 }, { "rhythm", 10 }, { "bassOn", 1 } } },
    };
    return P;
}
const juce::StringArray& LirioProcessor::perfGroup() { static const juce::StringArray g { "perf", "strum", "slop", "arpRate", "arpPattern", "arpOct", "arpGate", "rhythm" }; return g; }
const juce::StringArray& LirioProcessor::fxGroup() { static const juce::StringArray g { "chorus", "delayMix", "delayFb", "delayTime", "reverbMix", "reverbSize", "drive", "phaser", "flanger", "cutoff" }; return g; }
bool LirioProcessor::presetMayChange (const juce::String& id) const
{
    if (apvts.getRawParameterValue ("lockPerf")->load() > .5f && perfGroup().contains (id)) return false;
    if (apvts.getRawParameterValue ("lockFx")->load() > .5f && fxGroup().contains (id)) return false;
    return true;
}
void LirioProcessor::setPresetValue (const juce::String& id, float val)
{
    if (! presetMayChange (id)) return;
    if (auto* prm = apvts.getParameter (id)) prm->setValueNotifyingHost (prm->convertTo0to1 (val));
}
int LirioProcessor::getNumPrograms() { return (int) presets().size(); }
const juce::String LirioProcessor::getProgramName (int i) { return juce::isPositiveAndBelow (i, (int) presets().size()) ? juce::String::fromUTF8 (presets()[(size_t) i].name) : juce::String(); }
void LirioProcessor::setCurrentProgram (int i)
{
    if (! juce::isPositiveAndBelow (i, (int) presets().size())) return;
    currentProgram = i; currentUser = juce::File();
    for (auto& [id, val] : presetBase()) setPresetValue (id, val);
    for (auto& [id, val] : presets()[(size_t) i].v) setPresetValue (id, val);
}

// ---------------- presets propios (Documentos/Lirio/Presets/*.lirio) ----------------
static bool notInPreset (const juce::String& id)
{
    static const juce::StringArray skip { "lockPerf", "lockFx", "midiOut", "loopBars", "loopQuant", "mode", "hold", "keyswitch", "drumsOn", "drumSync", "tempo" };
    if (skip.contains (id)) return true;
    for (auto* c : LirioProcessor::chordIds) if (id == c) return true;
    return false;
}
juce::File LirioProcessor::userPresetFolder() const { return recordFolder().getChildFile ("Presets"); }
juce::Array<juce::File> LirioProcessor::userPresets() const
{
    auto a = userPresetFolder().findChildFiles (juce::File::findFiles, false, "*.lirio");
    std::sort (a.begin(), a.end(), [] (const juce::File& x, const juce::File& y) { return x.getFileNameWithoutExtension().compareIgnoreCase (y.getFileNameWithoutExtension()) < 0; });
    return a;
}
bool LirioProcessor::saveUserPreset (const juce::String& rawName)
{
    const auto name = juce::File::createLegalFileName (rawName.trim());
    if (name.isEmpty()) return false;
    juce::XmlElement x ("LIRIOPRESET"); x.setAttribute ("nombre", rawName.trim());
    for (auto* prm : getParameters())
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (prm))
            if (! notInPreset (rp->paramID)) { auto* e = x.createNewChildElement ("P"); e->setAttribute ("id", rp->paramID); e->setAttribute ("v", rp->convertFrom0to1 (rp->getValue())); }
    juce::String ln; for (int l = 0; l < kLanes; ++l) ln << juce::String::toHexString ((int) lanes[l].load()) << (l < kLanes - 1 ? "," : "");
    x.setAttribute ("lanes", ln);
    userPresetFolder().createDirectory();
    auto f = userPresetFolder().getChildFile (name + ".lirio");
    if (! x.writeTo (f)) return false;
    currentUser = f;
    return true;
}
bool LirioProcessor::loadUserPreset (const juce::File& f)
{
    auto x = juce::XmlDocument::parse (f);
    if (x == nullptr || ! x->hasTagName ("LIRIOPRESET")) return false;
    for (auto& [id, val] : presetBase()) setPresetValue (id, val);
    for (auto* e : x->getChildWithTagNameIterator ("P"))
    {
        const auto id = e->getStringAttribute ("id");
        if (! notInPreset (id)) setPresetValue (id, (float) e->getDoubleAttribute ("v"));
    }
    auto parts = juce::StringArray::fromTokens (x->getStringAttribute ("lanes"), ",", "");
    if (parts.size() == kLanes) for (int l = 0; l < kLanes; ++l) lanes[l].store ((uint16_t) parts[l].getHexValue32());
    currentUser = f;
    return true;
}

// ---------------- exportar el loop a un archivo MIDI ----------------
juce::File LirioProcessor::exportLoopMidi()
{
    if (! exportReady.load() || exportEv.empty() || exportLen == 0) { exportReady.store (false); return {}; }
    const double sr = currentSR > 0 ? currentSR : 48000.0;
    const int tpq = 960;
    auto ticks = [&] (uint32_t pos) { return (double) pos / sr * exportBpm / 60.0 * tpq; };
    juce::MidiMessageSequence seq;
    seq.addEvent (juce::MidiMessage::tempoMetaEvent ((int) (60000000.0 / exportBpm)), 0);
    std::vector<lirio::Chord> sounding (128);
    // el loop se escribe dos veces seguidas, para que se note la vuelta
    for (int rep = 0; rep < 2; ++rep)
    {
        const double base = ticks (exportLen) * rep;
        for (auto& c : sounding) c = lirio::Chord();
        for (auto& e : exportEv)
        {
            const double t = base + ticks (e.pos);
            if (e.on)
            {
                lirio::Params pp = exportParams; pp.voiceLead = false;
                auto c = pp.mode == 0 ? engine.buildChord (e.key, pp, e.mask) : lirio::Chord();
                if (pp.mode != 0) c.add (e.key + 12 * pp.octave);
                for (int k = 0; k < sounding[e.key].n; ++k) seq.addEvent (juce::MidiMessage::noteOff (1, sounding[e.key].v[k]), t);
                for (int k = 0; k < c.n; ++k) seq.addEvent (juce::MidiMessage::noteOn (1, c.v[k], (juce::uint8) e.vel), t);
                sounding[e.key] = c;
            }
            else
            {
                for (int k = 0; k < sounding[e.key].n; ++k) seq.addEvent (juce::MidiMessage::noteOff (1, sounding[e.key].v[k]), t);
                sounding[e.key] = lirio::Chord();
            }
        }
        const double end = base + ticks (exportLen);
        for (auto& c : sounding) for (int k = 0; k < c.n; ++k) seq.addEvent (juce::MidiMessage::noteOff (1, c.v[k]), end - 1);
    }
    seq.updateMatchedPairs();
    juce::MidiFile mf; mf.setTicksPerQuarterNote (tpq); mf.addTrack (seq);
    auto folder = recordFolder(); folder.createDirectory();
    auto file = folder.getNonexistentChildFile ("Lirio-loop-" + juce::Time::getCurrentTime().formatted ("%Y-%m-%d_%H-%M-%S"), ".mid");
    exportReady.store (false);
    juce::FileOutputStream os (file);
    if (! os.openedOk() || ! mf.writeTo (os)) return {};
    return file;
}

// ---------------- patrones de ritmo (bombo, hi-hat, redoblante, tom 1, tom 2, tom 3) ----------------
static uint16_t P (std::initializer_list<int> steps) { uint16_t m = 0; for (int s : steps) m |= (uint16_t) (1u << s); return m; }
void LirioProcessor::loadPattern (int i)
{
    const uint16_t E8 = P ({ 0, 2, 4, 6, 8, 10, 12, 14 }), S16 = 0xFFFF;
    const uint16_t pats[20][6] = {
        { P ({ 0, 7, 8, 10 }), E8, P ({ 4, 12 }), 0, 0, 0 },                                                                  // groove psicodélico
        { P ({ 0, 8 }), E8, P ({ 4, 12 }), 0, 0, 0 },                                                                         // latido
        { P ({ 0, 4, 8, 12 }), S16, P ({ 4, 12 }), 0, 0, 0 },                                                                 // motorik
        { P ({ 0, 10 }), P ({ 0, 4, 8, 12 }), P ({ 8 }), P ({ 12, 13 }), P ({ 14 }), P ({ 15 }) },                            // lento con toms
        { P ({ 0, 4, 8, 12 }), P ({ 2, 6, 10, 14 }), P ({ 4, 12 }), 0, 0, 0 },                                               // electropop
        { P ({ 0, 3, 10 }), E8, P ({ 4, 12, 15 }), 0, 0, 0 },                                                                 // breakbeat
        { P ({ 0, 8 }), P ({ 4, 12 }), 0, P ({ 6, 14 }), P ({ 3, 10, 11 }), P ({ 0, 2, 8 }) },                               // tribal de toms
        { P ({ 0, 3, 8, 11 }), E8, P ({ 0, 3, 6, 10, 13 }), 0, 0, 0 },                                                       // bossa
        { P ({ 8 }), P ({ 2, 6, 10, 14 }), P ({ 8 }), 0, 0, 0 },                                                             // one drop
        { P ({ 0, 7, 10 }), E8, P ({ 4, 12 }), 0, 0, 0 },                                                                     // hip hop lento
        { P ({ 0, 4, 8, 12 }), P ({ 2, 6, 10, 14 }), P ({ 4, 12 }), 0, 0, 0 },                                               // disco
        { P ({ 0, 3, 10 }), S16, P ({ 4, 9, 12 }), 0, 0, 0 },                                                                 // funk
        { P ({ 0, 8, 10 }), E8, P ({ 4, 12 }), 0, 0, 0 },                                                                     // rock
        { P ({ 0, 8 }), P ({ 0, 3, 4, 7, 8, 11, 12, 15 }), P ({ 4, 12 }), 0, 0, 0 },                                         // shuffle
        { P ({ 0, 4, 8, 12 }), E8, P ({ 3, 6, 11, 14 }), 0, 0, 0 },                                                           // dembow
        { P ({ 0, 8 }), P ({ 0, 2, 3, 4, 6, 7, 8, 10, 11, 12, 14, 15 }), P ({ 4, 12 }), 0, 0, P ({ 6, 14 }) },               // cumbia
        { P ({ 0, 3, 4, 7, 8, 11, 12, 15 }), S16, P ({ 2, 6, 9, 13 }), 0, 0, 0 },                                            // samba
        { P ({ 0, 10, 11 }), P ({ 0, 4, 8, 12 }), P ({ 4, 12 }), 0, 0, P ({ 14 }) },                                          // trip hop
        { P ({ 0, 3, 6, 8, 11, 14 }), 0, P ({ 4, 12 }), 0, 0, 0 },                                                            // milonga
        { 0, 0, 0, 0, 0, 0 } };                                                                                               // vacío
    if (! juce::isPositiveAndBelow (i, 20)) return;
    for (int l = 0; l < kLanes; ++l) lanes[l].store (pats[i][l]);
}
void LirioProcessor::parameterChanged (const juce::String& id, float value)
{
    if (id == "drumPattern") loadPattern (juce::roundToInt (value));
}

// ---------------- grabar demo ----------------
juce::File LirioProcessor::recordFolder() const
{
    return juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("Lirio");
}
bool LirioProcessor::startRecording()
{
    stopRecording();
    auto folder = recordFolder(); folder.createDirectory();
    auto file = folder.getNonexistentChildFile ("Lirio-demo-" + juce::Time::getCurrentTime().formatted ("%Y-%m-%d_%H-%M-%S"), ".wav");
    auto stream = std::unique_ptr<juce::OutputStream> (file.createOutputStream());
    if (stream == nullptr) return false;
    juce::WavAudioFormat wav;
    std::unique_ptr<juce::AudioFormatWriter> w (wav.createWriterFor (stream.get(), currentSR, 2, 24, {}, 0));
    if (w == nullptr) return false;
    stream.release(); // ahora es del writer
    writerThread.startThread();
    threaded = std::make_unique<juce::AudioFormatWriter::ThreadedWriter> (w.release(), writerThread, 32768);
    lastRecording = file; recSamples.store (0);
    { const juce::ScopedLock sl (writerLock); activeWriter = threaded.get(); }
    recording.store (true);
    return true;
}
void LirioProcessor::stopRecording()
{
    recording.store (false);
    { const juce::ScopedLock sl (writerLock); activeWriter = nullptr; }
    threaded.reset(); // termina de escribir el archivo
}
LirioProcessor::~LirioProcessor()
{
    apvts.removeParameterListener ("drumPattern", this);
    stopRecording();
    writerThread.stopThread (2000);
}

// ---------------- procesador ----------------
LirioProcessor::LirioProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Salida", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "LIRIO", createLayout())
{
    for (auto& l : lanes) l.store (0);
    loadPattern (0);
    exportEv.reserve (lirio::Engine::kMaxLoop);
    apvts.addParameterListener ("drumPattern", this);
}

bool LirioProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    return l.getMainOutputChannelSet() == juce::AudioChannelSet::stereo() || l.getMainOutputChannelSet() == juce::AudioChannelSet::mono();
}

void LirioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSR = sampleRate;
    monoScratch.setSize (1, juce::jmax (1, samplesPerBlock));
    engine.prepare (sampleRate, samplesPerBlock);
    keyboardState.reset();
}

lirio::Params LirioProcessor::readParams()
{
    auto f = [this] (const char* id) { return apvts.getRawParameterValue (id)->load(); };
    auto i = [&] (const char* id) { return (int) std::lround (f (id)); };
    lirio::Params p;
    p.mode = i ("mode");
    p.chordMask = 0; for (int k = 0; k < 9; ++k) if (f (chordIds[k]) > .5f) p.chordMask |= 1 << k;
    p.voiceLead = f ("voiceLead") > .5f; p.complexity = i ("complexity"); p.rhythm = i ("rhythm");
    p.bassMode = i ("bassMode"); p.bassSound = i ("bassSound");
    p.drive = f ("drive"); p.phaser = f ("phaser"); p.flanger = f ("flanger"); p.cutoff = f ("cutoff");
    { static const int bars[] = { 1, 2, 4, 8 }; p.loopBars = bars[juce::jlimit (0, 3, i ("loopBars"))]; } p.loopQuant = f ("loopQuant") > .5f;
    p.drumVerb = f ("drumVerb"); p.drumDrive = f ("drumDrive");
    p.hold = f ("hold") > .5f; p.keySwitch = f ("keyswitch") > .5f; p.followOct = f ("followOct") > .5f;
    p.key = i ("key"); p.scale = i ("scale"); p.voicing = i ("voicing"); p.octave = i ("octave");
    p.perf = i ("perf"); p.strumMs = f ("strum"); p.slop = f ("slop"); p.arpRate = i ("arpRate"); p.arpPattern = i ("arpPattern"); p.arpOct = i ("arpOct"); p.arpGate = f ("arpGate"); p.tempo = f ("tempo");
    p.engine = i ("engine"); p.bright = f ("bright"); p.tone2 = f ("tone2"); p.character = f ("character"); p.movement = f ("movement");
    p.attack = f ("attack"); p.decay = f ("decay"); p.sustain = f ("sustain"); p.release = f ("release"); p.velSens = f ("velsens");
    p.bassOn = f ("bassOn") > .5f; p.bassLevel = f ("bassLevel"); p.bassOct = i ("bassOct"); p.bassTone = f ("bassTone");
    p.chorus = f ("chorus"); p.delayMix = f ("delayMix"); p.delayFb = f ("delayFb"); p.delayTime = i ("delayTime");
    p.reverbMix = f ("reverbMix"); p.reverbSize = f ("reverbSize"); p.volume = f ("volume");
    p.drumsOn = f ("drumsOn") > .5f; p.drumSync = f ("drumSync") > .5f; p.drumVol = f ("drumVol"); p.swing = f ("swing");
    p.drumComp = f ("drumComp"); p.drumPhase = f ("drumPhase"); p.drumTone = f ("drumTone");
    for (int l = 0; l < kLanes; ++l) p.lanes[l] = lanes[l].load();
    return p;
}

void LirioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    keyboardState.processNextMidiBuffer (midi, 0, n, true);

    auto p = readParams();
    float* L = buffer.getWritePointer (0);
    float* R = buffer.getNumChannels() > 1 ? buffer.getWritePointer (1) : monoScratch.getWritePointer (0);
    if (buffer.getNumChannels() < 2 && monoScratch.getNumSamples() < n) monoScratch.setSize (1, n, false, false, true), R = monoScratch.getWritePointer (0);
    float bpm = 0.f; double ppq0 = 0.0;
    if (wrapperType != wrapperType_Standalone)
        if (auto* ph = getPlayHead())
            if (auto pos = ph->getPosition())
            {
                if (auto b = pos->getBpm()) bpm = (float) *b;
                if (auto q = pos->getPpqPosition()) { ppq0 = *q; p.hostPpqValid = true; }
                p.hostPlaying = pos->getIsPlaying();
            }
    lastHostBpm.store (bpm);
    p.hostBpm = bpm;
    const double ppqPerSample = bpm > 0 ? bpm / 60.0 / getSampleRate() : 0.0;
    auto renderTo = [&] (int from, int to)
    {
        p.hostPpq = ppq0 + ppqPerSample * from;
        engine.render (L + from, R + from, to - from, p);
    };
    const bool midiOut = apvts.getRawParameterValue ("midiOut")->load() > .5f;
    engine.midiOutOn = midiOut;
    const juce::uint64 blockStart = engine.now();
    engine.outN = 0;

    int pos = 0;
    for (const auto meta : midi)
    {
        const int at = juce::jlimit (0, n, meta.samplePosition);
        if (at > pos) { renderTo (pos, at); pos = at; }
        const auto m = meta.getMessage();
        if (m.isNoteOn()) engine.userNoteOn (m.getNoteNumber(), m.getFloatVelocity(), p, 0);
        else if (m.isNoteOff()) engine.userNoteOff (m.getNoteNumber(), p, 0);
        else if (m.isSustainPedalOn()) engine.sustain (true, p);
        else if (m.isSustainPedalOff()) engine.sustain (false, p);
        else if (m.isPitchWheel()) engine.pitchBend ((float) (m.getPitchWheelValue() - 8192) / 8192.f * 2.f);
        else if (m.isController() && m.getControllerNumber() == 1) engine.modWheel (m.getControllerValue() / 127.f);
        else if (m.isAllNotesOff() || m.isAllSoundOff()) engine.allOff();
    }
    if (pos < n) renderTo (pos, n);
    // salida MIDI: canal 1 los acordes (con strum, arpegio, patrón y looper), canal 2 el bajo
    midi.clear();
    if (midiOut)
        for (int k = 0; k < engine.outN; ++k)
        {
            const auto& e = engine.outEv[k];
            const int off = (int) juce::jlimit<juce::int64> (0, n - 1, (juce::int64) (e.t - blockStart));
            midi.addEvent (juce::MidiMessage (e.status, e.note, e.vel), off);
        }
    engine.outN = 0;
    // pedido de exportar el loop: se copia acá (hilo de audio) para no pisarse
    if (exportReq.load() && ! exportReady.load())
    {
        exportEv.assign (engine.loopEv, engine.loopEv + engine.loopN);
        exportLen = engine.loopLen; exportBpm = engine.loopBpm; exportParams = p;
        exportReq.store (false); exportReady.store (true);
    }
    for (int ch = 2; ch < buffer.getNumChannels(); ++ch) buffer.clear (ch, 0, n);

    // grabar demo: escribe lo que sale (sin bloquear el audio)
    if (recording.load())
    {
        const juce::ScopedTryLock sl (writerLock);
        if (sl.isLocked() && activeWriter != nullptr)
        {
            const float* chans[2] = { L, R };
            if (activeWriter->write (chans, n)) recSamples.fetch_add (n);
        }
    }
}

void LirioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty ("program", currentProgram, nullptr);
    juce::String ln; for (int l = 0; l < kLanes; ++l) ln << juce::String::toHexString ((int) lanes[l].load()) << (l < kLanes - 1 ? "," : "");
    state.setProperty ("lanes", ln, nullptr);
    if (auto xml = state.createXml()) copyXmlToBinary (*xml, destData);
}
void LirioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
        {
            auto vt = juce::ValueTree::fromXml (*xml);
            currentProgram = (int) vt.getProperty ("program", 0);
            apvts.replaceState (vt);
            auto parts = juce::StringArray::fromTokens (vt.getProperty ("lanes", "").toString(), ",", "");
            if (parts.size() == kLanes) for (int l = 0; l < kLanes; ++l) lanes[l].store ((uint16_t) parts[l].getHexValue32());
        }
}

juce::AudioProcessorEditor* LirioProcessor::createEditor() { return new LirioEditor (*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new LirioProcessor(); }
