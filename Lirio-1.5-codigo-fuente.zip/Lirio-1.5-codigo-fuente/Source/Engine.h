// LIRIO · máquina de acordes — motor de audio (C++17 puro, sin dependencias)
// Cada tecla es la raíz de un acorde; interpretación (acorde, strum, slop, arpegio, arpa),
// tres motores de síntesis (analógico, FM, lengüeta), bajo aparte y efectos (chorus, delay, reverb).
#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>
#include <array>
#include <algorithm>
#include <atomic>
#include <string>

namespace lirio {

constexpr float kPi = 3.14159265358979f;
constexpr float kTwoPi = 6.28318530717959f;
constexpr int kMaxVoices = 32;
constexpr int kMaxEvents = 512;

// botones de acorde (se combinan): Mayor/Menor/Dim se excluyen entre sí; el resto se suma
enum ChordBit { CB_Maj = 1, CB_Min = 2, CB_Dim = 4, CB_Sus2 = 8, CB_Sus4 = 16, CB_Six = 32, CB_Seven = 64, CB_Maj7 = 128, CB_Nine = 256 };
constexpr int kThirdBits = CB_Maj | CB_Min | CB_Dim;
enum Perf { P_Chord = 0, P_Strum, P_Slop, P_Arp, P_Harp, P_Pattern };
enum EngineType { E_Analog = 0, E_FM, E_Reed };
constexpr int kNumRhythms = 11;
// patrones del modo PATRÓN: 16 semicorcheas · X acento, x golpe, - sigue sonando, . silencio
inline const char* rhythmPattern (int i)
{
    static const char* R[kNumRhythms] = {
        "X---x---x---x---", // negras
        "X-x-x-x-X-x-x-x-", // corcheas
        "X-----x---------", // charleston
        "X--x--x-X--x--x-", // tresillo
        "..x-..x-..x-..x-", // a contratiempo
        "X--x--x---x-x---", // empuje pop
        "X--x--x---x--x--", // bossa
        "X.xx.x.xX.x..xx.", // funk
        "X.xxX.xxX.xxX.xx", // galope
        "X-.x-.x-.x-.xx-.", // síncopa
        "X-------x--x-x--"  // balada
    };
    return R[(i % kNumRhythms + kNumRhythms) % kNumRhythms];
}

struct Params
{
    int   mode = 0;          // 0 acordes, 1 notas
    int   chordMask = 0;     // botones de acorde prendidos (ChordBit); 0 = AUTO
    bool  hold = false, keySwitch = true, followOct = true, voiceLead = false;
    int   complexity = 1;    // 0 simple, 1 avanzado, 2 libre
    int   key = 9, scale = 1; // 0 mayor, 1 menor
    int   voicing = 0, octave = 0;
    int   perf = 0, rhythm = 0;
    float strumMs = 40.f, slop = 0.5f;
    int   arpRate = 1, arpPattern = 0, arpOct = 1;
    float arpGate = 0.6f, tempo = 100.f;
    int   engine = 0;
    float bright = 0.6f, tone2 = 0.25f, character = 0.5f, movement = 0.3f;
    float attack = 0.005f, decay = 1.0f, sustain = 0.6f, release = 0.4f, velSens = 0.7f;
    bool  bassOn = false; float bassLevel = 0.6f; int bassOct = 1; float bassTone = 0.4f;
    int   bassMode = 0, bassSound = 0; // 0 sigue al acorde, 1 solo bajo
    float chorus = 0.4f, delayMix = 0.15f, delayFb = 0.35f; int delayTime = 1;
    float reverbMix = 0.25f, reverbSize = 0.7f, volume = 0.75f;
    float drive = 0.f, phaser = 0.f, flanger = 0.f, cutoff = 1.f;
    float hostBpm = 0.f;     // >0 cuando el DAW da tempo
    // looper
    int   loopBars = 2; bool loopQuant = true;
    // ritmo
    bool  drumsOn = false, drumSync = true, hostPlaying = false, hostPpqValid = false;
    double hostPpq = 0.0;
    float drumVol = 0.7f, swing = 0.f, drumComp = 0.6f, drumPhase = 0.35f, drumTone = 0.6f, drumVerb = 0.f, drumDrive = 0.f;
    uint16_t lanes[6] {};
};

// ---------------- armado de acordes ----------------
inline int popcount32 (uint32_t m) { int c = 0; while (m) { m &= m - 1; ++c; } return c; }

// intervalos del acorde (bits 0..23, relativos a la raíz) para la nota pc según los botones prendidos
inline uint32_t chordIntervals (int pc, int mask, int key, int scale, int complexity)
{
    static const int SCL[2][7] = { { 0, 2, 4, 5, 7, 9, 11 }, { 0, 2, 3, 5, 7, 8, 10 } };
    int third = 4, fifth = 7, dSev = 10;
    const bool hasThird = (mask & kThirdBits) != 0;
    if (mask & CB_Maj)      { third = 4; fifth = 7; }
    else if (mask & CB_Min) { third = 3; fifth = 7; }
    else if (mask & CB_Dim) { third = 3; fifth = 6; }
    else // AUTO: tercera, quinta y séptima de la escala
    {
        const int* sc = SCL[scale ? 1 : 0];
        const int rel = ((pc - key) % 12 + 12) % 12;
        int d = -1; for (int k = 0; k < 7; ++k) if (sc[k] == rel) d = k;
        if (d >= 0)
        {
            third = (sc[(d + 2) % 7] - rel + 12) % 12; fifth = (sc[(d + 4) % 7] - rel + 12) % 12; dSev = (sc[(d + 6) % 7] - rel + 12) % 12;
            if (dSev != 10 && dSev != 11) dSev = 10;
        }
    }
    const bool s2 = (mask & CB_Sus2) != 0, s4 = (mask & CB_Sus4) != 0;
    bool six = (mask & CB_Six) != 0, sev = (mask & CB_Seven) != 0, maj7 = (mask & CB_Maj7) != 0, nine = (mask & CB_Nine) != 0;
    uint32_t m = 1u;
    if ((s2 || s4) && ! hasThird) { if (s2) m |= 1u << 2; if (s4) m |= 1u << 5; } // sus: reemplaza la tercera
    else { m |= 1u << third; if (s2) m |= 1u << 2; if (s4) m |= 1u << 5; }        // con MAYOR/MENOR/DIM: se suma
    m |= 1u << fifth;
    const int sevIv = hasThird ? 10 : dSev;
    if (complexity == 0) // simple: un solo color (maj7 > 7 > 6 > 9)
    {
        if (maj7) { sev = six = nine = false; } else if (sev) { six = nine = false; } else if (six) nine = false;
    }
    if (complexity == 1 && maj7 && sev) sev = false; // avanzado: maj7 manda sobre 7
    if (six)  m |= 1u << ((complexity == 1 && (sev || maj7)) ? 21 : 9); // 6 + 7 = 13
    if (sev)  m |= 1u << sevIv;
    if (maj7) m |= 1u << 11;
    if (nine) m |= 1u << 14;
    const int lim = complexity == 0 ? 4 : complexity == 1 ? 6 : 99; // si hay demasiadas notas, se saca la quinta
    if (popcount32 (m) > lim && (m & (1u << 7))) m &= ~(1u << 7);
    return m;
}

// nombre del acorde a partir de los intervalos; tag: 0 normal, 1 "JAZZ?", 2 "WTF?"
inline std::string chordSuffix (uint32_t m, int* tag = nullptr)
{
    auto has = [m] (int i) { return ((m >> i) & 1u) != 0; };
    const bool t4 = has (4), t3 = has (3), b5 = has (6) && ! has (7);
    const bool sev = has (10), maj7 = has (11), six = has (9), thir = has (21), nine = has (14);
    const bool s2 = has (2), s4 = has (5);
    std::string s;
    if (t3 && b5 && ! t4)
    {
        if (sev) s = "m7b5"; else if (six) s = "dim7"; else s = "dim";
        if (maj7) s += "(maj7)";
        if (nine) s += "(add9)";
    }
    else
    {
        const std::string q = t3 && ! t4 ? "m" : "";
        if (sev || maj7)
        {
            const std::string ext = thir ? "13" : nine ? "9" : "7";
            if (maj7 && sev) s = q + ext + "(maj7)";
            else if (maj7)   s = q.empty() ? "maj" + ext : "m(maj" + ext + ")";
            else             s = q + ext;
            if (six && ! thir) s += "(add6)";
        }
        else if (six || thir) s = q + (nine ? "6/9" : "6");
        else { s = q; if (nine) s += "add9"; }
    }
    if (! t3 && ! t4) s += s4 ? (s2 ? "sus2sus4" : "sus4") : (s2 ? "sus2" : "5");
    else { if (s2) s += "(add2)"; if (s4) s += "(add4)"; }
    if (tag)
    {
        const int n = popcount32 (m);
        *tag = (sev && maj7) || (t3 && t4) || n >= 7 ? 2 : (n >= 5 ? 1 : 0);
    }
    return s;
}

// ---------------- utilidades ----------------
inline float mtof (float m) { return 440.f * std::pow (2.f, (m - 69.f) / 12.f); }
inline float polyblep (float t, float dt)
{
    if (t < dt)       { t /= dt; return t + t - t * t - 1.f; }
    if (t > 1.f - dt) { t = (t - 1.f) / dt; return t * t + t + t + 1.f; }
    return 0.f;
}
struct Rng { uint32_t s = 0x12345678u; float next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return (float) (s & 0xffffff) / 8388608.f - 1.f; } float uni() { return 0.5f * (next() + 1.f); } };

struct Adsr
{
    enum St { Idle, Att, Dec, Sus, Rel } st = Idle;
    float v = 0, a = 0.01f, d = 0.5f, s = 0.6f, r = 0.4f, sr = 48000;
    float dCo = 0, rCo = 0;
    void set (float A, float D, float S, float R, float SR) { a = std::max (A, 0.0005f); d = std::max (D, 0.005f); s = S; r = std::max (R, 0.005f); sr = SR;
        dCo = std::exp (-1.f / (d * 0.3f * sr)); rCo = std::exp (-1.f / (r * 0.3f * sr)); }
    void on()  { st = Att; }
    void off() { if (st != Idle) st = Rel; }
    float next()
    {
        switch (st)
        {
            case Att: v += 1.f / (a * sr); if (v >= 1.f) { v = 1.f; st = Dec; } break;
            case Dec: v = s + (v - s) * dCo; if (std::fabs (v - s) < 1e-4f) st = Sus; break;
            case Sus: v = s; break;
            case Rel: v *= rCo; if (v < 1e-5f) { v = 0; st = Idle; } break;
            default: v = 0; break;
        }
        return v;
    }
};

// filtro de estado variable (TPT) — 12 dB/oct; dos en serie = 24 dB/oct
struct Svf
{
    float ic1 = 0, ic2 = 0, g = 0.1f, k = 1.4f, a1 = 0, a2 = 0, a3 = 0;
    void set (float fc, float res, float sr)
    {
        fc = std::min (std::max (fc, 20.f), sr * 0.45f);
        g = std::tan (kPi * fc / sr); k = 2.f - 1.9f * std::min (std::max (res, 0.f), 1.f);
        a1 = 1.f / (1.f + g * (g + k)); a2 = g * a1; a3 = g * a2;
    }
    float lp (float x)
    {
        float v3 = x - ic2, v1 = a1 * ic1 + a2 * v3, v2 = ic2 + a2 * ic1 + a3 * v3;
        ic1 = 2.f * v1 - ic1; ic2 = 2.f * v2 - ic2; return v2;
    }
    void reset() { ic1 = ic2 = 0; }
};

// ---------------- voz ----------------
struct Voice
{
    bool active = false, released = false;
    int note = 60; float vel = 1; uint32_t tag = 0; uint64_t age = 0; float gainMul = 1;
    float freq = 261.6f;
    float ph[5] {}; float fmPh = 0, fmPh2 = 0;
    Adsr amp, fenv; Svf f1, f2; Rng rng; float noiseEnv = 0, relThump = 0, lp1 = 0;
    int ctr = 0; float idxEnv = 0; float lastOut = 0, declick = 0;

    void start (int n, float v, uint32_t t, uint64_t a, const Params& p, float sr)
    {
        declick = active ? lastOut : 0.f; // si se reutiliza una voz que sonaba, se evita el "click"
        active = true; released = false; note = n; vel = v; tag = t; age = a;
        freq = mtof ((float) n);
        for (auto& x : ph) x = rng.uni();
        fmPh = fmPh2 = 0;
        if (p.engine == E_Analog) amp.set (p.attack, p.decay, p.sustain, p.release, sr);
        else // FM y lengüeta: envolvente de decaimiento natural
            amp.set (std::min (p.attack, 0.5f), p.decay * 1.6f, p.sustain, p.release, sr);
        fenv.set (0.002f, p.decay * 0.6f + 0.05f, 0.0f, p.release, sr);
        amp.v = 0; amp.on(); fenv.v = 0; fenv.on(); f1.reset(); f2.reset();
        noiseEnv = 1.f; relThump = 0; idxEnv = 1.f; ctr = 0; lp1 = 0;
        rng.s ^= (uint32_t) (n * 2654435761u + t);
    }
    void stop() { if (!released) { released = true; amp.off(); fenv.off(); relThump = 1.f; } }

    // devuelve una muestra mono; bend = factor de frecuencia, vib = desplazamiento por LFO
    inline float render (const Params& p, float sr, float bend, float lfo, float lfoSlow)
    {
        if (! active) return 0.f;
        const float e = amp.next();
        if (amp.st == Adsr::Idle) { active = false; lastOut = 0; declick = 0.f; return 0.f; }
        const float velG = (1.f - p.velSens) + p.velSens * vel;
        float out = 0.f;
        const float f = freq * bend * (1.f + lfo);

        if (p.engine == E_Analog)
        {
            const float det = 1.f + p.movement * 0.012f;
            const float dt0 = f / sr, dt1 = f * det / sr, dt2 = f * 0.5f / sr;
            float s0 = 2.f * ph[0] - 1.f - polyblep (ph[0], dt0);
            float s1 = 2.f * ph[1] - 1.f - polyblep (ph[1], dt1);
            float pw = 0.5f + 0.35f * p.movement * lfoSlow;
            float t2 = ph[2] + pw; if (t2 >= 1.f) t2 -= 1.f;
            float pu = (ph[2] < pw ? 1.f : -1.f) + polyblep (ph[2], dt0) - polyblep (t2, dt0);
            float sub = (ph[3] < 0.5f ? 1.f : -1.f) + polyblep (ph[3], dt2) - polyblep (std::fmod (ph[3] + 0.5f, 1.f), dt2);
            ph[0] += dt0; if (ph[0] >= 1.f) ph[0] -= 1.f;
            ph[1] += dt1; if (ph[1] >= 1.f) ph[1] -= 1.f;
            ph[2] += dt0; if (ph[2] >= 1.f) ph[2] -= 1.f;
            ph[3] += dt2; if (ph[3] >= 1.f) ph[3] -= 1.f;
            float x = 0.42f * s0 + 0.3f * s1 + 0.22f * pu + 0.28f * sub;
            const float fe = fenv.next();
            if ((ctr++ & 7) == 0)
            {
                float base = 60.f * std::pow (250.f, p.bright);
                float kt = std::pow (f / 261.6f, 0.5f);
                float env = std::pow (2.f, fe * p.character * 6.f * (0.4f + 0.6f * vel));
                float fc = base * kt * env;
                f1.set (fc, p.tone2, sr); f2.set (fc, p.tone2 * 0.3f, sr);
            }
            out = f2.lp (f1.lp (x)) * 0.55f;
        }
        else if (p.engine == E_FM)
        {
            // relación del modulador elegida con "Relación" (tone2)
            static const float ratios[] = { 0.5f, 1.f, 2.f, 3.f, 3.5f, 4.f, 5.f, 7.f };
            const int ri = std::min (7, (int) (p.tone2 * 7.99f));
            const float ratio = ratios[ri];
            idxEnv *= std::exp (-1.f / (sr * (0.08f + p.decay * 0.35f)));
            const float I = (0.4f + p.character * 6.f) * (0.35f + 0.65f * vel) * (0.25f + 0.75f * idxEnv) * (0.5f + p.bright);
            const float m = std::sin (kTwoPi * fmPh) * I;
            // "tine": modulador agudo muy corto (ataque tipo piano eléctrico)
            const float tine = std::sin (kTwoPi * fmPh2) * 1.6f * vel * idxEnv * idxEnv * idxEnv;
            out = std::sin (kTwoPi * ph[0] + m + (f * 14.f < sr * 0.4f ? tine : 0.f)) * 0.5f;
            ph[0] += f / sr; if (ph[0] >= 1.f) ph[0] -= 1.f;
            fmPh += f * ratio / sr; if (fmPh >= 1.f) fmPh -= 1.f;
            fmPh2 += f * 14.f / sr; if (fmPh2 >= 1.f) fmPh2 -= 1.f;
            out *= 1.f + 0.5f * p.movement * lfoSlow; // movimiento = trémolo suave
        }
        else // E_Reed: piano eléctrico de lengüeta con ruido mecánico
        {
            idxEnv *= std::exp (-1.f / (sr * 0.25f));
            const float I = (0.3f + 1.2f * vel) * (0.3f + 0.7f * idxEnv);
            const float m = std::sin (kTwoPi * fmPh) * I;
            float x = std::sin (kTwoPi * ph[0] + m) + (0.25f + 0.25f * vel) * std::sin (2.f * kTwoPi * ph[0]) + 0.08f * vel * std::sin (3.f * kTwoPi * ph[0]);
            ph[0] += f / sr; if (ph[0] >= 1.f) ph[0] -= 1.f;
            fmPh += f / sr; if (fmPh >= 1.f) fmPh -= 1.f;
            const float drive = 1.f + p.character * 4.f * vel;
            x = std::tanh (x * drive) / std::tanh (drive);
            // ruido mecánico: golpe al tocar y "thump" al soltar
            noiseEnv *= 0.9965f; relThump *= 0.993f;
            const float n = rng.next();
            lp1 += 0.08f * (n - lp1);
            const float mech = p.tone2 * (noiseEnv * vel * 0.5f * (n - lp1) + relThump * 0.25f * lp1);
            out = (x * 0.45f + mech * 0.6f);
            if ((ctr++ & 7) == 0) f1.set (900.f * std::pow (14.f, p.bright) * (0.6f + 0.4f * vel), 0.1f, sr);
            out = f1.lp (out);
            out *= 1.f + 0.6f * p.movement * lfoSlow; // trémolo
        }
        declick *= 0.96f;
        lastOut = out * e * velG * gainMul + declick;
        return lastOut;
    }
};

// ---------------- bajo (mono) ----------------
// sonidos: 0 redondo, 1 sierra, 2 cuadrado, 3 sub, 4 FM, 5 ácido
struct Bass
{
    bool active = false; int note = 36; float vel = 1; Adsr amp; float ph = 0, ph2 = 0, lp = 0, fenv = 0; uint32_t tag = 0; Svf flt;
    void start (int n, float v, uint32_t t, float sr, int sound)
    {
        note = n; vel = v; tag = t; active = true; fenv = 1.f;
        if (sound == 4) amp.set (0.002f, 0.9f, 0.35f, 0.15f, sr);
        else if (sound == 5) amp.set (0.002f, 0.35f, 0.55f, 0.12f, sr);
        else amp.set (0.004f, 0.6f, 0.75f, 0.18f, sr);
        amp.on();
    }
    void glide (int n, uint32_t t) { note = n; tag = t; } // legato (modo solo): cambia la nota sin volver a atacar
    void stop() { amp.off(); }
    float render (const Params& p, float sr, float bend)
    {
        if (! active) return 0.f;
        float e = amp.next(); if (amp.st == Adsr::Idle) { active = false; return 0.f; }
        const float f = mtof ((float) note) * bend, dt = f / sr;
        const float tn = p.bassTone;
        float out = 0.f;
        fenv *= std::exp (-1.f / (sr * (p.bassSound == 5 ? 0.12f : 0.25f)));
        switch (p.bassSound)
        {
            case 1: // sierra filtrada
            {
                const float saw = 2.f * ph2 - 1.f - polyblep (ph2, dt);
                flt.set (90.f + 2600.f * tn * tn * (0.35f + 0.65f * fenv) + f * 1.5f, 0.25f, sr);
                out = flt.lp (saw) * 0.75f; break;
            }
            case 2: // cuadrado + sub
            {
                const float sq = (ph2 < 0.5f ? 1.f : -1.f) + polyblep (ph2, dt) - polyblep (std::fmod (ph2 + 0.5f, 1.f), dt);
                flt.set (120.f + 2200.f * tn * tn, 0.15f, sr);
                out = flt.lp (sq) * 0.3f + 0.28f * std::sin (kTwoPi * ph); break;
            }
            case 3: // sub: seno grave con un poco de saturación
            {
                const float x = std::sin (kTwoPi * ph) + 0.15f * std::sin (2.f * kTwoPi * ph);
                const float g = 1.f + 3.f * tn;
                out = std::tanh (x * g) / std::tanh (g) * 0.5f; break;
            }
            case 4: // FM pulsado
            {
                const float I = (0.5f + 4.f * tn) * (0.2f + 0.8f * fenv);
                out = std::sin (kTwoPi * ph + I * std::sin (kTwoPi * ph2)) * 0.7f; break;
            }
            case 5: // ácido: sierra con filtro resonante que se cierra rápido
            {
                const float saw = 2.f * ph2 - 1.f - polyblep (ph2, dt);
                flt.set (110.f + 3800.f * (0.15f + 0.85f * tn) * fenv * fenv + f, 0.86f, sr);
                out = std::tanh (flt.lp (saw) * 1.6f) * 0.6f; break;
            }
            default: // redondo (el de siempre)
            {
                const float sine = std::sin (kTwoPi * ph);
                const float saw = 2.f * ph2 - 1.f - polyblep (ph2, dt);
                const float c = 1.f - std::exp (-kTwoPi * (120.f + 1800.f * tn * tn) / sr);
                lp += c * (saw - lp);
                out = 0.75f * sine + 0.5f * tn * lp + 0.15f * lp;
            }
        }
        ph += dt; if (ph >= 1.f) ph -= 1.f; ph2 += dt; if (ph2 >= 1.f) ph2 -= 1.f;
        return out * e * (0.6f + 0.4f * vel) * p.bassLevel * 0.55f;
    }
};

// ---------------- efectos ----------------
struct DelayLine
{
    std::vector<float> b; int w = 0;
    void init (int n) { b.assign ((size_t) std::max (n, 4), 0.f); w = 0; }
    void push (float x) { b[(size_t) w] = x; if (++w >= (int) b.size()) w = 0; }
    float tap (float d) const // d en muestras (fraccional)
    {
        float r = (float) w - d - 1.f; while (r < 0) r += (float) b.size();
        int i = (int) r; float fr = r - (float) i; int j = i + 1; if (j >= (int) b.size()) j = 0;
        return b[(size_t) i] + fr * (b[(size_t) j] - b[(size_t) i]);
    }
};

struct Comb { std::vector<float> b; int i = 0; float store = 0;
    void init (int n) { b.assign ((size_t) n, 0.f); i = 0; store = 0; }
    float process (float x, float fb, float damp) { float o = b[(size_t) i]; store = o * (1.f - damp) + store * damp; b[(size_t) i] = x + store * fb; if (++i >= (int) b.size()) i = 0; return o; } };
struct Allp { std::vector<float> b; int i = 0;
    void init (int n) { b.assign ((size_t) n, 0.f); i = 0; }
    float process (float x) { float o = b[(size_t) i]; b[(size_t) i] = x + o * 0.5f; if (++i >= (int) b.size()) i = 0; return o - x; } };

struct Reverb // tipo Freeverb, estéreo
{
    Comb cl[8], cr[8]; Allp al[4], ar[4];
    void init (float sr)
    {
        static const int ct[8] = { 1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617 };
        static const int at[4] = { 556, 441, 341, 225 };
        const float k = sr / 44100.f;
        for (int n = 0; n < 8; ++n) { cl[n].init ((int) (ct[n] * k)); cr[n].init ((int) ((ct[n] + 23) * k)); }
        for (int n = 0; n < 4; ++n) { al[n].init ((int) (at[n] * k)); ar[n].init ((int) ((at[n] + 23) * k)); }
    }
    void process (float inL, float inR, float size, float& oL, float& oR)
    {
        const float fb = 0.7f + 0.28f * size, damp = 0.35f - 0.15f * size, in = (inL + inR) * 0.015f;
        float l = 0, r = 0;
        for (int n = 0; n < 8; ++n) { l += cl[n].process (in, fb, damp); r += cr[n].process (in, fb, damp); }
        for (int n = 0; n < 4; ++n) { l = al[n].process (l); r = ar[n].process (r); }
        oL = l; oR = r;
    }
};


// ---------------- caja de ritmos: bombo, hi-hat, redoblante y 3 toms ----------------
// sonido setentoso: saturado, muy comprimido y con fase (phaser) en el bus
enum DrumLane { D_Kick = 0, D_Hat, D_Snare, D_TomHi, D_TomMid, D_TomLo, D_Count };

struct DrumVoice
{
    bool active = false; int type = 0; float t = 0, vel = 1, ph = 0, ph2 = 0, hp = 0, prevN = 0, lp = 0; Rng rng;
    float mph[6] {};
    void trigger (int ty, float v) { active = true; type = ty; t = 0; vel = v; ph = ph2 = 0; hp = prevN = lp = 0; for (auto& m : mph) m = rng.uni(); }
    float render (float sr, float tone)
    {
        if (! active) return 0.f;
        const float ts = t / sr; t += 1.f; float out = 0.f;
        const float n = rng.next();
        switch (type)
        {
            case D_Kick:
            {
                const float f = 48.f + 120.f * std::exp (-ts / 0.035f);
                ph += f / sr; if (ph >= 1.f) ph -= 1.f;
                const float body = std::sin (kTwoPi * ph) * std::exp (-ts / 0.32f);
                const float click = n * std::exp (-ts / 0.0015f) * 0.35f;
                out = std::tanh ((body + click) * 1.8f) * 0.95f;
                if (ts > 1.2f) active = false; break;
            }
            case D_Snare:
            {
                const float f = 175.f + 90.f * std::exp (-ts / 0.02f);
                ph += f / sr; if (ph >= 1.f) ph -= 1.f; ph2 += f * 1.87f / sr; if (ph2 >= 1.f) ph2 -= 1.f;
                const float body = (std::sin (kTwoPi * ph) + 0.4f * std::sin (kTwoPi * ph2)) * std::exp (-ts / 0.07f) * 0.55f;
                hp = n - prevN + 0.6f * hp; prevN = n;               // agudos del ruido (cuerdas del redoblante)
                lp += (0.25f + 0.5f * tone) * (hp - lp);
                const float noise = lp * (std::exp (-ts / 0.16f) + 0.45f * std::exp (-std::fabs (ts - 0.012f) / 0.006f)) * 0.75f;
                out = std::tanh ((body + noise) * 2.2f) * 0.75f;
                if (ts > 0.8f) active = false; break;
            }
            case D_Hat:
            {
                static const float r[6] = { 205.3f, 304.4f, 369.6f, 522.7f, 540.f, 800.f };
                float m = 0; for (int k = 0; k < 6; ++k) { mph[k] += r[k] * 2.4f / sr; if (mph[k] >= 1.f) mph[k] -= 1.f; m += mph[k] < 0.5f ? 1.f : -1.f; }
                const float x = m * 0.12f + n * 0.5f;
                hp = x - prevN + 0.2f * hp; prevN = x;
                out = hp * std::exp (-ts / (0.025f + 0.03f * tone)) * 0.45f;
                if (ts > 0.4f) active = false; break;
            }
            default: // toms
            {
                const float base = type == D_TomHi ? 196.f : type == D_TomMid ? 138.f : 92.f;
                const float dec  = type == D_TomHi ? 0.32f : type == D_TomMid ? 0.42f : 0.55f;
                const float f = base * (1.f + 0.45f * std::exp (-ts / 0.05f));
                ph += f / sr; if (ph >= 1.f) ph -= 1.f;
                const float body = std::sin (kTwoPi * ph) * std::exp (-ts / dec);
                lp += 0.2f * (n - lp);
                const float stick = lp * std::exp (-ts / 0.008f) * 0.6f;
                out = std::tanh ((body + stick) * 2.f) * 0.8f;
                if (ts > 2.f) active = false; break;
            }
        }
        return out * vel;
    }
};

struct DrumKit
{
    DrumVoice v[12]; int nextV = 0;
    // bus: saturación + compresor + phaser
    float env = 0, gain = 1, atk = 0, rel = 0, sr = 48000;
    float apL[4] {}, apR[4] {}, phLfo = 0, fbL = 0, fbR = 0, warm = 0, warmR = 0;
    int nextK = 0; double freeT = 0, expectQ = -1; bool running = false;
    std::atomic<int> uiStep { -1 };

    void prepare (float s) { sr = s; atk = 1.f - std::exp (-1.f / (0.002f * sr)); rel = 1.f - std::exp (-1.f / (0.12f * sr)); running = false; for (auto& x : v) x.active = false; }
    void hit (int lane, float vel) { auto& d = v[nextV]; nextV = (nextV + 1) % 12; d.trigger (lane, vel); }
    void triggerStep (int k, const Params& p)
    {
        const int s16 = ((k % 16) + 16) % 16; uiStep.store (s16);
        const float acc = (s16 % 4 == 0) ? 1.f : (s16 % 2 == 0 ? 0.85f : 0.72f);
        for (int lane = 0; lane < D_Count; ++lane)
            if ((p.lanes[lane] >> s16) & 1u) hit (lane, acc);
    }
    // posición del paso k en semicorcheas, con swing en los pasos impares
    static double stepPos (int k, float swing) { return (double) k + ((k & 1) ? swing * 0.5 : 0.0); }

    // avanza una muestra; dawQ = posición del DAW en semicorcheas (o <0 si no hay)
    void clock (const Params& p, float bpm, double dawQ)
    {
        const bool synced = p.drumSync && p.hostPpqValid;
        const bool shouldRun = p.drumsOn && (! synced || p.hostPlaying);
        if (! shouldRun) { running = false; uiStep.store (-1); return; }
        double q;
        if (synced) q = dawQ;
        else { if (! running) freeT = 0; q = freeT * bpm / 60.0 * 4.0 / sr; freeT += 1.0; }
        if (! running || std::fabs (q - expectQ) > 0.5) // arranque o salto de posición
        {
            int k = (int) std::floor (q) - 1; while (stepPos (k, p.swing) < q - 1e-9) ++k; nextK = k;
            running = true;
        }
        while (q >= stepPos (nextK, p.swing)) { triggerStep (nextK, p); ++nextK; }
        expectQ = q + bpm / 60.0 * 4.0 / sr;
    }
    void render (const Params& p, float& outL, float& outR)
    {
        float m = 0, side = 0;
        for (auto& d : v) if (d.active)
        {
            const float x = d.render (sr, p.drumTone);
            m += x;
            if (d.type == D_Hat) side += x * 0.35f; else if (d.type == D_TomHi) side -= x * 0.4f; else if (d.type == D_TomLo) side += x * 0.4f;
        }
        // saturación de cinta y tono cálido
        const float dg = 1.3f * (1.f + 4.f * p.drumDrive), dc = 1.f / (1.f + 0.8f * p.drumDrive); // saturador
        float l = std::tanh ((m - side) * dg) * dc, r = std::tanh ((m + side) * dg) * dc;
        const float c = 0.35f + 0.6f * p.drumTone; warm += c * (l - warm); warmR += c * (r - warmR); l = warm; r = warmR;
        // compresor que "respira" (mezcla en paralelo según el knob)
        const float pk = std::max (std::fabs (l), std::fabs (r));
        env += (pk > env ? atk : rel) * (pk - env);
        const float thr = 0.12f, ratio = 6.f;
        const float g = env > thr ? std::pow (env / thr, 1.f / ratio - 1.f) : 1.f;
        const float cmp = g * 2.6f;
        l = l * (1.f - p.drumComp) + l * cmp * p.drumComp; r = r * (1.f - p.drumComp) + r * cmp * p.drumComp;
        // phaser estéreo
        phLfo += 0.22f / sr; if (phLfo >= 1.f) phLfo -= 1.f;
        const float sweep = 0.5f + 0.5f * std::sin (kTwoPi * phLfo);
        const float a = 0.55f + 0.4f * sweep, aR = 0.55f + 0.4f * (1.f - sweep);
        float xl = l + fbL * 0.55f, xr = r + fbR * 0.55f;
        for (int k = 0; k < 4; ++k) { const float yl = -a * xl + apL[k]; apL[k] = xl + a * yl; xl = yl; const float yr = -aR * xr + apR[k]; apR[k] = xr + aR * yr; xr = yr; }
        fbL = xl; fbR = xr;
        l = l * (1.f - 0.5f * p.drumPhase) + xl * 0.5f * p.drumPhase * 2.f;
        r = r * (1.f - 0.5f * p.drumPhase) + xr * 0.5f * p.drumPhase * 2.f;
        const float vol = p.drumVol * p.drumVol * 0.9f;
        outL = l * vol; outR = r * vol;
    }
};

// ---------------- motor ----------------
struct Chord { int n = 0; int v[8] {}; void add (int x) { if (n < 8) v[n++] = x; } };

class Engine
{
public:
    // información para la interfaz (se lee desde otro hilo)
    std::atomic<int> uiRoot { -1 }, uiActivity { 0 }, uiMask { 0 }, uiKsHeld { 0 };
    std::atomic<uint32_t> uiIv { 0 };       // intervalos del último acorde (bits)
    std::atomic<uint64_t> uiNotesLo { 0 }, uiNotesHi { 0 }; // notas sonando (0..127)
    std::atomic<int> uiPatStep { -1 };
    // looper
    enum LoopState { L_Empty = 0, L_Armed, L_Rec, L_Play, L_Dub, L_Stop };
    std::atomic<int> uiLoopState { 0 }, uiLoopLayers { 0 }, uiLoopEvents { 0 };
    std::atomic<float> uiLoopPos { 0.f };
    std::atomic<int> loopCmd { 0 };          // 1 grabar, 2 play/parar, 3 deshacer, 4 borrar
    // salida MIDI (canal 1 acordes, canal 2 bajo); tiempo absoluto en muestras
    struct MidiOut { uint64_t t; uint8_t status, note, vel; };
    static constexpr int kMaxOut = 1024;
    MidiOut outEv[kMaxOut]; int outN = 0; bool midiOutOn = true;
    uint64_t now() const { return nowS; }

    void prepare (double sampleRate, int /*maxBlock*/)
    {
        sr = (float) sampleRate;
        for (auto& v : voices) v = Voice();
        bass = Bass();
        chL.init ((int) (sr * 0.05f)); chR.init ((int) (sr * 0.05f));
        dlL.init ((int) (sr * 2.6f)); dlR.init ((int) (sr * 2.6f)); flDl.init ((int) (sr * 0.02f));
        rev.init (sr); drumRev.init (sr); drums.prepare (sr);
        evCount = 0; nowS = 0; tagCounter = 1; heldN = 0; arpOn = false; patOn = false; dlLp = 0; dlRp = 0;
        smK = 1.f - std::exp (-1.f / (0.03f * sr)); smKd = 1.f - std::exp (-1.f / (0.15f * sr));
        limRel = 1.f - std::exp (-1.f / (0.15f * sr)); limGain = 1.f; smInit = false;
        prevN = 0; ksHeld = 0; ksThird = 0;
        for (auto& c : outCnt) c = 0; bassOutNote = -1; outN = 0;
        loopState = L_Empty; loopN = 0; loopLayers = 0; loopPos = 0; loopIdx = 0; for (auto& b : playOn) b = false; for (auto& b : userOn) b = 0;
    }

    // ---- MIDI que toca la persona (lo graba el looper) ----
    void userNoteOn (int key, float vel, const Params& p, int offset)
    {
        if (isKeySwitch (key, p)) { noteOn (key, vel, p, offset); return; }
        if (loopState == L_Armed) startLoopRec (p);
        const int mask = effMask (p);
        if (loopState == L_Rec || loopState == L_Dub) { recordEv (key, vel, true, mask, p); userOn[key & 127] = (uint16_t) (mask + 1); }
        noteOn (key, vel, p, offset);
    }
    void userNoteOff (int key, const Params& p, int offset)
    {
        if (! isKeySwitch (key, p) && (loopState == L_Rec || loopState == L_Dub) && userOn[key & 127]) recordEv (key, 0, false, 0, p);
        userOn[key & 127] = 0;
        noteOff (key, p, offset);
    }

    // ---- MIDI ----
    bool isKeySwitch (int key, const Params& p) const { return p.keySwitch && p.mode == 0 && key >= 24 && key <= 32; }
    // botones efectivos: los prendidos + los que se mantienen con las teclas de cambio
    int effMask (const Params& p) const
    {
        int m = p.chordMask;
        if (ksHeld & kThirdBits) m &= ~kThirdBits;
        m |= ksHeld & ~kThirdBits;
        m |= ksThird;
        return m;
    }
    void noteOn (int key, float vel, const Params& p, int offset, int maskOverride = -1)
    {
        if (isKeySwitch (key, p))
        {
            const int bit = 1 << (key - 24);
            ksHeld |= bit; if (bit & kThirdBits) ksThird = bit;
            uiKsHeld.store (ksHeld); uiActivity.fetch_add (1); return;
        }
        uiActivity.fetch_add (1);
        const int mask = maskOverride >= 0 ? maskOverride : effMask (p);
        const bool solo = p.mode == 0 && p.bassOn && p.bassMode == 1;
        if (p.hold && p.mode == 0 && ! solo) // mantener: un acorde nuevo reemplaza al anterior; la misma tecla lo apaga
        {
            const bool same = heldN > 0 && held[heldN - 1].key == key;
            for (int k = 0; k < heldN; ++k) releaseHeld (held[k]);
            heldN = 0;
            if (same) { stopPerf(); uiRoot.store (-1); return; }
        }
        removeHeld (key);
        if (heldN >= kMaxHeld) { releaseHeld (held[0]); removeAt (0); }
        Held& H = held[heldN++];
        H.key = key; H.vel = vel; H.tag = tagCounter++; H.pedalHeld = false; H.notes = Chord();
        const uint64_t t0 = nowS + (uint64_t) offset;
        if (solo) // solo bajo: mono, la última tecla manda
        {
            pushEv (t0, 2, bassNote (key, p), vel, H.tag);
            uiRoot.store (key); uiIv.store (0xFFFFFFFFu); return;
        }
        if (p.mode == 0) H.notes = voiceChord (key, p, mask); else H.notes.add (key + 12 * p.octave);
        const int n = H.notes.n;
        if (p.perf == P_Arp) { if (! arpOn) { arpOn = true; arpNext = t0; arpIdx = 0; } }
        else if (p.perf == P_Pattern)
        {
            if (! patOn) { patOn = true; patNext = t0; patStep = 0; }
            else // ya está andando: el acorde nuevo suena ya y el patrón sigue en su lugar
            {
                if (patTag) stopTag (patTag);
                patTag = tagCounter++;
                for (int i = 0; i < n; ++i) pushEv (t0, 1, H.notes.v[i], vel, patTag);
            }
        }
        else if (p.perf == P_Strum)
        {
            const bool down = strumDown; strumDown = ! strumDown;
            for (int i = 0; i < n; ++i) pushEv (t0 + (uint64_t) (i * p.strumMs * 0.001f * sr), 1, H.notes.v[down ? n - 1 - i : i], vel, H.tag);
        }
        else if (p.perf == P_Slop)
        {
            for (int i = 0; i < n; ++i)
            {
                const float d = rng.uni() * (0.012f + 0.09f * p.slop);
                const float v = std::min (1.f, std::max (0.05f, vel * (1.f + rng.next() * 0.3f * p.slop)));
                pushEv (t0 + (uint64_t) (d * sr), 1, H.notes.v[i], v, H.tag);
            }
        }
        else if (p.perf == P_Harp)
        {
            const float step = 0.025f + p.strumMs * 0.0009f; int k = 0;
            for (int o = 0; o < 3; ++o) for (int i = 0; i < n; ++i, ++k)
                pushEv (t0 + (uint64_t) ((float) k * step * sr), 1, H.notes.v[i] + 12 * o, vel * (1.f - 0.02f * (float) k), H.tag);
        }
        else for (int i = 0; i < n; ++i) pushEv (t0, 1, H.notes.v[i], vel, H.tag);
        if (p.bassOn && p.mode == 0) pushEv (t0, 2, bassNote (key, p), vel, H.tag);
        publishChord (key, p, mask);
    }
    void noteOff (int key, const Params& p, int /*offset*/)
    {
        if (isKeySwitch (key, p))
        {
            const int bit = 1 << (key - 24);
            ksHeld &= ~bit; if (ksThird == bit) ksThird = ksHeld & kThirdBits ? (ksHeld & CB_Dim ? CB_Dim : ksHeld & CB_Min ? CB_Min : CB_Maj) : 0;
            uiKsHeld.store (ksHeld); return;
        }
        if (sustainPedal) { for (int k = 0; k < heldN; ++k) if (held[k].key == key) held[k].pedalHeld = true; return; }
        const bool solo = p.mode == 0 && p.bassOn && p.bassMode == 1;
        if (p.hold && p.mode == 0 && ! solo) return;
        if (solo && heldN > 1 && held[heldN - 1].key == key && bass.active && bass.tag == held[heldN - 1].tag)
        {   // legato: vuelve a la tecla anterior que sigue apretada
            removeHeld (key);
            bass.glide (bassNote (held[heldN - 1].key, p), held[heldN - 1].tag); emitBass (bass.note, 100);
            uiRoot.store (held[heldN - 1].key); return;
        }
        for (int k = 0; k < heldN; ++k) if (held[k].key == key) releaseHeld (held[k]);
        removeHeld (key);
        if (heldN == 0) stopPerf();
    }
    void sustain (bool on, const Params& p)
    {
        sustainPedal = on;
        if (! on)
        {
            for (int k = 0; k < heldN;) { if (held[k].pedalHeld) { releaseHeld (held[k]); removeAt (k); } else ++k; }
            if (heldN == 0 && ! p.hold) stopPerf();
        }
    }
    void allOff()
    {
        for (auto& v : voices) v.stop(); bass.stop(); heldN = 0; evCount = 0; arpOn = false; patOn = false;
        for (int n = 0; n < 128; ++n) if (outCnt[n] > 0) { outCnt[n] = 0; emit (0x80, n, 0); }
        if (bassOutNote >= 0) { emit (0x81, bassOutNote, 0); bassOutNote = -1; }
    }
    void pitchBend (float semis) { bend = std::pow (2.f, semis / 12.f); }
    void modWheel (float v) { mod = v; }
    void resetVoiceLeading() { prevN = 0; }

    // ---- audio ----
    void render (float* L, float* R, int n, const Params& p)
    {
        const float bpm = p.hostBpm > 0 ? p.hostBpm : p.tempo;
        static const float dTimes[] = { 1.f, 0.75f, 0.5f, 0.25f, 2.f / 3.f };
        const float dTarget = std::min (2.5f, 60.f / bpm * dTimes[std::min (4, std::max (0, p.delayTime))]) * sr;
        const float volTarget = p.volume * p.volume * 1.4f;
        if (! smInit) { smVol = volTarget; smDel = dTarget; smCh = p.chorus; smDm = p.delayMix; smRm = p.reverbMix; smCut = p.cutoff; smDrv = p.drive; smPh = p.phaser; smFl = p.flanger; smInit = true; }
        uint64_t notesLo = 0, notesHi = 0;
        const float thr = 0.89f; // -1 dBFS
        handleLoopCmd (p);

        const double qPerSample = bpm / 60.0 * 4.0 / sr;
        for (int i = 0; i < n; ++i)
        {
            const uint64_t t = nowS + (uint64_t) i;
            curT = t;
            drums.clock (p, bpm, p.hostPpqValid ? p.hostPpq * 4.0 + qPerSample * i : -1.0);
            loopTick (p, i);
            processEvents (t, p);
            if (arpOn) arpTick (t, p, bpm);
            if (patOn) patTick (t, p, bpm);
            // valores suavizados (sin saltos ni "zipper" al mover knobs)
            smVol += smK * (volTarget - smVol); smCh += smK * (p.chorus - smCh);
            smDm += smK * (p.delayMix - smDm); smRm += smK * (p.reverbMix - smRm); smDel += smKd * (dTarget - smDel);
            smCut += smK * (p.cutoff - smCut); smDrv += smK * (p.drive - smDrv); smPh += smK * (p.phaser - smPh); smFl += smK * (p.flanger - smFl);

            lfoPh += 5.6f / sr; if (lfoPh >= 1.f) lfoPh -= 1.f;
            lfo2 += (0.35f + 3.5f * p.movement) / sr; if (lfo2 >= 1.f) lfo2 -= 1.f;
            const float vib = std::sin (kTwoPi * lfoPh) * mod * 0.012f;
            const float ls = std::sin (kTwoPi * lfo2);
            float s = 0.f;
            for (auto& v : voices) if (v.active) s += v.render (p, sr, bend, vib, ls);
            const float b = bass.render (p, sr, bend);

            // saturación
            if (smDrv > 0.002f)
            {
                const float g = 1.f + 12.f * smDrv;
                s = s * (1.f - smDrv) + std::tanh (s * g) / std::pow (g, 0.7f) * smDrv;
            }
            // filtro general (pasa bajos)
            if (smCut < 0.995f)
            {
                if ((i & 7) == 0) { const float fc = 30.f * std::pow (600.f, smCut); cutF1.set (fc, 0.25f, sr); cutF2.set (fc, 0.05f, sr); }
                s = cutF2.lp (cutF1.lp (s));
            }
            else { cutF1.reset(); cutF2.reset(); }
            // faser
            if (smPh > 0.002f)
            {
                phLfo += 0.28f / sr; if (phLfo >= 1.f) phLfo -= 1.f;
                const float a = 0.5f + 0.45f * std::sin (kTwoPi * phLfo);
                float x = s + phFb * 0.6f;
                for (int k = 0; k < 6; ++k) { const float y = -a * x + apS[k]; apS[k] = x + a * y; x = y; }
                phFb = x;
                s = s * (1.f - 0.5f * smPh) + x * smPh * 0.7f;
            }
            // flanger
            flDl.push (s + flFb * 0.65f * smFl);
            if (smFl > 0.002f)
            {
                flLfo += 0.12f / sr; if (flLfo >= 1.f) flLfo -= 1.f;
                const float d = (0.0012f + 0.0045f * (0.5f + 0.5f * std::sin (kTwoPi * flLfo))) * sr;
                const float w = flDl.tap (d); flFb = w;
                s = s * (1.f - 0.4f * smFl) + w * 0.6f * smFl;
            }

            // chorus estéreo
            chPh += 0.52f / sr; if (chPh >= 1.f) chPh -= 1.f;
            chL.push (s); chR.push (s);
            const float dl = (0.0068f + 0.0019f * std::sin (kTwoPi * chPh)) * sr;
            const float dr = (0.0074f + 0.0019f * std::sin (kTwoPi * (chPh + 0.37f))) * sr;
            float l = s * (1.f - 0.35f * smCh) + chL.tap (dl) * 0.8f * smCh;
            float r = s * (1.f - 0.35f * smCh) + chR.tap (dr) * 0.8f * smCh;

            // delay ping-pong
            const float dIn = (l + r) * 0.5f;
            const float tapL = dlL.tap (smDel), tapR = dlR.tap (smDel);
            dlLp += 0.35f * (tapL - dlLp); dlRp += 0.35f * (tapR - dlRp);
            dlL.push (dIn + dlRp * p.delayFb); dlR.push (dlLp * p.delayFb);
            l += tapL * smDm * 1.2f; r += tapR * smDm * 1.2f;

            // reverb
            float rl, rr; rev.process (l, r, p.reverbSize, rl, rr);
            float dL = 0, dR = 0; drums.render (p, dL, dR);
            if (p.drumVerb > 0.002f) { float xl, xr; drumRev.process (dL, dR, 0.55f, xl, xr); dL += xl * p.drumVerb * 1.6f; dR += xr * p.drumVerb * 1.6f; }
            l = (l * (1.f - 0.4f * smRm) + rl * smRm * 1.3f + b) * smVol + dL;
            r = (r * (1.f - 0.4f * smRm) + rr * smRm * 1.3f + b) * smVol + dR;

            // limitador de salida: baja el volumen solo en los picos, sin distorsionar
            const float pk = std::max (std::fabs (l), std::fabs (r));
            const float target = pk > thr ? thr / pk : 1.f;
            if (target < limGain) limGain = target; else limGain += limRel * (target - limGain);
            L[i] = std::max (-1.f, std::min (1.f, l * limGain));
            R[i] = std::max (-1.f, std::min (1.f, r * limGain));
        }
        nowS += (uint64_t) n; curT = nowS;
        for (auto& v : voices) if (v.active && ! v.released) { if (v.note < 64) notesLo |= (1ull << v.note); else if (v.note < 128) notesHi |= (1ull << (v.note - 64)); }
        uiNotesLo.store (notesLo); uiNotesHi.store (notesHi); uiLimit.store (limGain);
        uiLoopState.store (loopState); uiLoopLayers.store (loopLayers); uiLoopEvents.store (loopN);
        uiLoopPos.store (loopLen > 0 ? (float) loopPos / (float) loopLen : 0.f);
    }
    std::atomic<float> uiLimit { 1.f };
    DrumKit drums;

    // acorde (sin voice leading): raíz desde la tecla, intervalos según los botones, voicing
    Chord buildChord (int key, const Params& p, int mask) const
    {
        const uint32_t m = chordIntervals (key % 12, mask, p.key, p.scale, p.complexity);
        const int root = (p.followOct ? key : 48 + key % 12) + 12 * p.octave;
        int arr[24]; int n = 0;
        for (int i = 0; i < 24; ++i) if ((m >> i) & 1u) arr[n++] = root + i;
        if (n > 8) n = 8;
        rotate (arr, n, p.voicing);
        Chord c; for (int k = 0; k < n; ++k) c.add (std::min (120, std::max (12, arr[k])));
        return c;
    }
    // con voice leading: elige la inversión que menos se mueve respecto del acorde anterior
    Chord voiceChord (int key, const Params& p, int mask)
    {
        const uint32_t m = chordIntervals (key % 12, mask, p.key, p.scale, p.complexity);
        const int root = (p.followOct ? key : 48 + key % 12) + 12 * p.octave;
        int arr[24]; int n = 0;
        for (int i = 0; i < 24; ++i) if ((m >> i) & 1u) arr[n++] = root + i;
        if (n > 8) n = 8;
        if (p.voiceLead && prevN > 0)
        {
            int best[8]; int bestCost = 1 << 30;
            for (int inv = -n; inv <= n; ++inv)
            {
                int c[8]; for (int k = 0; k < n; ++k) c[k] = arr[k];
                rotate (c, n, inv);
                if (c[0] < 28 || c[n - 1] > 100) continue;
                int cost = 0;
                for (int a = 0; a < n; ++a) { int d = 999; for (int b = 0; b < prevN; ++b) d = std::min (d, std::abs (c[a] - prev[b])); cost += d; }
                for (int b = 0; b < prevN; ++b) { int d = 999; for (int a = 0; a < n; ++a) d = std::min (d, std::abs (c[a] - prev[b])); cost += d; }
                cost = cost * 4 + std::abs (inv); // a igual movimiento, la más cercana a la posición fundamental
                if (cost < bestCost) { bestCost = cost; for (int k = 0; k < n; ++k) best[k] = c[k]; }
            }
            if (bestCost < (1 << 30)) for (int k = 0; k < n; ++k) arr[k] = best[k];
        }
        for (int k = 0; k < n; ++k) prev[k] = arr[k]; prevN = n;
        rotate (arr, n, p.voicing);
        Chord c; for (int k = 0; k < n; ++k) c.add (std::min (120, std::max (12, arr[k])));
        return c;
    }
    static void rotate (int* arr, int n, int v)
    {
        if (n < 1) return;
        while (v > 0) { const int x = arr[0]; for (int k = 0; k < n - 1; ++k) arr[k] = arr[k + 1]; arr[n - 1] = x + 12; --v; }
        while (v < 0) { const int x = arr[n - 1]; for (int k = n - 1; k > 0; --k) arr[k] = arr[k - 1]; arr[0] = x - 12; ++v; }
    }

    // ---- looper: datos para exportar a MIDI (los copia el procesador desde el hilo de audio) ----
    struct LoopEv { uint32_t pos; uint8_t key, vel; bool on; bool fresh; uint16_t mask; uint8_t layer; };
    static constexpr int kMaxLoop = 4096;
    LoopEv loopEv[kMaxLoop]; int loopN = 0; uint32_t loopLen = 0; float loopBpm = 120.f;

private:
    static constexpr int kMaxHeld = 16;
    struct Ev { uint64_t t; int type; int note; float vel; uint32_t tag; };
    struct Held { int key = 0; float vel = 0; uint32_t tag = 0; Chord notes; bool pedalHeld = false; };

    float sr = 48000.f, bend = 1.f, mod = 0.f, lfoPh = 0, lfo2 = 0, chPh = 0, dlLp = 0, dlRp = 0;
    float smK = 0.001f, smKd = 0.0001f, smVol = 1, smDel = 0, smCh = 0, smDm = 0, smRm = 0; bool smInit = false;
    float smCut = 1, smDrv = 0, smPh = 0, smFl = 0, phLfo = 0, phFb = 0, apS[6] {}, flLfo = 0, flFb = 0;
    Svf cutF1, cutF2; DelayLine flDl; Reverb drumRev;
    float limGain = 1.f, limRel = 0.0001f;
    uint64_t nowS = 0, ageCtr = 0, curT = 0; uint32_t tagCounter = 1;
    std::array<Voice, kMaxVoices> voices; Bass bass;
    Ev evs[kMaxEvents]; int evCount = 0;
    Held held[kMaxHeld]; int heldN = 0;
    bool sustainPedal = false, strumDown = false;
    bool arpOn = false; uint64_t arpNext = 0, arpOffAt = 0; int arpIdx = 0; uint32_t arpVoiceTag = 0;
    bool patOn = false; uint64_t patNext = 0; int patStep = 0; uint32_t patTag = 0;
    int prev[8] {}; int prevN = 0;
    int ksHeld = 0, ksThird = 0;
    int outCnt[128] {}; int bassOutNote = -1;
    DelayLine chL, chR, dlL, dlR; Reverb rev; Rng rng;
    // looper
    int loopState = L_Empty, loopLayers = 0, loopIdx = 0, loopLayer = 0; uint32_t loopPos = 0;
    bool playOn[128] {}; uint16_t userOn[128] {};

    int bassNote (int key, const Params& p) const
    {
        int bn = (p.followOct ? key : 48 + key % 12) + 12 * p.octave - 12 * (p.bassOct + 1);
        while (bn < 28) bn += 12;
        return bn;
    }
    // ---- salida MIDI ----
    void emit (uint8_t st, int note, int vel)
    {
        if (! midiOutOn || outN >= kMaxOut) return;
        outEv[outN++] = { curT, st, (uint8_t) (note & 127), (uint8_t) std::max (0, std::min (127, vel)) };
    }
    void emitOn (int note, float vel) { note &= 127; if (outCnt[note] > 0) emit (0x80, note, 0); ++outCnt[note]; emit (0x90, note, std::max (1, (int) (vel * 127.f))); }
    void emitOff (int note) { note &= 127; if (outCnt[note] > 0 && --outCnt[note] == 0) emit (0x80, note, 0); }
    void emitBass (int note, int vel) { if (bassOutNote >= 0) emit (0x81, bassOutNote, 0); bassOutNote = note & 127; emit (0x91, note, vel); }

    void stopPerf()
    {
        arpOn = false; if (arpVoiceTag) { stopTag (arpVoiceTag); arpVoiceTag = 0; }
        patOn = false; if (patTag) { stopTag (patTag); patTag = 0; } uiPatStep.store (-1);
    }
    void pushEv (uint64_t t, int type, int note, float vel, uint32_t tag)
    {
        if (evCount >= kMaxEvents) return;
        evs[evCount++] = { t, type, note, vel, tag };
    }
    void processEvents (uint64_t t, const Params& p)
    {
        for (int k = 0; k < evCount;)
        {
            if (evs[k].t <= t)
            {
                const Ev e = evs[k]; evs[k] = evs[--evCount];
                if (e.type == 1) startVoice (e.note, e.vel, e.tag, p);
                else if (e.type == 2) { bass.start (e.note, e.vel, e.tag, sr, p.bassSound); emitBass (e.note, std::max (1, (int) (e.vel * 127.f))); }
            }
            else ++k;
        }
    }
    void startVoice (int note, float vel, uint32_t tag, const Params& p)
    {
        // 1) la misma nota del mismo acorde, 2) una voz libre, 3) la voz soltada más baja, 4) la más baja de todas
        Voice* best = nullptr;
        for (auto& v : voices) if (v.active && v.note == note && v.tag == tag) { best = &v; break; }
        if (! best) for (auto& v : voices) if (! v.active) { best = &v; break; }
        if (! best) { float lo = 1e9f; for (auto& v : voices) if (v.released && v.amp.v < lo) { lo = v.amp.v; best = &v; } }
        if (! best) { float lo = 1e9f; for (auto& v : voices) if (v.amp.v < lo) { lo = v.amp.v; best = &v; } }
        if (best->active && ! best->released) emitOff (best->note);
        best->gainMul = 0.3f;
        best->start (note, vel, tag, ++ageCtr, p, sr);
        emitOn (note, vel);
    }
    void stopTag (uint32_t tag)
    {
        for (auto& v : voices) if (v.active && v.tag == tag) { if (! v.released) emitOff (v.note); v.stop(); }
        if (bass.active && bass.tag == tag) { bass.stop(); if (bassOutNote >= 0) { emit (0x81, bassOutNote, 0); bassOutNote = -1; } }
    }
    void releaseHeld (Held& h)
    {
        stopTag (h.tag);
        for (int k = 0; k < evCount;) { if (evs[k].tag == h.tag) evs[k] = evs[--evCount]; else ++k; } // cancela notas pendientes de un strum
    }
    void removeAt (int i) { for (int k = i; k < heldN - 1; ++k) held[k] = held[k + 1]; --heldN; }
    void removeHeld (int key) { for (int k = 0; k < heldN;) { if (held[k].key == key) removeAt (k); else ++k; } }

    void arpTick (uint64_t t, const Params& p, float bpm)
    {
        if (arpVoiceTag && t >= arpOffAt) { stopTag (arpVoiceTag); arpVoiceTag = 0; }
        if (t < arpNext) return;
        // notas disponibles: todas las de los acordes sostenidos, ordenadas y sin repetir, en N octavas
        bool has[128] {}; int pool[128]; int pc = 0;
        for (int k = 0; k < heldN; ++k) for (int i = 0; i < held[k].notes.n; ++i) has[held[k].notes.v[i] & 127] = true;
        for (int m = 0; m < 128; ++m) if (has[m]) pool[pc++] = m;
        if (pc == 0) { arpOn = false; return; }
        const int oct = std::max (1, std::min (4, p.arpOct)), n = pc * oct;
        int idx = 0;
        switch (p.arpPattern)
        {
            case 1: idx = (n - 1) - (arpIdx % n); ++arpIdx; break;
            case 2: { if (n < 2) { idx = 0; break; } const int per = 2 * n - 2; const int k = arpIdx % per; idx = k < n ? k : per - k; ++arpIdx; break; }
            case 3: idx = (int) (rng.uni() * (float) n) % n; break;
            default: idx = arpIdx % n; ++arpIdx; break;
        }
        const int note = std::min (120, pool[idx % pc] + 12 * (idx / pc));
        static const float rates[] = { 1.f, 0.5f, 1.f / 3.f, 0.25f, 1.f / 6.f, 0.125f };
        const float stepS = 60.f / bpm * rates[std::min (5, std::max (0, p.arpRate))];
        const uint32_t tag = tagCounter++;
        startVoice (note, heldN ? held[heldN - 1].vel : 0.8f, tag, p);
        arpVoiceTag = tag;
        arpOffAt = t + (uint64_t) (stepS * p.arpGate * sr);
        arpNext = t + (uint64_t) (stepS * sr);
    }
    // modo PATRÓN: repite el último acorde con un ritmo de 16 pasos
    void patTick (uint64_t t, const Params& p, float bpm)
    {
        if (t < patNext) return;
        if (heldN == 0) { stopPerf(); return; }
        const char c = rhythmPattern (p.rhythm)[patStep & 15];
        uiPatStep.store (patStep & 15);
        if (c == 'X' || c == 'x' || c == '.')
        {
            if (patTag) { stopTag (patTag); patTag = 0; }
            if (c != '.')
            {
                const Held& H = held[heldN - 1];
                const uint32_t tag = tagCounter++;
                const float v = H.vel * (c == 'X' ? 1.f : 0.78f);
                for (int i = 0; i < H.notes.n; ++i) startVoice (H.notes.v[i], v, tag, p);
                patTag = tag;
            }
        }
        patStep = (patStep + 1) & 15;
        patNext = t + (uint64_t) (60.f / bpm * 0.25f * sr);
    }

    void publishChord (int key, const Params& p, int mask)
    {
        if (p.mode != 0) { uiRoot.store (key); uiIv.store (0); return; }
        uiIv.store (chordIntervals (key % 12, mask, p.key, p.scale, p.complexity));
        uiMask.store (mask);
        uiRoot.store (key % 12);
    }

    // ---- looper ----
    void handleLoopCmd (const Params& p)
    {
        const int c = loopCmd.exchange (0);
        if (c == 1) // grabar / sobregrabar
        {
            if (loopState == L_Empty) loopState = L_Armed;
            else if (loopState == L_Armed) loopState = L_Empty;
            else if (loopState == L_Rec) { finishPassHeld(); loopState = L_Play; }
            else if (loopState == L_Play) { loopLayer = ++loopLayers; loopState = L_Dub; }
            else if (loopState == L_Dub) { finishPassHeld(); clearFresh(); loopState = L_Play; }
            else if (loopState == L_Stop) { loopLayer = ++loopLayers; loopPos = 0; loopIdx = 0; loopState = L_Dub; }
        }
        else if (c == 2) // play / parar
        {
            if (loopState == L_Play || loopState == L_Dub || loopState == L_Rec) { if (loopState != L_Play) { finishPassHeld(); clearFresh(); } releasePlayback (p); loopState = L_Stop; }
            else if (loopState == L_Stop) { loopPos = 0; loopIdx = 0; loopState = L_Play; }
            else if (loopState == L_Armed) loopState = L_Empty;
        }
        else if (c == 3) // deshacer la última capa
        {
            if (loopN == 0) return;
            int top = 0; for (int k = 0; k < loopN; ++k) top = std::max (top, (int) loopEv[k].layer);
            releasePlayback (p);
            int w = 0; for (int k = 0; k < loopN; ++k) if (loopEv[k].layer != top) loopEv[w++] = loopEv[k];
            loopN = w; loopLayers = std::max (0, top - 1);
            if (loopState == L_Dub) { loopLayer = ++loopLayers; }
            loopIdx = 0; while (loopIdx < loopN && loopEv[loopIdx].pos < loopPos) ++loopIdx;
            if (loopN == 0 && loopState != L_Dub) { loopState = L_Empty; loopLen = 0; loopPos = 0; }
        }
        else if (c == 4) // borrar todo
        {
            releasePlayback (p);
            loopN = 0; loopLayers = 0; loopState = L_Empty; loopLen = 0; loopPos = 0; loopIdx = 0;
        }
    }
    void startLoopRec (const Params& p)
    {
        const float bpm = p.hostBpm > 0 ? p.hostBpm : p.tempo;
        const int bars = std::max (1, std::min (16, p.loopBars));
        loopBpm = bpm;
        loopLen = (uint32_t) (bars * 4.0 * 60.0 / bpm * sr);
        loopN = 0; loopLayers = 0; loopLayer = 0; loopPos = 0; loopIdx = 0; loopState = L_Rec;
    }
    void recordEv (int key, float vel, bool on, int mask, const Params& p)
    {
        if (loopN >= kMaxLoop || loopLen == 0) return;
        uint32_t pos = loopPos;
        if (on && p.loopQuant) // cuantiza a semicorcheas
        {
            const double step = 60.0 / loopBpm * 0.25 * sr;
            pos = (uint32_t) (std::floor ((double) pos / step + 0.5) * step);
            if (pos >= loopLen) pos = 0;
        }
        insertEv ({ pos, (uint8_t) (key & 127), (uint8_t) std::max (1, (int) (vel * 127.f)), on, true, (uint16_t) mask, (uint8_t) loopLayer });
    }
    void insertEv (const LoopEv& e)
    {
        if (loopN >= kMaxLoop) return;
        int i = loopN; while (i > 0 && loopEv[i - 1].pos > e.pos) { loopEv[i] = loopEv[i - 1]; --i; }
        loopEv[i] = e; ++loopN;
        if (i < loopIdx) ++loopIdx;
    }
    // notas que la persona sigue apretando al terminar una vuelta: se cierran al final del loop
    void finishPassHeld()
    {
        for (int k = 0; k < 128; ++k) if (userOn[k] && loopN < kMaxLoop)
        { insertEv ({ loopLen > 0 ? loopLen - 1 : 0, (uint8_t) k, 0, false, true, 0, (uint8_t) loopLayer }); userOn[k] = 0; }
    }
    void clearFresh() { for (int k = 0; k < loopN; ++k) loopEv[k].fresh = false; }
    void releasePlayback (const Params& p) { Params pp = p; pp.hold = false; pp.keySwitch = false; for (int k = 0; k < 128; ++k) if (playOn[k]) { playOn[k] = false; noteOff (k, pp, 0); } }
    void loopTick (const Params& p, int /*i*/)
    {
        if (loopState != L_Rec && loopState != L_Play && loopState != L_Dub) return;
        if (loopState != L_Rec) // reproducir
            while (loopIdx < loopN && loopEv[loopIdx].pos <= loopPos)
            {
                const LoopEv& e = loopEv[loopIdx++];
                if (e.fresh) continue;
                Params pp = p; pp.hold = false; pp.keySwitch = false;
                if (e.on) { if (playOn[e.key]) noteOff (e.key, pp, 0); playOn[e.key] = true; noteOn (e.key, e.vel / 127.f, pp, 0, e.mask); }
                else if (playOn[e.key]) { playOn[e.key] = false; noteOff (e.key, pp, 0); }
            }
        if (++loopPos >= loopLen)
        {
            loopPos = 0; loopIdx = 0;
            if (loopState == L_Rec || loopState == L_Dub)
            {
                // lo que sigue apretado: se corta al final y vuelve a empezar al principio de la vuelta siguiente
                const bool keep = loopState == L_Dub;
                for (int k = 0; k < 128; ++k) if (userOn[k])
                {
                    const uint16_t m = (uint16_t) (userOn[k] - 1);
                    insertEv ({ loopLen - 1, (uint8_t) k, 0, false, true, 0, (uint8_t) loopLayer });
                    if (keep) { insertEv ({ 0, (uint8_t) k, 100, true, true, m, (uint8_t) loopLayer }); }
                    else userOn[k] = 0;
                }
                clearFresh();
                if (keep) for (int k = 0; k < loopN; ++k) if (loopEv[k].pos == 0 && loopEv[k].layer == loopLayer && userOn[loopEv[k].key]) loopEv[k].fresh = true;
                if (loopState == L_Rec) loopState = L_Play;
            }
            releasePlayback (p);
        }
    }
};

} // namespace lirio
