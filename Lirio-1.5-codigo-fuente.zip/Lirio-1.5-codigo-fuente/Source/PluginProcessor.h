#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_utils/juce_audio_utils.h>
#include "Engine.h"

class LirioProcessor : public juce::AudioProcessor, private juce::AudioProcessorValueTreeState::Listener
{
public:
    LirioProcessor();
    ~LirioProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Lirio"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return true; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 4.0; }

    int getNumPrograms() override;
    int getCurrentProgram() override { return currentProgram; }
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;
    lirio::Engine engine;
    juce::MidiKeyboardState keyboardState; // teclado en pantalla (también se puede tocar con el ratón)
    // ---- presets propios y candados ----
    juce::File userPresetFolder() const;
    juce::Array<juce::File> userPresets() const;
    bool saveUserPreset (const juce::String& name);
    bool loadUserPreset (const juce::File&);
    juce::File currentUser;
    bool presetMayChange (const juce::String& id) const;
    static const juce::StringArray& perfGroup();
    static const juce::StringArray& fxGroup();
    // ---- looper: exportar a .mid ----
    std::atomic<bool> exportReq { false }, exportReady { false };
    juce::File exportLoopMidi();
    bool hasHostTempo() const { return lastHostBpm.load() > 0; }
    float hostBpm() const { return lastHostBpm.load(); }

    // ---- ritmo ----
    static constexpr int kLanes = 6;
    static const juce::StringArray drumPatternNames, laneNames;
    std::atomic<uint16_t> lanes[kLanes];
    void toggleStep (int lane, int step) { lanes[lane].store ((uint16_t) (lanes[lane].load() ^ (1u << step))); }
    void loadPattern (int index);
    // ---- grabar demo (WAV 24 bits en Documentos/Lirio) ----
    bool startRecording();
    void stopRecording();
    bool isRecording() const { return recording.load(); }
    double recordedSeconds() const { return currentSR > 0 ? (double) recSamples.load() / currentSR : 0.0; }
    juce::File recordFolder() const;
    juce::File lastRecording;

    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    static const char* const chordIds[9];
    static const juce::StringArray chordNames, rhythmNames, bassSoundNames, perfNames, engineNames, keyNames, rateNames, patternNames, delayNames;

private:
    lirio::Params readParams();
    void parameterChanged (const juce::String& id, float value) override;
    int currentProgram = 0;
    void setPresetValue (const juce::String& id, float val);
    std::vector<lirio::Engine::LoopEv> exportEv; uint32_t exportLen = 0; float exportBpm = 120.f; lirio::Params exportParams;
    juce::TimeSliceThread writerThread { "Lirio grabacion" };
    std::unique_ptr<juce::AudioFormatWriter::ThreadedWriter> threaded;
    juce::CriticalSection writerLock;
    juce::AudioFormatWriter::ThreadedWriter* activeWriter = nullptr;
    std::atomic<bool> recording { false };
    std::atomic<juce::int64> recSamples { 0 };
    double currentSR = 48000.0;
    juce::AudioBuffer<float> monoScratch;
    std::atomic<float> lastHostBpm { 0.f };
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LirioProcessor)
};
