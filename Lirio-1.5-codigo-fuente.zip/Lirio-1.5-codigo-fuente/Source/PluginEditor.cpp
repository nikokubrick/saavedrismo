#include "PluginEditor.h"
#include "BinaryData.h"

using namespace juce;
static String U (const char* s) { return String::fromUTF8 (s); }
static StringArray SA (std::initializer_list<const char*> l) { StringArray a; for (auto* s : l) a.add (U (s)); return a; }

// ======================= aspecto =======================
LirioLook::LirioLook()
{
    tDisplay = Typeface::createSystemTypefaceFor (BinaryData::InterDisplayBlack_otf, (size_t) BinaryData::InterDisplayBlack_otfSize);
    tLabel   = Typeface::createSystemTypefaceFor (BinaryData::InterSemiBold_otf, (size_t) BinaryData::InterSemiBold_otfSize);
    tMono    = Typeface::createSystemTypefaceFor (BinaryData::DejaVuSansMonoBold_ttf, (size_t) BinaryData::DejaVuSansMonoBold_ttfSize);
    setDefaultSansSerifTypeface (tLabel);
    setColour (PopupMenu::backgroundColourId, pal::ink);
    setColour (PopupMenu::textColourId, pal::cream);
    setColour (PopupMenu::headerTextColourId, pal::led);
    setColour (PopupMenu::highlightedBackgroundColourId, pal::led);
    setColour (PopupMenu::highlightedTextColourId, pal::ink);
    setColour (ComboBox::textColourId, pal::cream);
    setColour (Label::textColourId, pal::ink);
    setColour (TooltipWindow::backgroundColourId, pal::ink);
    setColour (TooltipWindow::textColourId, pal::cream);
    setColour (AlertWindow::backgroundColourId, pal::body);
    setColour (AlertWindow::textColourId, pal::ink);
    setColour (TextEditor::backgroundColourId, pal::cream);
    setColour (TextEditor::textColourId, pal::ink);
    setColour (TextEditor::outlineColourId, pal::ink);
}
Font LirioLook::display (float h) const { return Font (tDisplay).withHeight (h); }
Font LirioLook::label (float h) const   { return Font (tLabel).withHeight (h); }
Font LirioLook::mono (float h) const    { return Font (tMono).withHeight (h); }

void LirioLook::drawRotarySlider (Graphics& g, int x, int y, int w, int h, float pos, float a0, float a1, Slider& s)
{
    const auto c = s.findColour (Slider::rotarySliderFillColourId);
    const float r = jmin (w, h) * 0.5f - 2.f;
    const Point<float> ctr ((float) x + w * 0.5f, (float) y + h * 0.5f);
    const float ang = a0 + pos * (a1 - a0);
    // marcas grabadas alrededor
    for (int i = 0; i <= 10; ++i)
    {
        const float ta = a0 + (a1 - a0) * (float) i / 10.f;
        g.setColour (pal::ink.withAlpha (i == 0 || i == 10 || i == 5 ? 0.7f : 0.35f));
        g.drawLine (Line<float> (ctr.getPointOnCircumference (r * 0.86f, ta), ctr.getPointOnCircumference (r * (i % 5 == 0 ? 1.0f : 0.95f), ta)), 1.4f);
    }
    // arco de valor (luz ámbar fina)
    Path val; val.addCentredArc (ctr.x, ctr.y, r * 0.78f, r * 0.78f, 0, a0, ang, true);
    g.setColour (pal::ink.withAlpha (0.25f));
    Path tr; tr.addCentredArc (ctr.x, ctr.y, r * 0.78f, r * 0.78f, 0, a0, a1, true); g.strokePath (tr, PathStrokeType (2.6f, PathStrokeType::curved, PathStrokeType::rounded));
    g.setColour (c.interpolatedWith (pal::led, 0.5f)); g.strokePath (val, PathStrokeType (2.6f, PathStrokeType::curved, PathStrokeType::rounded));
    // perilla negra con brillo arriba
    const float br = r * 0.62f;
    g.setColour (Colours::black.withAlpha (0.28f)); g.fillEllipse (ctr.x - br + 1.5f, ctr.y - br + 3.f, br * 2, br * 2);
    ColourGradient gr (Colour (0xff3a3027), ctr.x, ctr.y - br, Colour (0xff100c08), ctr.x, ctr.y + br, false);
    g.setGradientFill (gr); g.fillEllipse (ctr.x - br, ctr.y - br, br * 2, br * 2);
    g.setColour (Colour (0xff4a3e33)); g.drawEllipse (ctr.x - br * 0.8f, ctr.y - br * 0.8f, br * 1.6f, br * 1.6f, 1.f);
    // indicador
    g.setColour (pal::cream);
    g.drawLine (Line<float> (ctr.getPointOnCircumference (br * 0.3f, ang), ctr.getPointOnCircumference (br * 0.88f, ang)), 2.4f);
}

void LirioLook::drawButtonBackground (Graphics& g, Button& b, const Colour&, bool over, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced (2.5f, 3.f).withTrimmedBottom (1.5f);
    const bool on = b.getToggleState();
    const float rad = jmin (r.getHeight() * 0.5f, 12.f);
    if (! down) { g.setColour (Colours::black.withAlpha (0.3f)); g.fillRoundedRectangle (r.translated (0.f, 2.f), rad); }
    else r = r.translated (0.f, 1.f);
    if (on)
    {
        const auto c = b.findColour (TextButton::buttonOnColourId);
        g.setColour (c.withAlpha (0.35f)); g.fillRoundedRectangle (r.expanded (2.f), rad + 2.f); // brillo
        ColourGradient gr (c.brighter (0.25f), r.getX(), r.getY(), c.darker (0.15f), r.getX(), r.getBottom(), false);
        g.setGradientFill (gr); g.fillRoundedRectangle (r, rad);
    }
    else
    {
        ColourGradient gr (Colour (0xff3a2d21).brighter (over ? 0.12f : 0.f), r.getX(), r.getY(), pal::ink, r.getX(), r.getBottom(), false);
        g.setGradientFill (gr); g.fillRoundedRectangle (r, rad);
    }
    g.setColour (Colours::black.withAlpha (0.55f)); g.drawRoundedRectangle (r, rad, 1.f);
}
void LirioLook::drawButtonText (Graphics& g, TextButton& b, bool, bool down)
{
    g.setFont (label (jmin (14.f, b.getHeight() * 0.38f)));
    const bool on = b.getToggleState();
    g.setColour (on ? pal::ink : pal::cream);
    auto r = b.getLocalBounds().reduced (4, 2).translated (0, down ? 1 : 0);
    g.drawFittedText (b.getButtonText(), r, Justification::centred, 1, 0.75f);
}
void LirioLook::drawToggleButton (Graphics& g, ToggleButton& b, bool over, bool)
{
    auto r = b.getLocalBounds().toFloat().reduced (2.f, 3.f);
    const bool on = b.getToggleState();
    const float d = jmin (14.f, r.getHeight() * 0.42f);
    auto lamp = Rectangle<float> (r.getX() + 6.f, r.getCentreY() - d * 0.5f, d, d);
    if (on) { g.setColour (pal::led.withAlpha (0.35f)); g.fillEllipse (lamp.expanded (4.f)); }
    g.setColour (on ? pal::led : Colour (0xff5a4630)); g.fillEllipse (lamp);
    if (on) { g.setColour (Colours::white.withAlpha (0.7f)); g.fillEllipse (lamp.reduced (d * 0.32f).translated (-d * 0.1f, -d * 0.1f)); }
    g.setColour (pal::ink); g.drawEllipse (lamp, 1.3f);
    g.setFont (label (jmin (13.5f, r.getHeight() * 0.42f))); g.setColour (over ? pal::ink.brighter (0.4f) : pal::ink);
    g.drawFittedText (b.getButtonText(), r.withTrimmedLeft (lamp.getRight() - r.getX() + 6.f).toNearestInt(), Justification::centredLeft, 1, 0.7f);
}
void LirioLook::drawComboBox (Graphics& g, int w, int h, bool, int, int, int, int, ComboBox&)
{
    auto r = Rectangle<float> (0, 0, (float) w, (float) h).reduced (2.f, 2.f);
    const float rad = jmin (r.getHeight() * 0.5f, 10.f);
    g.setColour (Colours::black.withAlpha (0.25f)); g.fillRoundedRectangle (r.translated (0.f, 1.5f), rad);
    g.setColour (pal::ink); g.fillRoundedRectangle (r, rad);
    g.setColour (Colours::black.withAlpha (0.5f)); g.drawRoundedRectangle (r, rad, 1.f);
    Path tri; const float cx = r.getRight() - r.getHeight() * 0.55f, cy = r.getCentreY();
    tri.addTriangle (cx - 4.5f, cy - 2.5f, cx + 4.5f, cy - 2.5f, cx, cy + 3.5f); g.setColour (pal::led); g.fillPath (tri);
}
Label* LirioLook::createSliderTextBox (Slider& s)
{
    auto* l = LookAndFeel_V4::createSliderTextBox (s);
    l->setColour (Label::textColourId, pal::ink); l->setColour (Label::backgroundColourId, Colours::transparentBlack);
    l->setColour (Label::outlineColourId, Colours::transparentBlack); l->setFont (label (12.f)); l->setJustificationType (Justification::centred);
    return l;
}
void LirioLook::drawLabel (Graphics& g, Label& l)
{
    if (! l.isBeingEdited())
    {
        g.setColour (l.findColour (Label::textColourId)); g.setFont (label (12.f));
        g.drawFittedText (l.getText(), l.getLocalBounds(), l.getJustificationType(), 1, 0.8f);
    }
}

// ======================= knob =======================
Knob::Knob (AudioProcessorValueTreeState& s, const String& id, const String& text, Colour c) : name (text), colour (c)
{
    slider.setColour (Slider::textBoxTextColourId, pal::ink); slider.setColour (Slider::textBoxOutlineColourId, Colours::transparentBlack); slider.setColour (Slider::textBoxBackgroundColourId, Colours::transparentBlack);
    slider.setSliderStyle (Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle (Slider::TextBoxBelow, false, 70, 16);
    slider.setColour (Slider::rotarySliderFillColourId, c);
    slider.setRotaryParameters (MathConstants<float>::pi * 1.2f, MathConstants<float>::pi * 2.8f, true);
    slider.setPopupDisplayEnabled (false, false, nullptr);
    addAndMakeVisible (slider);
    att = std::make_unique<AudioProcessorValueTreeState::SliderAttachment> (s, id, slider);
    slider.setDoubleClickReturnValue (true, s.getParameter (id)->convertFrom0to1 (s.getParameter (id)->getDefaultValue()));
}
void Knob::resized() { slider.setBounds (getLocalBounds().withTrimmedTop (18)); }
void Knob::paint (Graphics& g)
{
    auto* lf = dynamic_cast<LirioLook*> (&getLookAndFeel());
    g.setFont (lf ? lf->label (11.5f) : Font (11.5f)); g.setColour (pal::ink);
    g.drawFittedText (name, getLocalBounds().removeFromTop (18), Justification::centred, 1, 0.75f);
}

// ======================= píldoras =======================
Pills::Pills (AudioProcessorValueTreeState& s, const String& id, const StringArray& items, int columns, bool rainbow, std::function<void()> onPick)
    : param (s.getParameter (id)), cols (columns), picked (std::move (onPick))
{
    for (int i = 0; i < items.size(); ++i)
    {
        auto* b = buttons.add (new TextButton (items[i]));
        b->setClickingTogglesState (false);
        b->setColour (TextButton::buttonOnColourId, rainbow ? pal::rainbow (i) : pal::led);
        b->onClick = [this, i] {
            const int n = buttons.size();
            param->beginChangeGesture(); param->setValueNotifyingHost (n > 1 ? (float) i / (float) (n - 1) : 0.f); param->endChangeGesture();
            if (picked) picked(); sync(); };
        addAndMakeVisible (b);
    }
    sync();
}
void Pills::resized()
{
    const int n = buttons.size(), rows = (n + cols - 1) / cols;
    const float bw = getWidth() / (float) cols, bh = getHeight() / (float) rows;
    for (int i = 0; i < n; ++i) buttons[i]->setBounds (Rectangle<float> ((i % cols) * bw, (i / cols) * bh, bw, bh).reduced (3.f, 2.f).toNearestInt());
}
void Pills::sync()
{
    const int n = buttons.size();
    const int idx = n > 1 ? roundToInt (param->getValue() * (n - 1)) : 0;
    for (int i = 0; i < n; ++i) if (buttons[i]->getToggleState() != (i == idx)) buttons[i]->setToggleState (i == idx, dontSendNotification);
}

// ======================= teclado =======================
static bool isBlack (int m) { const int k = m % 12; return k == 1 || k == 3 || k == 6 || k == 8 || k == 10; }
void Keys::paint (Graphics& g)
{
    const auto lo64 = proc.engine.uiNotesLo.load(), hi64 = proc.engine.uiNotesHi.load();
    auto sounding = [&] (int m) { return m < 64 ? ((lo64 >> m) & 1ull) : ((hi64 >> (m - 64)) & 1ull); };
    auto r = getLocalBounds().toFloat();
    g.setColour (Colour (0xff17110c)); g.fillRoundedRectangle (r, 10.f);
    r = r.reduced (8.f, 7.f);
    int whites = 0; for (int m = lo; m <= hi; ++m) if (! isBlack (m)) ++whites;
    const float kw = r.getWidth() / (float) whites;
    int wi = 0;
    for (int m = lo; m <= hi; ++m) if (! isBlack (m))
    {
        auto k = Rectangle<float> (r.getX() + wi * kw, r.getY(), kw - 2.f, r.getHeight());
        const bool on = sounding (m) || proc.keyboardState.isNoteOnForChannels (0xffff, m);
        g.setColour (on ? pal::led : pal::cream); g.fillRoundedRectangle (k, 4.f);
        if (m % 12 == 0) { g.setColour (pal::ink.withAlpha (0.5f)); g.setFont (Font (10.f)); g.drawText ("C" + String (m / 12 - 1), k.removeFromBottom (14.f), Justification::centred); }
        ++wi;
    }
    wi = 0;
    for (int m = lo; m <= hi; ++m)
    {
        if (! isBlack (m)) { ++wi; continue; }
        auto k = Rectangle<float> (r.getX() + wi * kw - kw * 0.32f, r.getY(), kw * 0.62f, r.getHeight() * 0.6f);
        const bool on = sounding (m) || proc.keyboardState.isNoteOnForChannels (0xffff, m);
        g.setColour (on ? pal::led : pal::ink); g.fillRoundedRectangle (k, 3.f);
        g.setColour (pal::ink); g.drawRoundedRectangle (k, 4.f, 1.5f);
    }
}
int Keys::noteAt (Point<float> p) const
{
    auto r = getLocalBounds().toFloat().reduced (8.f, 7.f);
    int whites = 0; for (int m = lo; m <= hi; ++m) if (! isBlack (m)) ++whites;
    const float kw = r.getWidth() / (float) whites;
    if (p.y < r.getY() + r.getHeight() * 0.6f)
    {
        int wi = 0; for (int m = lo; m <= hi; ++m) { if (! isBlack (m)) { ++wi; continue; }
            const float x0 = r.getX() + wi * kw - kw * 0.32f; if (p.x >= x0 && p.x <= x0 + kw * 0.62f) return m; }
    }
    const int idx = jlimit (0, whites - 1, (int) ((p.x - r.getX()) / kw));
    int wi = 0; for (int m = lo; m <= hi; ++m) if (! isBlack (m)) { if (wi == idx) return m; ++wi; }
    return -1;
}
void Keys::mouseDown (const MouseEvent& e) { down = noteAt (e.position); if (down >= 0) proc.keyboardState.noteOn (1, down, 0.8f); }
void Keys::mouseDrag (const MouseEvent& e) { const int n = noteAt (e.position); if (n != down && n >= 0) { if (down >= 0) proc.keyboardState.noteOff (1, down, 0.f); down = n; proc.keyboardState.noteOn (1, n, 0.8f); } }
void Keys::mouseUp (const MouseEvent&) { if (down >= 0) proc.keyboardState.noteOff (1, down, 0.f); down = -1; }

// ======================= grilla de ritmo =======================
void DrumGrid::paint (Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    const int L = LirioProcessor::kLanes; const float lh = r.getHeight() / (float) L;
    const float cw = (r.getWidth() - labelW) / 16.f;
    const int cur = proc.engine.drums.uiStep.load();
    auto* lf = dynamic_cast<LirioLook*> (&getLookAndFeel());
    for (int l = 0; l < L; ++l)
    {
        const float y = r.getY() + l * lh;
        g.setColour (pal::ink); g.setFont (lf ? lf->label (12.5f) : Font (12.5f));
        g.drawText (LirioProcessor::laneNames[l], Rectangle<float> (0.f, y, (float) labelW - 6.f, lh), Justification::centredRight);
        const uint16_t mask = proc.lanes[l].load();
        for (int s = 0; s < 16; ++s)
        {
            auto c = Rectangle<float> (labelW + s * cw, y, cw, lh).reduced (1.5f, 1.5f);
            const bool on = (mask >> s) & 1u;
            if (on) { g.setColour (pal::led.withAlpha (0.3f)); g.fillRoundedRectangle (c.expanded (1.5f), 5.f); }
            g.setColour (on ? (l == 0 ? pal::led : l == 1 ? pal::cream : l == 2 ? pal::orange : pal::lemon) : (s / 4) % 2 ? Colour (0xff3a2d21) : Colour (0xff2c2219));
            g.fillRoundedRectangle (c, 4.f);
            g.setColour (s == cur ? pal::cream : Colours::black.withAlpha (0.5f));
            g.drawRoundedRectangle (c, 4.f, s == cur ? 2.2f : 1.f);
        }
    }
}
bool DrumGrid::cellAt (Point<float> p, int& lane, int& step) const
{
    const int L = LirioProcessor::kLanes; const float lh = getHeight() / (float) L, cw = (getWidth() - labelW) / 16.f;
    if (p.x < labelW) return false;
    lane = jlimit (0, L - 1, (int) (p.y / lh)); step = jlimit (0, 15, (int) ((p.x - labelW) / cw)); return true;
}
void DrumGrid::mouseDown (const MouseEvent& ev)
{
    int l, s; if (! cellAt (ev.position, l, s)) return;
    paintValue = ! ((proc.lanes[l].load() >> s) & 1u);
    proc.toggleStep (l, s); lastLane = l; lastStep = s; repaint();
}
void DrumGrid::mouseDrag (const MouseEvent& ev)
{
    int l, s; if (! cellAt (ev.position, l, s) || (l == lastLane && s == lastStep)) return;
    lastLane = l; lastStep = s;
    const bool on = (proc.lanes[l].load() >> s) & 1u;
    if (on != paintValue) proc.toggleStep (l, s);
    repaint();
}

// ======================= tempo =======================
TempoBox::TempoBox (LirioProcessor& p) : proc (p), param (p.apvts.getParameter ("tempo"))
{
    for (auto* b : { &minus, &tap, &plus }) { addAndMakeVisible (b); b->setColour (TextButton::buttonOnColourId, pal::led); }
    minus.setRepeatSpeed (450, 70); plus.setRepeatSpeed (450, 70);
    minus.onClick = [this] { setBpm ((float) std::round (bpm()) - 1.f); };
    plus.onClick  = [this] { setBpm ((float) std::round (bpm()) + 1.f); };
    tap.onClick   = [this] { tapped(); };
    minus.setTooltip (U ("Bajar 1 BPM (mantené apretado para bajar rápido)"));
    plus.setTooltip (U ("Subir 1 BPM (mantené apretado para subir rápido)"));
    tap.setTooltip (U ("Tocalo varias veces al ritmo que quieras y Lirio toma ese tempo"));
    typer.setJustification (Justification::centred);
    typer.setInputRestrictions (5, "0123456789.,");
    typer.setColour (TextEditor::backgroundColourId, pal::ink);
    typer.setColour (TextEditor::textColourId, pal::lemon);
    typer.setColour (TextEditor::outlineColourId, pal::pink);
    typer.setColour (TextEditor::focusedOutlineColourId, pal::pink);
    typer.setColour (TextEditor::highlightColourId, pal::pink.withAlpha (0.5f));
    typer.setColour (CaretComponent::caretColourId, pal::lemon);
    auto close = [this] (bool apply)
    {
        if (! typer.isVisible()) return;
        if (apply) { const float v = typer.getText().replaceCharacter (',', '.').getFloatValue(); if (v > 0.f) setBpm (v); }
        typer.setVisible (false); repaint();
    };
    typer.onReturnKey = [close] { close (true); };
    typer.onEscapeKey = [close] { close (false); };
    typer.onFocusLost = [close] { close (true); };
    addChildComponent (typer);
    setTooltip (U ("Tempo de Lirio: arrastrá el número arriba/abajo, usá la rueda del mouse o hacé doble clic para escribirlo. Mueve el ritmo, el arpegio y el delay."));
}
bool TempoBox::editable() const { return proc.wrapperType == AudioProcessor::wrapperType_Standalone || ! proc.hasHostTempo(); }
float TempoBox::bpm() const { return editable() ? param->convertFrom0to1 (param->getValue()) : proc.hostBpm(); }
void TempoBox::setBpm (float v)
{
    if (! editable()) return;
    v = jlimit (40.f, 220.f, std::round (v * 10.f) / 10.f);
    param->beginChangeGesture(); param->setValueNotifyingHost (param->convertTo0to1 (v)); param->endChangeGesture();
    refresh(); repaint();
}
void TempoBox::tapped()
{
    const double now = Time::getMillisecondCounterHiRes();
    if (tapN > 0 && now - taps[tapN - 1] > 2000.0) tapN = 0; // pausa larga: empieza de nuevo
    if (tapN == 6) { for (int i = 1; i < 6; ++i) taps[i - 1] = taps[i]; tapN = 5; }
    taps[tapN++] = now;
    if (tapN >= 2) setBpm ((float) std::round (60000.0 * (tapN - 1) / (taps[tapN - 1] - taps[0])));
}
void TempoBox::resized()
{
    const int w = getWidth(), y = 64, h = getHeight() - y;
    minus.setBounds (0, y, 40, h); tap.setBounds (40, y, w - 80, h); plus.setBounds (w - 40, y, 40, h);
    typer.setBounds (numberArea().reduced (8, 3));
    if (auto* lf = dynamic_cast<LirioLook*> (&getLookAndFeel())) typer.setFont (lf->display (24.f));
}
void TempoBox::paint (Graphics& g)
{
    auto* lf = dynamic_cast<LirioLook*> (&getLookAndFeel());
    auto font = [lf] (bool disp, float h) { return lf ? (disp ? lf->display (h) : lf->label (h)) : Font (h); };
    const bool ed = editable();
    g.setFont (font (false, 12.f)); g.setColour (pal::ink);
    g.drawText ("TEMPO", Rectangle<int> (0, 0, getWidth(), 18), Justification::centred);
    auto r = numberArea().toFloat().reduced (2.f, 2.f);
    g.setColour (Colour (0xff1b1510)); g.fillRoundedRectangle (r, 9.f);
    g.setColour (Colour (0xff050403)); g.fillRoundedRectangle (r.reduced (4.f), 5.f);
    if (typer.isVisible()) return;
    const float v = bpm();
    const String num = v <= 0.f ? String ("—") : (std::abs (v - std::round (v)) < 0.05f ? String (roundToInt (v)) : String (v, 1));
    auto txt = r.reduced (8.f, 0.f);
    auto unit = txt.removeFromRight (40.f);
    g.setFont (lf ? lf->mono (26.f) : Font (26.f));
    g.setColour (ed ? Colour (0xfffff4dc) : pal::cream.withAlpha (0.7f)); g.drawText (num, txt.translated (0.f, 2.f), Justification::centredRight);
    g.setFont (font (false, ed ? 11.f : 10.f)); g.setColour (pal::led.withAlpha (0.85f));
    g.drawFittedText (ed ? String ("BPM") : String ("DEL\nDAW"), unit.toNearestInt().withTrimmedLeft (6), Justification::centredLeft, 2, 0.8f);
}
void TempoBox::mouseDown (const MouseEvent& e)
{
    dragging = editable() && numberArea().contains (e.getPosition());
    if (dragging) { dragStart = bpm(); param->beginChangeGesture(); }
}
void TempoBox::mouseDrag (const MouseEvent& e)
{
    if (! dragging) return;
    const float per = e.mods.isShiftDown() ? 0.1f : 0.5f; // con Shift: ajuste fino
    float v = dragStart - (float) e.getDistanceFromDragStartY() * per;
    v = e.mods.isShiftDown() ? std::round (v * 10.f) / 10.f : std::round (v);
    param->setValueNotifyingHost (param->convertTo0to1 (jlimit (40.f, 220.f, v)));
    repaint();
}
void TempoBox::mouseUp (const MouseEvent&) { if (dragging) param->endChangeGesture(); dragging = false; }
void TempoBox::mouseDoubleClick (const MouseEvent& e)
{
    if (! editable() || ! numberArea().contains (e.getPosition())) return;
    typer.setText (String (roundToInt (bpm())), false);
    typer.setVisible (true); typer.grabKeyboardFocus(); typer.selectAll(); repaint();
}
void TempoBox::mouseWheelMove (const MouseEvent& e, const MouseWheelDetails& w)
{
    if (! editable()) return;
    const float step = e.mods.isShiftDown() ? 0.1f : 1.f;
    const float dir = (w.deltaY != 0 ? w.deltaY : w.deltaX) * (w.isReversed ? -1.f : 1.f);
    if (dir != 0) setBpm (bpm() + (dir > 0 ? step : -step));
}
void TempoBox::refresh()
{
    const bool ed = editable();
    const String s = String (bpm(), 1);
    if (ed != lastEditable)
    {
        lastEditable = ed;
        for (auto* b : { &minus, &tap, &plus }) { b->setEnabled (ed); b->setAlpha (ed ? 1.f : 0.45f); }
        setTooltip (ed ? U ("Tempo de Lirio: arrastrá el número arriba/abajo, usá la rueda del mouse o hacé doble clic para escribirlo. Mueve el ritmo, el arpegio y el delay.")
                       : U ("Dentro del DAW, Lirio sigue el tempo del proyecto. Para cambiarlo, cambiá el tempo en Sonar."));
        repaint();
    }
    if (s != shown) { shown = s; repaint(); }
}

// ======================= botones de acorde =======================
ChordPad::ChordPad (LirioProcessor& p) : proc (p)
{
    static const char* names[9] = { "MAYOR", "MENOR", "DIM", "SUS2", "SUS4", "6", "7", "MAJ7", "9" };
    for (int i = 0; i < 9; ++i)
    {
        auto* b = buttons.add (new TextButton (names[i]));
        b->setClickingTogglesState (false);
        b->setColour (TextButton::buttonOnColourId, pal::rainbow (i));
        b->onClick = [this, i] { toggle (i); };
        addAndMakeVisible (b);
    }
    buttons[0]->setTooltip (U ("Mayor · tecla Q (no se combina con Menor ni Dim)"));
    buttons[1]->setTooltip (U ("Menor · tecla W (se puede sumar a Sus2, Sus4, 6, 7, Maj7 y 9)"));
    buttons[2]->setTooltip (U ("Disminuido · tecla E"));
    buttons[3]->setTooltip (U ("Sus2 · tecla A. Solo: reemplaza la tercera. Con Mayor/Menor: se suma (add2)"));
    buttons[4]->setTooltip (U ("Sus4 · tecla S. Solo: reemplaza la tercera. Con Mayor/Menor: se suma (add4)"));
    buttons[5]->setTooltip (U ("Sexta · tecla D. Con 7 en AVANZADO se vuelve 13"));
    buttons[6]->setTooltip (U ("Séptima menor (7) · tecla Z"));
    buttons[7]->setTooltip (U ("Séptima mayor (Maj7) · tecla X"));
    buttons[8]->setTooltip (U ("Novena · tecla C"));
    sync();
}
void ChordPad::resized()
{
    const float bw = getWidth() / 3.f, bh = getHeight() / 3.f;
    for (int i = 0; i < 9; ++i) buttons[i]->setBounds (Rectangle<float> ((i % 3) * bw, (i / 3) * bh, bw, bh).reduced (3.f, 2.f).toNearestInt());
}
static bool paramOn (LirioProcessor& p, const char* id) { return p.apvts.getRawParameterValue (id)->load() > .5f; }
static void setParam (LirioProcessor& p, const char* id, bool on)
{
    if (auto* prm = p.apvts.getParameter (id)) { prm->beginChangeGesture(); prm->setValueNotifyingHost (on ? 1.f : 0.f); prm->endChangeGesture(); }
}
void ChordPad::toggle (int k)
{
    const bool on = ! paramOn (proc, LirioProcessor::chordIds[k]);
    if (on && k < 3) for (int j = 0; j < 3; ++j) if (j != k && paramOn (proc, LirioProcessor::chordIds[j])) setParam (proc, LirioProcessor::chordIds[j], false);
    setParam (proc, LirioProcessor::chordIds[k], on);
    sync();
}
void ChordPad::clearAll() { for (int k = 0; k < 9; ++k) if (paramOn (proc, LirioProcessor::chordIds[k])) setParam (proc, LirioProcessor::chordIds[k], false); sync(); }
void ChordPad::sync()
{
    const int ks = proc.engine.uiKsHeld.load();
    for (int k = 0; k < 9; ++k)
    {
        bool on = paramOn (proc, LirioProcessor::chordIds[k]);
        if ((ks & 7) && k < 3) on = false;           // una tecla de cambio de tercera manda mientras se mantiene
        on = on || ((ks >> k) & 1);
        if (buttons[k]->getToggleState() != on) buttons[k]->setToggleState (on, dontSendNotification);
    }
}

// ======================= barra del looper =======================
void LoopBar::paint (Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (1.f);
    g.setColour (pal::ink); g.fillRoundedRectangle (r, r.getHeight() * 0.5f);
    const int st = proc.engine.uiLoopState.load();
    const float pos = proc.engine.uiLoopPos.load();
    const auto col = st == lirio::Engine::L_Rec || st == lirio::Engine::L_Dub ? pal::red : pal::led;
    if (st == lirio::Engine::L_Rec || st == lirio::Engine::L_Play || st == lirio::Engine::L_Dub)
    { auto f = r.reduced (3.f); g.setColour (col); g.fillRoundedRectangle (f.withWidth (jmax (f.getHeight(), f.getWidth() * pos)), f.getHeight() * 0.5f); }
    // marcas de compás
    const int bars = (int) std::lround (proc.apvts.getRawParameterValue ("loopBars")->load());
    static const int nb[] = { 1, 2, 4, 8 };
    const int n = nb[jlimit (0, 3, bars)];
    g.setColour (pal::cream.withAlpha (0.5f));
    for (int k = 1; k < n; ++k) { const float x = r.getX() + r.getWidth() * (float) k / (float) n; g.drawLine (x, r.getY() + 4.f, x, r.getBottom() - 4.f, 1.5f); }
}

// ======================= contenido =======================
Content::Content (LirioProcessor& p) : proc (p), chordPad (p), loopBar (p), keys (p), grid (p), tempoBox (p)
{
    setLookAndFeel (&look);
    auto& s = proc.apvts;
    mode   = std::make_unique<Pills> (s, "mode", SA ({ "ACORDES", "NOTAS" }), 2, false);
    perf   = std::make_unique<Pills> (s, "perf", SA ({ "ACORDE", "STRUM", "SLOP", "ARPEGIO", "ARPA", "PATRÓN" }), 6, true);
    engine = std::make_unique<Pills> (s, "engine", SA ({ "ANALÓGICO", "FM", "LENGÜETA" }), 3, true);
    complexity = std::make_unique<Pills> (s, "complexity", SA ({ "SIMPLE", "AVANZADO", "LIBRE" }), 3, true);
    bassMode = std::make_unique<Pills> (s, "bassMode", SA ({ "SIGUE", "SOLO" }), 2, true);
    for (auto* c : { mode.get(), perf.get(), engine.get(), complexity.get(), bassMode.get() }) addAndMakeVisible (c);
    for (auto* b : complexity->buttons) b->setTooltip (U ("SIMPLE: un solo color por acorde (como mucho 4 notas). AVANZADO: 6+7 da 13, Maj7 manda sobre 7. LIBRE: apila todo lo que prendas."));
    for (auto* b : bassMode->buttons) b->setTooltip (U ("SIGUE: el bajo toca la raíz de cada acorde. SOLO: el teclado toca solo el bajo (una nota a la vez)."));
    addAndMakeVisible (chordPad);
    autoBtn.setClickingTogglesState (false); autoBtn.setColour (TextButton::buttonOnColourId, pal::cream);
    autoBtn.onClick = [this] { chordPad.clearAll(); };
    autoBtn.setTooltip (U ("Apaga todos los botones: cada tecla arma el acorde de la escala · tecla R"));
    addAndMakeVisible (autoBtn);

    auto tog = [&] (ToggleButton& b, const char* id, Colour c) { b.setColour (ToggleButton::tickColourId, c); addAndMakeVisible (b); btnAtt.push_back (std::make_unique<AudioProcessorValueTreeState::ButtonAttachment> (s, id, b)); };
    lockPerf.setButtonText (U ("TRABAR INTERPRETACIÓN")); lockFx.setButtonText (U ("TRABAR EFECTOS"));
    tog (hold, "hold", pal::pink); tog (keyswitch, "keyswitch", pal::turq); tog (bassOn, "bassOn", pal::lime); tog (followOct, "followOct", pal::lime);
    tog (voiceLead, "voiceLead", pal::pink); tog (loopQuant, "loopQuant", pal::turq); tog (lockPerf, "lockPerf", pal::orange); tog (lockFx, "lockFx", pal::purple); tog (midiOut, "midiOut", pal::lime);
    followOct.setTooltip (U ("Encendido: el acorde suena en la octava de la tecla que tocás (los botones de octava del teclado lo suben o bajan). Apagado: siempre en la misma zona."));
    keyswitch.setTooltip (U ("Las teclas MIDI 24 a 32 (Do1 a Sol#1) son los 9 botones de acorde mientras las mantenés: Mayor, Menor, Dim, Sus2, Sus4, 6, 7, Maj7, 9"));
    hold.setTooltip ("El acorde queda sonando al soltar la tecla. Tocá la misma tecla para apagarlo.");
    voiceLead.setTooltip (U ("Cada acorde elige la inversión más cercana al anterior: las voces se mueven lo menos posible."));
    lockPerf.setTooltip (U ("Al cambiar de preset no se toca la interpretación (strum, arpegio, patrón)."));
    lockFx.setTooltip (U ("Al cambiar de preset no se tocan los efectos."));
    midiOut.setTooltip (U ("Manda al DAW lo que toca Lirio: canal 1 los acordes (con strum, arpegio, patrón y looper), canal 2 el bajo."));
    loopQuant.setTooltip (U ("Acomoda lo que grabás a la semicorchea más cercana."));

    auto box = [&] (ComboBox& b, const char* id, const StringArray& items)
    {
        b.addItemList (items, 1); addAndMakeVisible (b);
        boxAtt.push_back (std::make_unique<AudioProcessorValueTreeState::ComboBoxAttachment> (s, id, b));
    };
    box (keyBox, "key", LirioProcessor::keyNames); box (scaleBox, "scale", SA ({ "Mayor", "Menor" }));
    box (rateBox, "arpRate", LirioProcessor::rateNames); box (patternBox, "arpPattern", LirioProcessor::patternNames);
    box (rhythmBox, "rhythm", LirioProcessor::rhythmNames);
    box (delayBox, "delayTime", LirioProcessor::delayNames); box (bassOctBox, "bassOct", SA ({ "-1", "-2" })); bassOctBox.setTooltip ("Octava del bajo respecto del acorde");
    box (bassSoundBox, "bassSound", LirioProcessor::bassSoundNames); bassSoundBox.setTooltip ("Sonido del bajo");
    box (loopBarsBox, "loopBars", SA ({ "1 compás", "2 compases", "4 compases", "8 compases" }));
    refreshPresetList();
    presetBox.onChange = [this]
    {
        const int id = presetBox.getSelectedId();
        if (id >= 1000) { auto f = proc.userPresets(); if (isPositiveAndBelow (id - 1000, f.size())) proc.loadUserPreset (f[id - 1000]); }
        else if (id > 0) proc.setCurrentProgram (id - 1);
    };
    addAndMakeVisible (presetBox);

    auto knob = [&] (const char* id, const char* name, Colour c) { auto* k = knobs.add (new Knob (s, id, U (name), c)); k->setName (id); addAndMakeVisible (k); return k; };
    knob ("voicing", "VOICING", pal::pink); knob ("octave", "REGISTRO", pal::orange); knob ("velsens", "DINÁMICA", pal::turq);
    knob ("strum", "VELOCIDAD", pal::pink); knob ("slop", "HUMANO", pal::orange); knob ("arpOct", "OCTAVAS", pal::lime); knob ("arpGate", "DURACIÓN", pal::turq);
    addAndMakeVisible (tempoBox);
    knob ("bright", "BRILLO", pal::lemon); kTone2 = knob ("tone2", "RESONANCIA", pal::pink); kChar = knob ("character", "ENVOLVENTE", pal::orange); kMove = knob ("movement", "MOVIMIENTO", pal::turq);
    knob ("attack", "ATAQUE", pal::lime); knob ("decay", "CAÍDA", pal::sky); knob ("sustain", "SOSTÉN", pal::purple); knob ("release", "SUELTA", pal::pink);
    knob ("bassLevel", "NIVEL", pal::lime); knob ("bassTone", "TONO", pal::orange);
    knob ("chorus", "CHORUS", pal::turq); knob ("delayMix", "DELAY", pal::pink); knob ("delayFb", "REPETIR", pal::orange); knob ("reverbMix", "REVERB", pal::purple);
    knob ("reverbSize", "TAMAÑO", pal::sky); knob ("volume", "VOLUMEN", pal::lemon);
    knob ("drive", "SATURACIÓN", pal::orange); knob ("cutoff", "FILTRO", pal::lemon); knob ("phaser", "FASER", pal::turq); knob ("flanger", "FLANGER", pal::pink);
    addAndMakeVisible (keys);
    // ---- looper ----
    loopRec.setColour (TextButton::buttonOnColourId, pal::red); loopPlay.setColour (TextButton::buttonOnColourId, pal::led);
    loopRec.onClick   = [this] { proc.engine.loopCmd.store (1); };
    loopPlay.onClick  = [this] { proc.engine.loopCmd.store (2); };
    loopUndo.onClick  = [this] { proc.engine.loopCmd.store (3); };
    loopClear.onClick = [this] { proc.engine.loopCmd.store (4); };
    loopExport.onClick = [this] { if (proc.engine.uiLoopEvents.load() > 0) proc.exportReq.store (true); else loopText = U ("Todavía no hay nada grabado"); };
    loopRec.setTooltip (U ("Grabar: arranca con la primera nota que toques. Con el loop sonando, sobregraba encima."));
    loopUndo.setTooltip (U ("Saca la última capa grabada"));
    loopExport.setTooltip (U ("Guarda el loop como archivo MIDI (con los acordes ya armados) en Documentos\\Lirio, para arrastrarlo al DAW"));
    for (auto* b : { &loopRec, &loopPlay, &loopUndo, &loopClear, &loopExport }) addAndMakeVisible (b);
    addAndMakeVisible (loopBar);
    // ---- presets propios ----
    presetSave.onClick = [this] { askPresetName(); };
    presetFolder.onClick = [this] { auto f = proc.userPresetFolder(); f.createDirectory(); f.startAsProcess(); };
    presetSave.setTooltip (U ("Guarda el sonido actual como preset tuyo (aparece al final de la lista de presets)"));
    addAndMakeVisible (presetSave); addAndMakeVisible (presetFolder);
    // ---- ritmo ----
    knob ("drumVol", "VOLUMEN", pal::pink); knob ("swing", "SWING", pal::orange); knob ("drumComp", "COMPRESIÓN", pal::lime); knob ("drumVerb", "REVERB", pal::purple);
    knob ("drumPhase", "FASE", pal::turq); knob ("drumTone", "TONO", pal::lemon); knob ("drumDrive", "SATURAR", pal::orange);
    drumPlay.setClickingTogglesState (true); drumPlay.setColour (TextButton::buttonOnColourId, pal::lime);
    btnAtt.push_back (std::make_unique<AudioProcessorValueTreeState::ButtonAttachment> (s, "drumsOn", drumPlay)); addAndMakeVisible (drumPlay);
    tog (drumSync, "drumSync", pal::turq);
    drumSync.setTooltip (U ("Encendido: dentro de Sonar el ritmo arranca y para con el play del proyecto y sigue su tempo."));
    box (drumPatternBox, "drumPattern", LirioProcessor::drumPatternNames);
    addAndMakeVisible (grid); grid.setTooltip (U ("Clic en los cuadros para poner o quitar golpes (podés arrastrar). Con SEGUIR AL DAW, en Sonar arranca con el play."));
    // ---- grabar demo ----
    recBtn.setColour (TextButton::buttonOnColourId, pal::red);
    recBtn.onClick = [this] { if (proc.isRecording()) proc.stopRecording(); else if (! proc.startRecording()) recText = U ("No se pudo crear el archivo"); };
    folderBtn.onClick = [this] { auto f = proc.recordFolder(); f.createDirectory(); if (proc.lastRecording.existsAsFile()) proc.lastRecording.revealToUser(); else f.startAsProcess(); };
    addAndMakeVisible (recBtn); addAndMakeVisible (folderBtn);
    // teclado de la compu: QWE/ASD/ZXC prenden y apagan los botones de acorde, R vuelve a AUTO
    setWantsKeyboardFocus (true);
    // los botones, listas y knobs no se quedan con el foco: así las letras llegan siempre a Lirio
    // y la barra espaciadora sigue yendo al DAW en vez de apretar el último botón tocado
    std::function<void (Component&)> noFocus = [&] (Component& c)
    {
        for (auto* ch : c.getChildren())
        {
            if (dynamic_cast<Button*> (ch) || dynamic_cast<ComboBox*> (ch) || dynamic_cast<Slider*> (ch)) ch->setWantsKeyboardFocus (false);
            if (dynamic_cast<ComboBox*> (ch) == nullptr && dynamic_cast<Slider*> (ch) == nullptr) noFocus (*ch);
        }
    };
    noFocus (*this);
    setMouseClickGrabsKeyboardFocus (true);
    startTimerHz (20);
}
Content::~Content() { stopTimer(); setLookAndFeel (nullptr); }

void Content::refreshPresetList()
{
    presetBox.clear (dontSendNotification);
    for (int i = 0; i < proc.getNumPrograms(); ++i) presetBox.addItem (proc.getProgramName (i), i + 1);
    auto files = proc.userPresets();
    if (! files.isEmpty())
    {
        presetBox.addSectionHeading (U ("TUS PRESETS"));
        for (int i = 0; i < files.size(); ++i) presetBox.addItem (files[i].getFileNameWithoutExtension(), 1000 + i);
    }
    int sel = proc.getCurrentProgram() + 1;
    if (proc.currentUser.existsAsFile()) { const int k = files.indexOf (proc.currentUser); if (k >= 0) sel = 1000 + k; }
    presetBox.setSelectedId (sel, dontSendNotification);
}

void Content::askPresetName()
{
    nameWindow = std::make_unique<AlertWindow> (U ("Guardar preset"), U ("Ponele un nombre a tu sonido:"), MessageBoxIconType::NoIcon, this);
    nameWindow->addTextEditor ("nombre", proc.currentUser.existsAsFile() ? proc.currentUser.getFileNameWithoutExtension() : String(), {});
    nameWindow->addButton ("GUARDAR", 1, KeyPress (KeyPress::returnKey));
    nameWindow->addButton ("CANCELAR", 0, KeyPress (KeyPress::escapeKey));
    nameWindow->enterModalState (true, ModalCallbackFunction::create ([this] (int r)
    {
        if (r == 1 && nameWindow != nullptr)
        {
            const auto n = nameWindow->getTextEditorContents ("nombre");
            if (proc.saveUserPreset (n)) { refreshPresetList(); loopText = U ("Preset guardado: ") + n; }
            else loopText = U ("No se pudo guardar el preset");
        }
        nameWindow.reset();
    }), false);
}

void Content::timerCallback()
{
    // programa independiente: toma el teclado al abrir (en el DAW, al hacer clic en Lirio)
    if (proc.wrapperType == AudioProcessor::wrapperType_Standalone && focusTries < 40 && isShowing() && nameWindow == nullptr)
    { if (hasKeyboardFocus (true)) focusTries = 40; else { ++focusTries; grabKeyboardFocus(); } }
    phase += 0.03f; // solo gira la flor; el fondo es fijo para no gastar CPU
    for (auto* pl : { mode.get(), perf.get(), engine.get(), complexity.get(), bassMode.get() }) pl->sync();
    chordPad.sync();
    {
        int mask = 0; for (int k = 0; k < 9; ++k) if (paramOn (proc, LirioProcessor::chordIds[k])) mask |= 1 << k;
        const bool autoOn = mask == 0 && (proc.engine.uiKsHeld.load() == 0);
        if (autoBtn.getToggleState() != autoOn) autoBtn.setToggleState (autoOn, dontSendNotification);
    }
    // rótulos según el motor
    const int e = (int) std::lround (proc.apvts.getRawParameterValue ("engine")->load());
    if (e != lastEngine)
    {
        lastEngine = e;
        if (e == 0) { kTone2->setText (U ("RESONANCIA")); kChar->setText (U ("ENVOLVENTE")); kMove->setText (U ("MOVIMIENTO")); }
        else if (e == 1) { kTone2->setText (U ("RELACIÓN")); kChar->setText (U ("ÍNDICE")); kMove->setText (U ("TRÉMOLO")); }
        else { kTone2->setText (U ("MECÁNICA")); kChar->setText (U ("MORDIDA")); kMove->setText (U ("TRÉMOLO")); }
    }
    // pantalla
    static const char* L[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    static const char* S[] = { "Do", "Do#", "Re", "Re#", "Mi", "Fa", "Fa#", "Sol", "Sol#", "La", "La#", "Si" };
    const int root = proc.engine.uiRoot.load(); const uint32_t iv = proc.engine.uiIv.load();
    const bool isChord = root >= 0 && iv != 0 && iv != 0xFFFFFFFFu;
    const int pf = (int) std::lround (proc.apvts.getRawParameterValue ("perf")->load());
    int tag = 0;
    if (root < 0) chordText = U ("¡Tocá!");
    else if (! isChord) chordText = String (L[root % 12]) + String (root / 12 - 1);
    else chordText = String (L[root % 12]) + String (lirio::chordSuffix (iv, &tag));
    tagText = tag == 2 ? "WTF?" : tag == 1 ? "JAZZ?" : "";
    String tempo = proc.wrapperType == AudioProcessor::wrapperType_Standalone || ! proc.hasHostTempo()
                     ? String (roundToInt (proc.apvts.getRawParameterValue ("tempo")->load())) + " BPM"
                     : String (roundToInt (proc.hostBpm())) + " BPM del DAW";
    static const char* PU[] = { "ACORDE", "STRUM", "SLOP", "ARPEGIO", "ARPA", "PATRÓN" };
    const String what = iv == 0xFFFFFFFFu ? U ("BAJO SOLO") : U (PU[jlimit (0, 5, pf)]);
    subText = (isChord ? String (S[root % 12]) + "  ·  " : String()) + what + "  ·  " + tempo;
    const int act = proc.engine.uiActivity.load(); if (act != lastActivity) { lastActivity = act; led = 1.f; } else led *= 0.8f;
    if (! proc.currentUser.existsAsFile())
    { const int pi = proc.getCurrentProgram(); if (presetBox.getSelectedId() != pi + 1) presetBox.setSelectedId (pi + 1, dontSendNotification); }
    // redibujar solo lo que cambia (pantalla, flor y teclado): mucho menos trabajo para el procesador
    const String sig = chordText + subText + tagText + String (roundToInt (led * 20.f));
    if (sig != lastSig) { lastSig = sig; repaint (476, 10, 312, 102); }
    repaint (24, 12, 108, 108);
    keys.repaint(); grid.repaint(); tempoBox.refresh();
    // looper
    const int ls = proc.engine.uiLoopState.load();
    using EN = lirio::Engine;
    if (ls != lastLoopState)
    {
        lastLoopState = ls;
        loopRec.setToggleState (ls == EN::L_Armed || ls == EN::L_Rec || ls == EN::L_Dub, dontSendNotification);
        loopPlay.setToggleState (ls == EN::L_Play || ls == EN::L_Dub || ls == EN::L_Rec, dontSendNotification);
        loopRec.setButtonText (ls == EN::L_Armed ? U ("ESPERANDO…") : ls == EN::L_Rec ? U ("GRABANDO") : ls == EN::L_Dub ? U ("SOBREGRABANDO")
                               : (ls == EN::L_Play || ls == EN::L_Stop) ? U ("SOBREGRABAR") : U ("GRABAR"));
        loopPlay.setButtonText (ls == EN::L_Play || ls == EN::L_Dub || ls == EN::L_Rec ? U ("PARAR") : U ("PLAY"));
        loopText = ls == EN::L_Empty ? U ("Elegí los compases y tocá GRABAR: arranca con la primera nota.")
                 : ls == EN::L_Armed ? U ("Listo: empezá a tocar y se graba.")
                 : ls == EN::L_Rec ? U ("Grabando la primera vuelta…")
                 : ls == EN::L_Dub ? U ("Sobregrabando: lo que toques se suma.")
                 : ls == EN::L_Play ? U ("Sonando. SOBREGRABAR suma otra capa; DESHACER la saca.")
                 : U ("Loop guardado. PLAY lo vuelve a tocar.");
        repaint (30, 846, 460, 38);
    }
    if (ls == EN::L_Rec || ls == EN::L_Play || ls == EN::L_Dub) loopBar.repaint();
    if (proc.exportReady.load())
    {
        auto f = proc.exportLoopMidi();
        loopText = f.existsAsFile() ? U ("Guardado: ") + f.getFileName() : U ("No se pudo guardar el MIDI");
        if (f.existsAsFile()) f.revealToUser();
        repaint (30, 846, 460, 38); lastLoopState = -2;
    }
    // ritmo y grabación
    const bool playing = proc.apvts.getRawParameterValue ("drumsOn")->load() > .5f;
    drumPlay.setButtonText (playing ? U ("PARAR RITMO") : U ("TOCAR RITMO"));
    const bool rec = proc.isRecording();
    recBtn.setToggleState (rec, dontSendNotification);
    recBtn.setButtonText (rec ? U ("PARAR Y GUARDAR") : U ("GRABAR DEMO"));
    String rt;
    if (rec) { const int sc = (int) proc.recordedSeconds(); rt = U ("GRABANDO  ") + String (sc / 60) + ":" + String (sc % 60).paddedLeft ('0', 2); }
    else if (proc.lastRecording.existsAsFile()) rt = U ("Guardado: ") + proc.lastRecording.getFileName();
    else rt = U ("WAV 24 bits en Documentos\\Lirio");
    if (rt != recText) { recText = rt; repaint (882, 970, 176, 40); }
}

void Content::flower (Graphics& g, Point<float> c, float r, float rot)
{
    // rejilla de parlante: puntos en círculos concéntricos; el del centro titila con lo que suena
    g.setColour (Colours::black.withAlpha (0.12f)); g.fillEllipse (c.x - r - 4.f, c.y - r - 4.f, (r + 4.f) * 2, (r + 4.f) * 2);
    for (int ring = 1; ring <= 5; ++ring)
    {
        const float rr = r * (float) ring / 5.3f; const int n = ring * 7;
        for (int i = 0; i < n; ++i)
        {
            const auto p = c.getPointOnCircumference (rr, (float) i / (float) n * MathConstants<float>::twoPi + ring * 0.3f);
            g.setColour (pal::ink.withAlpha (0.85f)); g.fillEllipse (p.x - 2.1f, p.y - 2.1f, 4.2f, 4.2f);
        }
    }
    g.setColour (pal::led.withAlpha (0.25f + 0.75f * led)); g.fillEllipse (c.x - 3.5f, c.y - 3.5f, 7.f, 7.f);
    ignoreUnused (rot);
}

void Content::panel (Graphics& g, Rectangle<float> r, const String& title, Colour)
{
    // zona hundida en el cuerpo, con el nombre grabado arriba a la izquierda
    g.setColour (pal::well); g.fillRoundedRectangle (r, 14.f);
    g.setColour (Colours::black.withAlpha (0.18f)); g.drawRoundedRectangle (r.translated (0.f, 1.f), 14.f, 2.f);
    g.setColour (Colours::white.withAlpha (0.18f)); g.drawRoundedRectangle (r.translated (0.f, -0.5f).reduced (0.5f), 14.f, 1.f);
    g.setFont (look.label (12.f)); g.setColour (pal::ink);
    const String t = title.toUpperCase();
    String spaced; for (auto ch : t) { spaced << String::charToString (ch) << (ch == ' ' ? " " : String::charToString (0x2009)); }
    g.drawText (spaced.trimEnd(), Rectangle<float> (r.getX() + 16.f, r.getY() - 8.f, 300.f, 16.f).withY (r.getY() - 18.f), Justification::centredLeft);
}

void Content::paint (Graphics& g)
{
    const float W = (float) getWidth(), H = (float) getHeight();
    // cuerpo del aparato: mostaza con luz de arriba, bordes redondeados y marco oscuro
    g.fillAll (Colour (0xff16110c));
    auto bodyR = Rectangle<float> (3.f, 3.f, W - 6.f, H - 6.f);
    ColourGradient gr (pal::body.brighter (0.08f), 0.f, 0.f, pal::bodyLo, 0.f, H, false);
    g.setGradientFill (gr); g.fillRoundedRectangle (bodyR, 26.f);
    g.setColour (Colours::white.withAlpha (0.22f)); g.drawRoundedRectangle (bodyR.reduced (1.f), 25.f, 1.5f);
    // tornillos
    for (auto p : { Point<float> (18.f, 18.f), Point<float> (W - 18.f, 18.f), Point<float> (18.f, H - 18.f), Point<float> (W - 18.f, H - 18.f) })
    { g.setColour (Colours::black.withAlpha (0.25f)); g.fillEllipse (p.x - 5.f, p.y - 4.f, 10.f, 10.f); g.setColour (pal::bodyLo.darker (0.2f)); g.fillEllipse (p.x - 5.f, p.y - 5.f, 10.f, 10.f);
      g.setColour (pal::ink.withAlpha (0.6f)); g.drawLine (p.x - 3.f, p.y - 3.f, p.x + 3.f, p.y + 3.f, 1.4f); }

    // parlante
    flower (g, { 76.f, 64.f }, 44.f, phase);

    // nombre
    g.setFont (look.display (64.f)); g.setColour (pal::ink);
    g.drawText ("lirio", Rectangle<float> (136.f, 6.f, 300.f, 80.f), Justification::centredLeft);
    g.setFont (look.label (12.f)); g.setColour (pal::ink.withAlpha (0.8f));
    g.drawText (U ("M Á Q U I N A   D E   A C O R D E S"), Rectangle<float> (140.f, 78.f, 320.f, 18.f), Justification::centredLeft);
    g.drawText (U ("S A A V E D R I S M O"), Rectangle<float> (140.f, 96.f, 320.f, 16.f), Justification::centredLeft);

    // pantalla OLED
    auto bez = Rectangle<float> (476.f, 12.f, 308.f, 98.f);
    g.setColour (Colours::black.withAlpha (0.3f)); g.fillRoundedRectangle (bez.translated (0.f, 2.f), 14.f);
    g.setColour (Colour (0xff1b1510)); g.fillRoundedRectangle (bez, 14.f);
    auto d = bez.reduced (8.f);
    g.setColour (Colour (0xff050403)); g.fillRoundedRectangle (d, 6.f);
    // líneas de barrido suaves
    g.setColour (Colours::white.withAlpha (0.025f)); for (float y = d.getY() + 1.f; y < d.getBottom(); y += 3.f) g.drawHorizontalLine ((int) y, d.getX() + 2.f, d.getRight() - 2.f);
    auto big = d.withTrimmedBottom (24.f);
    g.setFont (look.mono (chordText.length() > 10 ? 26.f : 34.f));
    g.setColour (pal::cream.withAlpha (0.18f)); g.drawText (chordText, big.translated (0.f, 1.5f).expanded (1.f), Justification::centred);
    g.setColour (Colour (0xfffff4dc)); g.drawText (chordText, big, Justification::centred);
    g.setFont (look.mono (11.f)); g.setColour (pal::led.withAlpha (0.85f)); g.drawText (subText, d.removeFromBottom (24.f), Justification::centred);
    g.setColour (pal::led.withAlpha (0.2f + 0.8f * led)); g.fillEllipse (bez.getRight() - 20.f, bez.getY() + 12.f, 7.f, 7.f);
    if (tagText.isNotEmpty())
    {
        auto tg = Rectangle<float> (bez.getX() + 14.f, bez.getY() + 13.f, tagText.length() > 4 ? 50.f : 42.f, 16.f);
        g.setColour (tagText == "WTF?" ? pal::red : pal::led); g.drawRoundedRectangle (tg, 3.f, 1.2f);
        g.setFont (look.mono (11.f)); g.drawText (tagText, tg, Justification::centred);
    }

    // etiqueta de preset
    g.setFont (look.label (11.5f)); g.setColour (pal::ink);
    g.drawText ("P R E S E T", Rectangle<float> (804.f, 8.f, 120.f, 18.f), Justification::centredLeft);

    panel (g, { 18.f, 140.f, 360.f, 252.f }, "Acorde", pal::pink);
    panel (g, { 392.f, 140.f, 214.f, 252.f }, "Tono", pal::orange);
    panel (g, { 620.f, 140.f, 442.f, 252.f }, U ("INTERPRETACIÓN"), pal::turq);
    panel (g, { 18.f, 420.f, 588.f, 220.f }, "Sonido", pal::lemon);
    panel (g, { 620.f, 420.f, 150.f, 220.f }, "Bajo", pal::lime);
    panel (g, { 784.f, 420.f, 278.f, 220.f }, "Efectos", pal::purple);
    panel (g, { 18.f, 656.f, 480.f, 220.f }, "Looper", pal::pink);
    panel (g, { 512.f, 656.f, 286.f, 220.f }, U ("MÁS EFECTOS"), pal::turq);
    panel (g, { 812.f, 656.f, 250.f, 220.f }, "Presets", pal::lime);
    panel (g, { 18.f, 892.f, 1044.f, 190.f }, "Ritmo", pal::orange);
    g.setFont (look.label (12.f)); g.setColour (pal::ink.withAlpha (0.75f));
    g.drawFittedText (U ("Arrastrá los knobs arriba/abajo · doble clic vuelve al valor inicial · teclas Q W E / A S D / Z X C prenden los botones de acorde, R vuelve a AUTO."), Rectangle<int> (34, 596, 560, 36), Justification::centredLeft, 2);
    g.drawFittedText (loopText, Rectangle<int> (30, 846, 460, 38), Justification::centredLeft, 2);
    g.drawFittedText (U ("Saturación y filtro van antes del chorus, el delay y la reverb."), Rectangle<int> (526, 806, 260, 56), Justification::centredLeft, 3);
    g.setFont (look.label (12.5f)); g.setColour (pal::ink.withAlpha (0.75f));
    g.setColour (proc.isRecording() ? pal::red : pal::ink); g.setFont (look.label (12.f));
    g.drawFittedText (recText, Rectangle<int> (884, 972, 172, 36), Justification::centred, 2);
    g.setColour (pal::ink.withAlpha (0.8f)); g.setFont (look.label (11.f));
    g.drawText ("RITMO ARPEGIO", Rectangle<float> (640.f, 314.f, 136.f, 18.f), Justification::centredLeft);
    g.drawText ("DIBUJO ARPEGIO", Rectangle<float> (782.f, 314.f, 136.f, 18.f), Justification::centredLeft);
    g.drawText (U ("PATRÓN RÍTMICO"), Rectangle<float> (922.f, 314.f, 136.f, 18.f), Justification::centredLeft);
    g.drawText ("TIEMPO DEL DELAY", Rectangle<float> (938.f, 546.f, 120.f, 18.f), Justification::centredLeft);
}

bool Content::keyPressed (const KeyPress& k)
{
    const auto m = k.getModifiers();
    if (m.isCommandDown() || m.isCtrlDown() || m.isAltDown()) return false; // atajos del sistema o del DAW
    const juce_wchar c = CharacterFunctions::toLowerCase (k.getTextCharacter());
    static const char keys[] = "qweasdzxc";
    for (int i = 0; i < 9; ++i)
        if (c == (juce_wchar) keys[i]) { chordPad.toggle (i); return true; }
    if (c == 'r') { chordPad.clearAll(); return true; }
    return false; // las demás teclas siguen de largo (por ejemplo, al DAW)
}

void Content::paintOverChildren (Graphics& g)
{
    // letrita de la tecla en la esquina de cada botón de acorde y de AUTO
    static const char* keys[] = { "Q", "W", "E", "A", "S", "D", "Z", "X", "C" };
    auto badge = [&] (Rectangle<int> b, const char* t)
    {
        auto r = Rectangle<float> ((float) b.getRight() - 21.f, (float) b.getY() + 1.f, 17.f, 15.f);
        g.setColour (pal::cream); g.fillRoundedRectangle (r, 4.f);
        g.setColour (pal::ink); g.setFont (look.label (10.5f)); g.drawText (t, r.translated (0.f, -0.5f), Justification::centred);
    };
    for (int i = 0; i < chordPad.buttons.size() && i < 9; ++i)
        badge (getLocalArea (&chordPad, chordPad.buttons[i]->getBounds()), keys[i]);
    badge (autoBtn.getBounds(), "R");
}

void Content::resized()
{
    auto K = [this] (const char* id) -> Knob* { for (auto* k : knobs) if (k->getName() == id) return k; return nullptr; };
    auto put = [&] (const char* id, int x, int y) { if (auto* k = K (id)) k->setBounds (x, y, 70, 84); };
    auto putS = [&] (const char* id, int x, int y) { if (auto* k = K (id)) k->setBounds (x, y, 58, 74); };

    presetBox.setBounds (800, 26, 262, 32);
    mode->setBounds (800, 64, 262, 40);
    // Acorde
    chordPad.setBounds (30, 164, 336, 132);
    autoBtn.setBounds (30, 300, 92, 38); complexity->setBounds (124, 300, 244, 38);
    hold.setBounds (30, 342, 130, 38); keyswitch.setBounds (164, 342, 204, 38);
    // Tono
    put ("voicing", 400, 166); put ("octave", 466, 166); put ("velsens", 532, 166);
    keyBox.setBounds (404, 262, 92, 32); scaleBox.setBounds (500, 262, 96, 32);
    followOct.setBounds (400, 300, 200, 36); voiceLead.setBounds (400, 340, 200, 36);
    // Interpretación
    perf->setBounds (630, 164, 422, 40);
    put ("strum", 630, 210); put ("slop", 700, 210); put ("arpOct", 770, 210); put ("arpGate", 840, 210);
    tempoBox.setBounds (916, 208, 138, 96);
    rateBox.setBounds (634, 334, 138, 32); patternBox.setBounds (776, 334, 138, 32); rhythmBox.setBounds (918, 334, 138, 32);
    // Sonido
    engine->setBounds (30, 444, 360, 40);
    const char* snd[] = { "bright", "tone2", "character", "movement", "attack", "decay", "sustain", "release" };
    for (int i = 0; i < 8; ++i) put (snd[i], 28 + i * 72, 500);
    // Bajo
    bassOn.setBounds (626, 440, 78, 36); bassOctBox.setBounds (706, 442, 58, 30);
    bassSoundBox.setBounds (628, 478, 136, 30);
    put ("bassLevel", 628, 512); put ("bassTone", 694, 512);
    bassMode->setBounds (626, 598, 140, 34);
    // Efectos
    put ("chorus", 790, 444); put ("delayMix", 856, 444); put ("delayFb", 922, 444); put ("reverbMix", 988, 444);
    put ("reverbSize", 790, 534); put ("volume", 856, 534);
    delayBox.setBounds (930, 566, 124, 30);
    // Looper
    loopRec.setBounds (28, 682, 150, 46); loopPlay.setBounds (180, 682, 100, 46); loopUndo.setBounds (282, 682, 104, 46); loopClear.setBounds (388, 682, 100, 46);
    loopBar.setBounds (32, 738, 454, 24);
    loopBarsBox.setBounds (28, 772, 140, 32); loopQuant.setBounds (172, 770, 140, 36); loopExport.setBounds (316, 768, 172, 40);
    // Más efectos
    put ("drive", 520, 690); put ("cutoff", 588, 690); put ("phaser", 656, 690); put ("flanger", 724, 690);
    // Presets
    presetSave.setBounds (822, 680, 230, 40); presetFolder.setBounds (822, 722, 230, 34);
    lockPerf.setBounds (822, 760, 230, 36); lockFx.setBounds (822, 798, 230, 36); midiOut.setBounds (822, 836, 230, 36);
    // Ritmo
    const int dy = 236;
    drumPlay.setBounds (28, 684 + dy, 150, 40); drumSync.setBounds (28, 726 + dy, 150, 34); drumPatternBox.setBounds (28, 764 + dy, 150, 32);
    putS ("drumVol", 182, 676 + dy); putS ("swing", 240, 676 + dy); putS ("drumComp", 298, 676 + dy); putS ("drumVerb", 356, 676 + dy);
    putS ("drumPhase", 182, 752 + dy); putS ("drumTone", 240, 752 + dy); putS ("drumDrive", 298, 752 + dy);
    grid.setBounds (420, 676 + dy, 456, 158);
    recBtn.setBounds (884, 682 + dy, 172, 44); folderBtn.setBounds (884, 778 + dy, 172, 38);
    keys.setBounds (18, 1094, 1044, 46);
}

// ======================= editor =======================
LirioEditor::LirioEditor (LirioProcessor& p) : AudioProcessorEditor (p), content (p)
{
    addAndMakeVisible (content);
    content.setBounds (0, 0, W, H);
    setResizable (true, true);
    setResizeLimits (W * 6 / 10, H * 6 / 10, W * 3 / 2, H * 3 / 2);
    if (auto* c = getConstrainer()) c->setFixedAspectRatio ((double) W / H);
    // si la pantalla es baja (notebook), arranca más chico para que entre entero
    float sc = 1.f;
    if (auto* d = Desktop::getInstance().getDisplays().getPrimaryDisplay())
        sc = jlimit (0.6f, 1.f, (float) (d->userArea.getHeight() - 90) / (float) H);
    setSize (roundToInt (W * sc), roundToInt (H * sc));
}
void LirioEditor::resized()
{
    content.setTransform (AffineTransform::scale ((float) getWidth() / (float) W));
}
