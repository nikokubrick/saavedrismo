#include "PluginProcessor.h"
#include "PluginEditor.h"
using namespace juce;
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();

static void setP (LirioProcessor& p, const char* id, float v) { if (auto* prm = p.apvts.getParameter (id)) prm->setValueNotifyingHost (prm->convertTo0to1 (v)); }
static String notes (const MidiBuffer& mb)
{
    String s; for (const auto m : mb) { auto msg = m.getMessage(); if (msg.isNoteOn()) s << "on" << msg.getChannel() << ":" << msg.getNoteNumber() << " "; else if (msg.isNoteOff()) s << "off" << msg.getChannel() << ":" << msg.getNoteNumber() << " "; }
    return s;
}

int main (int argc, char** argv)
{
    ScopedJuceInitialiser_GUI gui;
    String out = argc > 1 ? argv[1] : "/tmp/lirio";
    std::unique_ptr<LirioProcessor> p (dynamic_cast<LirioProcessor*> (createPluginFilter()));
    p->setPlayConfigDetails (0, 2, 48000, 512); p->prepareToPlay (48000, 512);
    AudioBuffer<float> buf (2, 512); MidiBuffer mb;
    auto block = [&] (int k = 1) { for (int i = 0; i < k; ++i) { mb.clear(); p->processBlock (buf, mb); } };

    // ---- nombres de acordes (combinaciones) ----
    {
        struct T { int mask; int cx; const char* want; };
        const T tests[] = { { 0, 0, "m" }, { 2 | 8, 1, "m(add2)" }, { 8, 1, "sus2" }, { 1 | 64, 1, "7" }, { 2 | 64 | 256, 1, "m9" }, { 1 | 128, 1, "maj7" },
                            { 1 | 32 | 64, 1, "13" }, { 1 | 64 | 128, 2, "7(maj7)" }, { 4 | 64, 1, "m7b5" }, { 4 | 32, 1, "dim7" }, { 16 | 64, 1, "7sus4" }, { 1 | 32 | 256, 1, "6/9" },
                            { 1 | 64 | 128, 0, "maj7" } };
        int ok = 0;
        for (auto& t : tests)
        {
            const auto iv = lirio::chordIntervals (9, t.mask, 9, 1, t.cx); // La en La menor
            int tag = 0; const auto s = lirio::chordSuffix (iv, &tag);
            if (s == t.want) ++ok; else printf ("  FALLA nombre mask=%d cx=%d -> '%s' (esperaba '%s')\n", t.mask, t.cx, s.c_str(), t.want);
        }
        printf ("nombres de acordes: %d/%d\n", ok, (int) (sizeof (tests) / sizeof (tests[0])));
    }

    // ---- salida MIDI: Am con Menor+Sus2 por teclas de cambio, bajo en canal 2 ----
    setP (*p, "bassOn", 1.f);
    mb.clear(); mb.addEvent (MidiMessage::noteOn (1, 25, (uint8) 100), 0); mb.addEvent (MidiMessage::noteOn (1, 27, (uint8) 100), 1);
    mb.addEvent (MidiMessage::noteOn (1, 57, (uint8) 100), 10); p->processBlock (buf, mb);
    printf ("midi out Am(add2): %s\n", notes (mb).toRawUTF8());
    mb.clear(); mb.addEvent (MidiMessage::noteOff (1, 57), 0); mb.addEvent (MidiMessage::noteOff (1, 25), 0); mb.addEvent (MidiMessage::noteOff (1, 27), 0); p->processBlock (buf, mb);
    printf ("midi out off: %s\n", notes (mb).toRawUTF8());
    setP (*p, "bassOn", 0.f);

    // ---- voice leading ----
    setP (*p, "voiceLead", 1.f);
    String vl;
    for (int key : { 48, 53, 55, 48 })
    {
        mb.clear(); mb.addEvent (MidiMessage::noteOn (1, key, (uint8) 100), 0); p->processBlock (buf, mb);
        vl << notes (mb) << "| ";
        mb.clear(); mb.addEvent (MidiMessage::noteOff (1, key), 0); p->processBlock (buf, mb);
    }
    printf ("voice leading C F G C: %s\n", vl.toRawUTF8());
    setP (*p, "voiceLead", 0.f);

    // ---- looper: 1 compás, graba Am y la repite ----
    setP (*p, "loopBars", 0.f); setP (*p, "tempo", 120.f);
    p->engine.loopCmd.store (1); block();
    mb.clear(); mb.addEvent (MidiMessage::noteOn (1, 57, (uint8) 100), 0); p->processBlock (buf, mb);
    block (20);
    mb.clear(); mb.addEvent (MidiMessage::noteOff (1, 57), 0); p->processBlock (buf, mb);
    int replays = 0; String st;
    for (int i = 0; i < 400; ++i) { mb.clear(); p->processBlock (buf, mb); if (notes (mb).contains ("on1:")) ++replays; }
    printf ("looper: estado %d, eventos %d, vueltas con notas %d\n", p->engine.uiLoopState.load(), p->engine.uiLoopEvents.load(), replays);
    p->exportReq.store (true); block();
    auto mid = p->exportLoopMidi();
    printf ("export midi: %s (%lld bytes)\n", mid.getFullPathName().toRawUTF8(), (long long) mid.getSize());
    p->engine.loopCmd.store (4); block (4);

    // ---- presets propios ----
    setP (*p, "phaser", 0.66f);
    printf ("preset guardado: %d\n", (int) p->saveUserPreset ("Prueba snap"));
    p->setCurrentProgram (0);
    printf ("phaser tras preset de fábrica: %.2f\n", p->apvts.getRawParameterValue ("phaser")->load());
    p->loadUserPreset (p->userPresetFolder().getChildFile ("Prueba snap.lirio"));
    printf ("phaser tras preset propio: %.2f\n", p->apvts.getRawParameterValue ("phaser")->load());
    setP (*p, "lockFx", 1.f); setP (*p, "phaser", 0.5f); p->setCurrentProgram (13);
    printf ("candado de efectos: phaser sigue en %.2f\n", p->apvts.getRawParameterValue ("phaser")->load());
    setP (*p, "lockFx", 0.f);
    p->userPresetFolder().getChildFile ("Prueba snap.lirio").deleteFile();

    // ---- capturas ----
    struct Shot { int prog; int key; const char* name; int mask; };
    Shot shots[] = { { 0, 57, "1-juno", 2 | 8 }, { 10, 60, "2-funk", 1 | 64 | 256 }, { 19, 50, "3-bajo-solo", 0 } };
    if (auto* prm = p->apvts.getParameter ("drumsOn")) prm->setValueNotifyingHost (1.f);
    if (auto* prm = p->apvts.getParameter ("drumPattern")) prm->setValueNotifyingHost (prm->convertTo0to1 (7.f));
    for (auto& s : shots)
    {
        p->setCurrentProgram (s.prog);
        for (int k = 0; k < 9; ++k) setP (*p, LirioProcessor::chordIds[k], (s.mask >> k) & 1 ? 1.f : 0.f);
        mb.clear(); mb.addEvent (MidiMessage::noteOn (1, s.key, (uint8) 100), 4); p->processBlock (buf, mb);
        block (30);
        std::unique_ptr<AudioProcessorEditor> ed (p->createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 20; ++i) { MessageManager::getInstance()->runDispatchLoopUntil (25); block(); }
        if (std::string (s.name) == "1-juno")
        {
            // teclas de la compu: W (menor) y A (sus2) se suman; Q cambia menor por mayor; R limpia
            auto* c = ed->getChildComponent (0);
            auto press = [&] (char ch) { c->keyPressed (KeyPress ((int) ch, ModifierKeys(), (juce_wchar) ch)); };
            setP (*p, "cMin", 0.f); setP (*p, "cSus2", 0.f);
            press ('w'); press ('a');
            const bool both = p->apvts.getRawParameterValue ("cMin")->load() > .5f && p->apvts.getRawParameterValue ("cSus2")->load() > .5f;
            press ('q');
            const bool swapped = p->apvts.getRawParameterValue ("cMaj")->load() > .5f && p->apvts.getRawParameterValue ("cMin")->load() < .5f && p->apvts.getRawParameterValue ("cSus2")->load() > .5f;
            press ('r');
            int any = 0; for (int k = 0; k < 9; ++k) any += p->apvts.getRawParameterValue (LirioProcessor::chordIds[k])->load() > .5f;
            printf ("teclas: W+A suman %d · Q reemplaza a W %d · R limpia %d\n", (int) both, (int) swapped, (int) (any == 0));
            press ('w'); press ('a');
            for (int i = 0; i < 6; ++i) { MessageManager::getInstance()->runDispatchLoopUntil (25); block(); }
        }
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        File f (out + "-" + s.name + ".png"); f.deleteFile(); FileOutputStream os (f); PNGImageFormat().writeImageToStream (img, os); os.flush();
        printf ("png %s\n", f.getFullPathName().toRawUTF8());
        mb.clear(); mb.addEvent (MidiMessage::noteOff (1, s.key), 0); p->processBlock (buf, mb);
    }
    return 0;
}
