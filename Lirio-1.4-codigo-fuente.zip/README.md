# Lirio

Máquina de acordes psicodélica (VST3 / AU / programa independiente) de [Saavedrismo](https://nicosaavedra.tech). Hecha con JUCE 7. Licencia GPLv3.

La versión para Mac se compila sola con GitHub Actions (pestaña *Actions* → *Lirio para Mac* → descargar `Lirio-1.4-Mac`).
