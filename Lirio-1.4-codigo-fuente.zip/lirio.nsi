Target amd64-unicode
!include "MUI2.nsh"
!include "x64.nsh"
!define APP "Lirio"
!define VER "1.4.0"
Name "${APP}"
OutFile "/tmp/lirio-pkg/Lirio-Instalador-1.4.exe"
InstallDir "$PROGRAMFILES64\Saavedrismo\Lirio"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
BrandingText "Lirio · Saavedrismo"
!define MUI_ICON "/tmp/lirio-pkg/icon.ico"
!define MUI_UNICON "/tmp/lirio-pkg/icon.ico"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Instalar Lirio"
!define MUI_WELCOMEPAGE_TEXT "Máquina de acordes psicodélica: plugin VST3 para tu DAW y programa independiente.$\r$\n$\r$\nEl plugin se copia en la carpeta estándar de VST3 (Common Files\VST3)."
!define MUI_FINISHPAGE_RUN "$INSTDIR\Lirio.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Abrir Lirio (programa independiente)"
!define MUI_FINISHPAGE_SHOWREADME "$INSTDIR\LEEME.txt"
!define MUI_FINISHPAGE_SHOWREADME_TEXT "Ver instrucciones (LEEME)"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Spanish"
VIProductVersion "1.4.0.0"
VIAddVersionKey /LANG=${LANG_SPANISH} "ProductName" "Lirio"
VIAddVersionKey /LANG=${LANG_SPANISH} "CompanyName" "Saavedrismo"
VIAddVersionKey /LANG=${LANG_SPANISH} "FileDescription" "Instalador de Lirio"
VIAddVersionKey /LANG=${LANG_SPANISH} "FileVersion" "${VER}"
VIAddVersionKey /LANG=${LANG_SPANISH} "LegalCopyright" "Saavedrismo · GPLv3"

Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_OK|MB_ICONSTOP "Lirio necesita Windows de 64 bits."
    Abort
  ${EndIf}
  SetRegView 64
FunctionEnd

Section "Plugin VST3 (para Sonar y otros DAW)" SecVST
  SectionIn RO
  SetOutPath "$COMMONFILES64\VST3"
  File /r "/tmp/lirio-pkg/stage/Lirio.vst3"
SectionEnd

Section "Programa independiente" SecApp
  SetOutPath "$INSTDIR"
  File "/tmp/lirio-pkg/stage/Lirio.exe"
  File "/tmp/lirio-pkg/stage/LEEME.txt"
  CreateDirectory "$SMPROGRAMS\Lirio"
  CreateShortCut "$SMPROGRAMS\Lirio\Lirio.lnk" "$INSTDIR\Lirio.exe"
  CreateShortCut "$SMPROGRAMS\Lirio\LEEME.lnk" "$INSTDIR\LEEME.txt"
  CreateShortCut "$SMPROGRAMS\Lirio\Desinstalar Lirio.lnk" "$INSTDIR\Desinstalar.exe"
  CreateShortCut "$DESKTOP\Lirio.lnk" "$INSTDIR\Lirio.exe"
SectionEnd

Section "-registro"
  SetOutPath "$INSTDIR"
  File "/tmp/lirio-pkg/stage/LEEME.txt"
  WriteUninstaller "$INSTDIR\Desinstalar.exe"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Lirio" "DisplayName" "Lirio (Saavedrismo)"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Lirio" "DisplayVersion" "${VER}"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Lirio" "Publisher" "Saavedrismo"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Lirio" "DisplayIcon" "$INSTDIR\Lirio.exe"
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Lirio" "UninstallString" "$\"$INSTDIR\Desinstalar.exe$\""
  WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Lirio" "URLInfoAbout" "https://nicosaavedra.tech"
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Lirio" "NoModify" 1
  WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Lirio" "NoRepair" 1
SectionEnd

LangString DESC_VST ${LANG_SPANISH} "El instrumento para cargar en Sonar u otro DAW (formato VST3)."
LangString DESC_APP ${LANG_SPANISH} "Lirio como programa suelto, con acceso directo en el escritorio."
!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
  !insertmacro MUI_DESCRIPTION_TEXT ${SecVST} $(DESC_VST)
  !insertmacro MUI_DESCRIPTION_TEXT ${SecApp} $(DESC_APP)
!insertmacro MUI_FUNCTION_DESCRIPTION_END

Function un.onInit
  SetRegView 64
FunctionEnd

Section "Uninstall"
  RMDir /r "$COMMONFILES64\VST3\Lirio.vst3"
  Delete "$DESKTOP\Lirio.lnk"
  RMDir /r "$SMPROGRAMS\Lirio"
  RMDir /r "$INSTDIR"
  DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\Lirio"
SectionEnd
