// prueba offline del motor: renderiza cada motor e interpretación y mide niveles
#include "../Source/Engine.h"
#include <cstdio>
#include <chrono>
using namespace lirio;
static void wav(const char* path,const std::vector<float>& L,const std::vector<float>& R,int sr){
  FILE* f=fopen(path,"wb"); int n=(int)L.size(); int data=n*4; auto w32=[&](uint32_t v){fwrite(&v,4,1,f);}; auto w16=[&](uint16_t v){fwrite(&v,2,1,f);};
  fwrite("RIFF",1,4,f); w32(36+data); fwrite("WAVEfmt ",1,8,f); w32(16); w16(1); w16(2); w32(sr); w32(sr*4); w16(4); w16(16); fwrite("data",1,4,f); w32(data);
  for(int i=0;i<n;i++){ int16_t a=(int16_t)(std::max(-1.f,std::min(1.f,L[i]))*32767), b=(int16_t)(std::max(-1.f,std::min(1.f,R[i]))*32767); fwrite(&a,2,1,f); fwrite(&b,2,1,f);} fclose(f);}
struct Res{float peak, rms; bool nan;};
static Res run(Params p,const char* name,bool write){
  const int sr=48000, blk=256; Engine e; e.prepare(sr,blk);
  std::vector<float> L(sr*6), R(sr*6); float pk=0; double ss=0; bool nan=false;
  // progresión: Am  F  C  G  (teclas 57,53,60,55) cada 1.2 s
  int keys[4]={57,53,60,55};
  for(int b=0;b<(int)L.size()/blk;b++){
    int t=b*blk;
    for(int k=0;k<4;k++){ int on=(int)(k*1.2*sr), off=(int)((k*1.2+1.0)*sr);
      if(on>=t && on<t+blk) e.noteOn(keys[k],0.8f,p,on-t);
      if(off>=t && off<t+blk) e.noteOff(keys[k],p,off-t);}
    e.render(&L[t],&R[t],blk,p);
  }
  for(size_t i=0;i<L.size();i++){ float a=std::fabs(L[i]); if(!std::isfinite(L[i])||!std::isfinite(R[i]))nan=true; pk=std::max(pk,a); ss+=L[i]*L[i]; }
  if(write) wav(name,L,R,sr);
  return {pk,(float)std::sqrt(ss/L.size()),nan};
}
int main(){
  const char* eng[]={"analog","fm","reed"}; const char* perf[]={"acorde","strum","slop","arp","arpa"};
  for(int en=0;en<3;en++) for(int pf=0;pf<5;pf++){
    Params p; p.engine=en; p.perf=pf; p.chorus=0.4f; p.reverbMix=0.3f; p.delayMix=0.2f; p.bassOn=(pf==0);
    char nm[64]; snprintf(nm,64,"out_%s_%s.wav",eng[en],perf[pf]);
    Res r=run(p,nm,pf==0||pf==3);
    printf("%-7s %-7s peak=%.3f rms=%.3f %s\n",eng[en],perf[pf],r.peak,r.rms,r.nan?"NAN!":"");
  }
  { Params q; q.engine=2; q.perf=4; q.release=3.f; q.reverbMix=0.5f; q.bassOn=true; q.volume=1.f; const int sr=48000; Engine e3; e3.prepare(sr,256);
    std::vector<float> L(sr*8),R(sr*8); float pk=0, maxJump=0; float prev=0;
    for(int b=0;b<(int)L.size()/256;b++){ int t=b*256; if(b%25==0){ e3.noteOn(48+(b/25)%24,1.f,q,0);} if(b%25==12) e3.noteOff(48+(b/25)%24,q,0);
      e3.render(&L[t],&R[t],256,q);}
    for(size_t i=0;i<L.size();i++){pk=std::max(pk,std::fabs(L[i])); maxJump=std::max(maxJump,std::fabs(L[i]-prev)); prev=L[i];}
    printf("estrés (arpa, release largo, bajo, volumen al máximo): pico=%.3f salto máx entre muestras=%.3f\n",pk,maxJump); wav("out_stress.wav",L,R,sr); }
  // ritmo: patrón de prueba, modo libre y modo sincronizado con el DAW
  { Params q; q.drumsOn=true; q.tempo=120; q.lanes[0]=0x0101|0x1010; q.lanes[1]=0x5555; q.lanes[2]=0x1010; q.lanes[3]=1u<<13; q.lanes[4]=1u<<14; q.lanes[5]=1u<<15; q.swing=0.3f;
    const int sr=48000; Engine e5; e5.prepare(sr,256); std::vector<float> L(sr*4),R(sr*4); int steps=0, last=-1;
    for(int b=0;b<(int)L.size()/256;b++){ e5.render(&L[b*256],&R[b*256],256,q); int s=e5.drums.uiStep.load(); if(s!=last){steps++; last=s;} }
    float pk=0; for(float x:L) pk=std::max(pk,std::fabs(x)); printf("ritmo libre 120 BPM 4 s: pico=%.3f pasos vistos~%d\n",pk,steps); wav("out_ritmo.wav",L,R,sr);
    // sincronizado: el DAW avanza la posición
    Params r=q; r.hostPpqValid=true; r.hostPlaying=true; r.hostBpm=120; Engine e6; e6.prepare(sr,512); int trig=0; last=-1; double ppq=0;
    for(int b=0;b<375;b++){ r.hostPpq=ppq; e6.render(&L[0],&R[0],512,r); ppq+=512.0/sr*120/60; int s=e6.drums.uiStep.load(); if(s!=last){trig++; last=s;} }
    printf("ritmo sincronizado: 4 s -> posición %.2f negras, cambios de paso vistos %d\n",ppq,trig); }
  // octava de la tecla
  { Params q; Engine e4; e4.prepare(48000,256); for(int k:{48,60,72}){ auto c=e4.chordNotes(k,q); printf("tecla %d ->",k); for(int i=0;i<c.n;i++)printf(" %d",c.v[i]); printf("\n"); } }
  // chord naming / types
  Params p; Engine e; e.prepare(48000,256);
  for(int t=0;t<9;t++){ p.chordType=t; auto ns=e.chordNotes(60,p); printf("tipo %d:",t); for(int i=0;i<ns.n;i++)printf(" %d",ns.v[i]); printf("\n"); }
  p.chordType=0; p.key=9; p.scale=1; for(int k:{57,59,60,62}){ auto ns=e.chordNotes(k,p); printf("auto %d:",k); for(int i=0;i<ns.n;i++)printf(" %d",ns.v[i]); printf("\n"); }
  // rendimiento: 24 voces sostenidas
  Params q; q.engine=0; q.mode=1; Engine e2; e2.prepare(48000,256); for(int k=0;k<24;k++) e2.noteOn(40+k*2,0.8f,q,0);
  std::vector<float> L(256),R(256); auto t0=std::chrono::steady_clock::now(); for(int b=0;b<1875;b++) e2.render(L.data(),R.data(),256,q); auto dt=std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count();
  printf("CPU: 10 s de audio con 24 voces analógicas en %.2f s (%.1f%% de un núcleo)\n",dt,dt/10*100);
}
