#include "PluginProcessor.h"
#include "PluginEditor.h"
using namespace juce;
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();
int main (int argc, char** argv)
{
    ScopedJuceInitialiser_GUI gui;
    String out = argc > 1 ? argv[1] : "/tmp/lirio";
    std::unique_ptr<LirioProcessor> p (dynamic_cast<LirioProcessor*> (createPluginFilter()));
    p->setPlayConfigDetails (0, 2, 48000, 512); p->prepareToPlay (48000, 512);
    AudioBuffer<float> buf (2, 512); MidiBuffer mb;
    struct Shot { int prog; int key; const char* name; int ks; };
    Shot shots[] = { { 0, 57, "1-juno", -1 }, { 5, 60, "2-arpegio", 30 }, { 2, 62, "3-fm", 29 } };
    if (auto* prm = p->apvts.getParameter ("drumsOn")) prm->setValueNotifyingHost (1.f);
    if (auto* prm = p->apvts.getParameter ("drumPattern")) prm->setValueNotifyingHost (prm->convertTo0to1 (3.f));
    for (auto& s : shots)
    {
        p->setCurrentProgram (s.prog);
        mb.clear(); if (s.ks >= 0) mb.addEvent (MidiMessage::noteOn (1, s.ks, (uint8) 100), 0);
        mb.addEvent (MidiMessage::noteOn (1, s.key, (uint8) 100), 4); p->processBlock (buf, mb);
        for (int i = 0; i < 30; ++i) { mb.clear(); p->processBlock (buf, mb); }
        std::unique_ptr<AudioProcessorEditor> ed (p->createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 20; ++i) { MessageManager::getInstance()->runDispatchLoopUntil (25); mb.clear(); p->processBlock (buf, mb); }
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        File f (out + "-" + s.name + ".png"); f.deleteFile(); FileOutputStream os (f); PNGImageFormat().writeImageToStream (img, os); os.flush();
        printf ("png %s\n", f.getFullPathName().toRawUTF8());
        mb.clear(); mb.addEvent (MidiMessage::noteOff (1, s.key), 0); p->processBlock (buf, mb);
    }
    // prueba de grabación
    p->startRecording();
    for (int i = 0; i < 100; ++i) { mb.clear(); if (i == 1) mb.addEvent (MidiMessage::noteOn (1, 60, (uint8) 100), 0); p->processBlock (buf, mb); }
    Thread::sleep (300);
    p->stopRecording();
    printf ("grabado: %s  %lld bytes\n", p->lastRecording.getFullPathName().toRawUTF8(), (long long) p->lastRecording.getSize());
    return 0;
}
