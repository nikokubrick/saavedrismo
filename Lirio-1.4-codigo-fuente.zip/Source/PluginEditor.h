#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include "PluginProcessor.h"

namespace pal // paleta pop psicodélica
{
    const juce::Colour ink     { 0xff2a1640 }; // contorno violeta oscuro
    const juce::Colour cream   { 0xfffff3d6 };
    const juce::Colour pink    { 0xffff2e88 };
    const juce::Colour orange  { 0xffff8a00 };
    const juce::Colour lemon   { 0xffffe14a };
    const juce::Colour turq    { 0xff00c2c7 };
    const juce::Colour purple  { 0xff7b3dff };
    const juce::Colour lime    { 0xff8ad63c };
    const juce::Colour sky     { 0xff4aa8ff };
    inline juce::Colour rainbow (int i) { static const juce::Colour c[] = { pink, orange, lemon, lime, turq, sky, purple }; return c[((i % 7) + 7) % 7]; }
}

class LirioLook : public juce::LookAndFeel_V4
{
public:
    LirioLook();
    juce::Font display (float h) const; // tipografía de títulos (redonda, años 60)
    juce::Font label (float h) const;   // tipografía de rótulos
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos, float a0, float a1, juce::Slider&) override;
    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour&, bool over, bool down) override;
    void drawButtonText (juce::Graphics&, juce::TextButton&, bool over, bool down) override;
    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool over, bool down) override;
    void drawComboBox (juce::Graphics&, int w, int h, bool down, int bx, int by, int bw, int bh, juce::ComboBox&) override;
    juce::Font getComboBoxFont (juce::ComboBox&) override { return label (15.f); }
    void positionComboBoxText (juce::ComboBox& b, juce::Label& l) override { l.setBounds (14, 1, b.getWidth() - 40, b.getHeight() - 4); l.setFont (label (15.f)); }
    juce::Font getPopupMenuFont() override { return label (16.f); }
    juce::Font getTextButtonFont (juce::TextButton&, int) override { return label (14.f); }
    juce::Label* createSliderTextBox (juce::Slider&) override;
    void drawLabel (juce::Graphics&, juce::Label&) override;
private:
    juce::Typeface::Ptr tDisplay, tLabel;
};

class Knob : public juce::Component
{
public:
    Knob (juce::AudioProcessorValueTreeState& s, const juce::String& id, const juce::String& text, juce::Colour c);
    void resized() override;
    void paint (juce::Graphics&) override;
    void setText (const juce::String& t) { name = t; repaint(); }
    juce::Slider slider;
private:
    juce::String name; juce::Colour colour;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> att;
};

// grupo de botones tipo píldora para un parámetro de elección
class Pills : public juce::Component
{
public:
    Pills (juce::AudioProcessorValueTreeState& s, const juce::String& id, const juce::StringArray& items, int columns, bool rainbow, std::function<void()> onPick = {});
    void resized() override;
    void sync();
    juce::OwnedArray<juce::TextButton> buttons;
private:
    juce::RangedAudioParameter* param; int cols; std::function<void()> picked;
};

class Keys : public juce::Component
{
public:
    Keys (LirioProcessor& p) : proc (p) {}
    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
private:
    int noteAt (juce::Point<float>) const;
    LirioProcessor& proc; int down = -1;
    static constexpr int lo = 36, hi = 96;
};

class DrumGrid : public juce::Component, public juce::SettableTooltipClient
{
public:
    DrumGrid (LirioProcessor& p) : proc (p) {}
    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    static constexpr int labelW = 82;
private:
    bool cellAt (juce::Point<float>, int& lane, int& step) const;
    LirioProcessor& proc; bool paintValue = true; int lastLane = -1, lastStep = -1;
};

// control de tempo: número grande (arrastrar, rueda, doble clic para escribir), botones − / + y TAP.
// En el programa independiente manda Lirio; dentro del DAW solo muestra el tempo del proyecto.
class TempoBox : public juce::Component, public juce::SettableTooltipClient
{
public:
    TempoBox (LirioProcessor& p);
    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;
    void refresh(); // llamado por el temporizador de la interfaz
private:
    bool editable() const;
    float bpm() const;
    void setBpm (float v);
    void tapped();
    juce::Rectangle<int> numberArea() const { return { 0, 18, getWidth(), 42 }; }
    LirioProcessor& proc; juce::RangedAudioParameter* param;
    juce::TextButton minus { juce::String::fromUTF8 ("−") }, tap { "TAP" }, plus { "+" };
    juce::TextEditor typer;
    float dragStart = 0.f; bool dragging = false;
    double taps[6] {}; int tapN = 0;
    juce::String shown; bool lastEditable = true;
};

class Content : public juce::Component, private juce::Timer
{
public:
    explicit Content (LirioProcessor&);
    ~Content() override;
    void paint (juce::Graphics&) override;
    void paintOverChildren (juce::Graphics&) override;
    void resized() override;
    bool keyPressed (const juce::KeyPress&) override;
private:
    void timerCallback() override;
    void pickChord (int index);
    int focusTries = 0;
    void panel (juce::Graphics&, juce::Rectangle<float>, const juce::String& title, juce::Colour accent);
    void flower (juce::Graphics&, juce::Point<float> c, float r, float rot);
    LirioProcessor& proc; LirioLook look;
    float phase = 0.f;
    std::unique_ptr<Pills> mode, chord, perf, engine;
    juce::ToggleButton add9 { "+9" }, hold { "MANTENER" }, keyswitch { "TECLAS DE CAMBIO" }, bassOn { "BAJO" }, followOct { "OCTAVA DE LA TECLA" };
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> btnAtt;
    juce::ComboBox keyBox, scaleBox, rateBox, patternBox, delayBox, bassOctBox, presetBox;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> boxAtt;
    juce::OwnedArray<Knob> knobs;
    Knob *kTone2 = nullptr, *kChar = nullptr, *kMove = nullptr;
    Keys keys;
    DrumGrid grid;
    TempoBox tempoBox;
    juce::TextButton drumPlay { "RITMO" }, recBtn { "GRABAR DEMO" }, folderBtn { "ABRIR CARPETA" };
    juce::ToggleButton drumSync { "SEGUIR AL DAW" };
    juce::ComboBox drumPatternBox;
    juce::String recText;
    juce::String chordText = "—", subText, lastSig;
    int lastEngine = -1, lastActivity = 0; float led = 0.f;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Content)
};

class LirioEditor : public juce::AudioProcessorEditor
{
public:
    explicit LirioEditor (LirioProcessor&);
    void resized() override;
    void paint (juce::Graphics& g) override { g.fillAll (pal::ink); }
    static constexpr int W = 1080, H = 908;
private:
    Content content;
};
