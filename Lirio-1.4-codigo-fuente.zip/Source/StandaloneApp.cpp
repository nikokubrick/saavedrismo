// Aplicación independiente de Lirio: igual que la de JUCE, pero abre solos todos los teclados MIDI conectados
#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_audio_devices/juce_audio_devices.h>
#include <juce_audio_plugin_client/juce_audio_plugin_client.h>
#include <juce_audio_plugin_client/Standalone/juce_StandaloneFilterWindow.h>

namespace juce
{
class LirioStandaloneApp final : public JUCEApplication
{
public:
    LirioStandaloneApp()
    {
        PropertiesFile::Options o;
        o.applicationName = "Lirio"; o.filenameSuffix = ".settings"; o.osxLibrarySubFolder = "Application Support";
       #if JUCE_LINUX || JUCE_BSD
        o.folderName = "~/.config";
       #else
        o.folderName = "Saavedrismo";
       #endif
        props.setStorageParameters (o);
    }
    const String getApplicationName() override { return "Lirio"; }
    const String getApplicationVersion() override { return JucePlugin_VersionString; }
    bool moreThanOneInstanceAllowed() override { return false; }
    void anotherInstanceStarted (const String&) override { if (window) window->toFront (true); }
    void initialise (const String&) override
    {
        window.reset (new StandaloneFilterWindow (String::fromUTF8 ("Lirio · máquina de acordes"), Colour (0xff2a1640),
                                                  props.getUserSettings(), false, {}, nullptr, {}, true /* abrir teclados MIDI solos */));
        window->setVisible (true);
    }
    void shutdown() override { window = nullptr; props.saveIfNeeded(); }
    void systemRequestedQuit() override
    {
        if (window) window->pluginHolder->savePluginState();
        quit();
    }
private:
    ApplicationProperties props;
    std::unique_ptr<StandaloneFilterWindow> window;
};
}

juce::JUCEApplicationBase* juce_CreateApplication() { return new juce::LirioStandaloneApp(); }
