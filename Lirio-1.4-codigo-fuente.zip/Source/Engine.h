// LIRIO · máquina de acordes — motor de audio (C++17 puro, sin dependencias)
// Cada tecla es la raíz de un acorde; interpretación (acorde, strum, slop, arpegio, arpa),
// tres motores de síntesis (analógico, FM, lengüeta), bajo aparte y efectos (chorus, delay, reverb).
#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>
#include <array>
#include <algorithm>
#include <atomic>

namespace lirio {

constexpr float kPi = 3.14159265358979f;
constexpr float kTwoPi = 6.28318530717959f;
constexpr int kMaxVoices = 32;
constexpr int kMaxEvents = 512;

enum ChordType { CT_Auto = 0, CT_Maj, CT_Min, CT_Sus2, CT_Sus4, CT_Dom7, CT_Maj7, CT_Min7, CT_Dim, CT_Count };
enum Perf { P_Chord = 0, P_Strum, P_Slop, P_Arp, P_Harp };
enum EngineType { E_Analog = 0, E_FM, E_Reed };

inline const char* chordSuffix (int t, bool minorTriad, bool dimTriad)
{
    switch (t)
    {
        case CT_Maj:  return "";
        case CT_Min:  return "m";
        case CT_Sus2: return "sus2";
        case CT_Sus4: return "sus4";
        case CT_Dom7: return "7";
        case CT_Maj7: return "maj7";
        case CT_Min7: return "m7";
        case CT_Dim:  return "dim";
        default:      return dimTriad ? "dim" : (minorTriad ? "m" : "");
    }
}

struct Params
{
    int   mode = 0;          // 0 acordes, 1 notas
    int   chordType = 0;
    bool  add9 = false, hold = false, keySwitch = true, followOct = true;
    int   key = 9, scale = 1; // 0 mayor, 1 menor
    int   voicing = 0, octave = 0;
    int   perf = 0;
    float strumMs = 40.f, slop = 0.5f;
    int   arpRate = 1, arpPattern = 0, arpOct = 1;
    float arpGate = 0.6f, tempo = 100.f;
    int   engine = 0;
    float bright = 0.6f, tone2 = 0.25f, character = 0.5f, movement = 0.3f;
    float attack = 0.005f, decay = 1.0f, sustain = 0.6f, release = 0.4f, velSens = 0.7f;
    bool  bassOn = false; float bassLevel = 0.6f; int bassOct = 1; float bassTone = 0.4f;
    float chorus = 0.4f, delayMix = 0.15f, delayFb = 0.35f; int delayTime = 1;
    float reverbMix = 0.25f, reverbSize = 0.7f, volume = 0.75f;
    float hostBpm = 0.f;     // >0 cuando el DAW da tempo
    // ritmo
    bool  drumsOn = false, drumSync = true, hostPlaying = false, hostPpqValid = false;
    double hostPpq = 0.0;
    float drumVol = 0.7f, swing = 0.f, drumComp = 0.6f, drumPhase = 0.35f, drumTone = 0.6f;
    uint16_t lanes[6] {};
};

// ---------------- utilidades ----------------
inline float mtof (float m) { return 440.f * std::pow (2.f, (m - 69.f) / 12.f); }
inline float polyblep (float t, float dt)
{
    if (t < dt)       { t /= dt; return t + t - t * t - 1.f; }
    if (t > 1.f - dt) { t = (t - 1.f) / dt; return t * t + t + t + 1.f; }
    return 0.f;
}
struct Rng { uint32_t s = 0x12345678u; float next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return (float) (s & 0xffffff) / 8388608.f - 1.f; } float uni() { return 0.5f * (next() + 1.f); } };

struct Adsr
{
    enum St { Idle, Att, Dec, Sus, Rel } st = Idle;
    float v = 0, a = 0.01f, d = 0.5f, s = 0.6f, r = 0.4f, sr = 48000;
    float dCo = 0, rCo = 0;
    void set (float A, float D, float S, float R, float SR) { a = std::max (A, 0.0005f); d = std::max (D, 0.005f); s = S; r = std::max (R, 0.005f); sr = SR;
        dCo = std::exp (-1.f / (d * 0.3f * sr)); rCo = std::exp (-1.f / (r * 0.3f * sr)); }
    void on()  { st = Att; }
    void off() { if (st != Idle) st = Rel; }
    float next()
    {
        switch (st)
        {
            case Att: v += 1.f / (a * sr); if (v >= 1.f) { v = 1.f; st = Dec; } break;
            case Dec: v = s + (v - s) * dCo; if (std::fabs (v - s) < 1e-4f) st = Sus; break;
            case Sus: v = s; break;
            case Rel: v *= rCo; if (v < 1e-5f) { v = 0; st = Idle; } break;
            default: v = 0; break;
        }
        return v;
    }
};

// filtro de estado variable (TPT) — 12 dB/oct; dos en serie = 24 dB/oct
struct Svf
{
    float ic1 = 0, ic2 = 0, g = 0.1f, k = 1.4f, a1 = 0, a2 = 0, a3 = 0;
    void set (float fc, float res, float sr)
    {
        fc = std::min (std::max (fc, 20.f), sr * 0.45f);
        g = std::tan (kPi * fc / sr); k = 2.f - 1.9f * std::min (std::max (res, 0.f), 1.f);
        a1 = 1.f / (1.f + g * (g + k)); a2 = g * a1; a3 = g * a2;
    }
    float lp (float x)
    {
        float v3 = x - ic2, v1 = a1 * ic1 + a2 * v3, v2 = ic2 + a2 * ic1 + a3 * v3;
        ic1 = 2.f * v1 - ic1; ic2 = 2.f * v2 - ic2; return v2;
    }
    void reset() { ic1 = ic2 = 0; }
};

// ---------------- voz ----------------
struct Voice
{
    bool active = false, released = false;
    int note = 60; float vel = 1; uint32_t tag = 0; uint64_t age = 0; float gainMul = 1;
    float freq = 261.6f;
    float ph[5] {}; float fmPh = 0, fmPh2 = 0;
    Adsr amp, fenv; Svf f1, f2; Rng rng; float noiseEnv = 0, relThump = 0, lp1 = 0;
    int ctr = 0; float idxEnv = 0; float lastOut = 0, declick = 0;

    void start (int n, float v, uint32_t t, uint64_t a, const Params& p, float sr)
    {
        declick = active ? lastOut : 0.f; // si se reutiliza una voz que sonaba, se evita el "click"
        active = true; released = false; note = n; vel = v; tag = t; age = a;
        freq = mtof ((float) n);
        for (auto& x : ph) x = rng.uni();
        fmPh = fmPh2 = 0;
        if (p.engine == E_Analog) amp.set (p.attack, p.decay, p.sustain, p.release, sr);
        else // FM y lengüeta: envolvente de decaimiento natural
            amp.set (std::min (p.attack, 0.5f), p.decay * 1.6f, p.sustain, p.release, sr);
        fenv.set (0.002f, p.decay * 0.6f + 0.05f, 0.0f, p.release, sr);
        amp.v = 0; amp.on(); fenv.v = 0; fenv.on(); f1.reset(); f2.reset();
        noiseEnv = 1.f; relThump = 0; idxEnv = 1.f; ctr = 0; lp1 = 0;
        rng.s ^= (uint32_t) (n * 2654435761u + t);
    }
    void stop() { if (!released) { released = true; amp.off(); fenv.off(); relThump = 1.f; } }

    // devuelve una muestra mono; bend = factor de frecuencia, vib = desplazamiento por LFO
    inline float render (const Params& p, float sr, float bend, float lfo, float lfoSlow)
    {
        if (! active) return 0.f;
        const float e = amp.next();
        if (amp.st == Adsr::Idle) { active = false; lastOut = 0; declick = 0.f; return 0.f; }
        const float velG = (1.f - p.velSens) + p.velSens * vel;
        float out = 0.f;
        const float f = freq * bend * (1.f + lfo);

        if (p.engine == E_Analog)
        {
            const float det = 1.f + p.movement * 0.012f;
            const float dt0 = f / sr, dt1 = f * det / sr, dt2 = f * 0.5f / sr;
            float s0 = 2.f * ph[0] - 1.f - polyblep (ph[0], dt0);
            float s1 = 2.f * ph[1] - 1.f - polyblep (ph[1], dt1);
            float pw = 0.5f + 0.35f * p.movement * lfoSlow;
            float t2 = ph[2] + pw; if (t2 >= 1.f) t2 -= 1.f;
            float pu = (ph[2] < pw ? 1.f : -1.f) + polyblep (ph[2], dt0) - polyblep (t2, dt0);
            float sub = (ph[3] < 0.5f ? 1.f : -1.f) + polyblep (ph[3], dt2) - polyblep (std::fmod (ph[3] + 0.5f, 1.f), dt2);
            ph[0] += dt0; if (ph[0] >= 1.f) ph[0] -= 1.f;
            ph[1] += dt1; if (ph[1] >= 1.f) ph[1] -= 1.f;
            ph[2] += dt0; if (ph[2] >= 1.f) ph[2] -= 1.f;
            ph[3] += dt2; if (ph[3] >= 1.f) ph[3] -= 1.f;
            float x = 0.42f * s0 + 0.3f * s1 + 0.22f * pu + 0.28f * sub;
            const float fe = fenv.next();
            if ((ctr++ & 7) == 0)
            {
                float base = 60.f * std::pow (250.f, p.bright);
                float kt = std::pow (f / 261.6f, 0.5f);
                float env = std::pow (2.f, fe * p.character * 6.f * (0.4f + 0.6f * vel));
                float fc = base * kt * env;
                f1.set (fc, p.tone2, sr); f2.set (fc, p.tone2 * 0.3f, sr);
            }
            out = f2.lp (f1.lp (x)) * 0.55f;
        }
        else if (p.engine == E_FM)
        {
            // relación del modulador elegida con "Relación" (tone2)
            static const float ratios[] = { 0.5f, 1.f, 2.f, 3.f, 3.5f, 4.f, 5.f, 7.f };
            const int ri = std::min (7, (int) (p.tone2 * 7.99f));
            const float ratio = ratios[ri];
            idxEnv *= std::exp (-1.f / (sr * (0.08f + p.decay * 0.35f)));
            const float I = (0.4f + p.character * 6.f) * (0.35f + 0.65f * vel) * (0.25f + 0.75f * idxEnv) * (0.5f + p.bright);
            const float m = std::sin (kTwoPi * fmPh) * I;
            // "tine": modulador agudo muy corto (ataque tipo piano eléctrico)
            const float tine = std::sin (kTwoPi * fmPh2) * 1.6f * vel * idxEnv * idxEnv * idxEnv;
            out = std::sin (kTwoPi * ph[0] + m + (f * 14.f < sr * 0.4f ? tine : 0.f)) * 0.5f;
            ph[0] += f / sr; if (ph[0] >= 1.f) ph[0] -= 1.f;
            fmPh += f * ratio / sr; if (fmPh >= 1.f) fmPh -= 1.f;
            fmPh2 += f * 14.f / sr; if (fmPh2 >= 1.f) fmPh2 -= 1.f;
            out *= 1.f + 0.5f * p.movement * lfoSlow; // movimiento = trémolo suave
        }
        else // E_Reed: piano eléctrico de lengüeta con ruido mecánico
        {
            idxEnv *= std::exp (-1.f / (sr * 0.25f));
            const float I = (0.3f + 1.2f * vel) * (0.3f + 0.7f * idxEnv);
            const float m = std::sin (kTwoPi * fmPh) * I;
            float x = std::sin (kTwoPi * ph[0] + m) + (0.25f + 0.25f * vel) * std::sin (2.f * kTwoPi * ph[0]) + 0.08f * vel * std::sin (3.f * kTwoPi * ph[0]);
            ph[0] += f / sr; if (ph[0] >= 1.f) ph[0] -= 1.f;
            fmPh += f / sr; if (fmPh >= 1.f) fmPh -= 1.f;
            const float drive = 1.f + p.character * 4.f * vel;
            x = std::tanh (x * drive) / std::tanh (drive);
            // ruido mecánico: golpe al tocar y "thump" al soltar
            noiseEnv *= 0.9965f; relThump *= 0.993f;
            const float n = rng.next();
            lp1 += 0.08f * (n - lp1);
            const float mech = p.tone2 * (noiseEnv * vel * 0.5f * (n - lp1) + relThump * 0.25f * lp1);
            out = (x * 0.45f + mech * 0.6f);
            if ((ctr++ & 7) == 0) f1.set (900.f * std::pow (14.f, p.bright) * (0.6f + 0.4f * vel), 0.1f, sr);
            out = f1.lp (out);
            out *= 1.f + 0.6f * p.movement * lfoSlow; // trémolo
        }
        declick *= 0.96f;
        lastOut = out * e * velG * gainMul + declick;
        return lastOut;
    }
};

// ---------------- bajo (mono) ----------------
struct Bass
{
    bool active = false; int note = 36; float vel = 1; Adsr amp; float ph = 0, ph2 = 0, lp = 0; uint32_t tag = 0;
    void start (int n, float v, uint32_t t, float sr) { note = n; vel = v; tag = t; active = true; amp.set (0.004f, 0.6f, 0.75f, 0.18f, sr); amp.on(); }
    void stop() { amp.off(); }
    float render (const Params& p, float sr, float bend)
    {
        if (! active) return 0.f;
        float e = amp.next(); if (amp.st == Adsr::Idle) { active = false; return 0.f; }
        const float f = mtof ((float) note) * bend, dt = f / sr;
        float sine = std::sin (kTwoPi * ph);
        float saw = 2.f * ph2 - 1.f - polyblep (ph2, dt);
        ph += dt; if (ph >= 1.f) ph -= 1.f; ph2 += dt; if (ph2 >= 1.f) ph2 -= 1.f;
        const float c = 1.f - std::exp (-kTwoPi * (120.f + 1800.f * p.bassTone * p.bassTone) / sr);
        lp += c * (saw - lp);
        return (0.75f * sine + 0.5f * p.bassTone * lp + 0.15f * lp) * e * (0.6f + 0.4f * vel) * p.bassLevel * 0.55f;
    }
};

// ---------------- efectos ----------------
struct DelayLine
{
    std::vector<float> b; int w = 0;
    void init (int n) { b.assign ((size_t) std::max (n, 4), 0.f); w = 0; }
    void push (float x) { b[(size_t) w] = x; if (++w >= (int) b.size()) w = 0; }
    float tap (float d) const // d en muestras (fraccional)
    {
        float r = (float) w - d - 1.f; while (r < 0) r += (float) b.size();
        int i = (int) r; float fr = r - (float) i; int j = i + 1; if (j >= (int) b.size()) j = 0;
        return b[(size_t) i] + fr * (b[(size_t) j] - b[(size_t) i]);
    }
};

struct Comb { std::vector<float> b; int i = 0; float store = 0;
    void init (int n) { b.assign ((size_t) n, 0.f); i = 0; store = 0; }
    float process (float x, float fb, float damp) { float o = b[(size_t) i]; store = o * (1.f - damp) + store * damp; b[(size_t) i] = x + store * fb; if (++i >= (int) b.size()) i = 0; return o; } };
struct Allp { std::vector<float> b; int i = 0;
    void init (int n) { b.assign ((size_t) n, 0.f); i = 0; }
    float process (float x) { float o = b[(size_t) i]; b[(size_t) i] = x + o * 0.5f; if (++i >= (int) b.size()) i = 0; return o - x; } };

struct Reverb // tipo Freeverb, estéreo
{
    Comb cl[8], cr[8]; Allp al[4], ar[4];
    void init (float sr)
    {
        static const int ct[8] = { 1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617 };
        static const int at[4] = { 556, 441, 341, 225 };
        const float k = sr / 44100.f;
        for (int n = 0; n < 8; ++n) { cl[n].init ((int) (ct[n] * k)); cr[n].init ((int) ((ct[n] + 23) * k)); }
        for (int n = 0; n < 4; ++n) { al[n].init ((int) (at[n] * k)); ar[n].init ((int) ((at[n] + 23) * k)); }
    }
    void process (float inL, float inR, float size, float& oL, float& oR)
    {
        const float fb = 0.7f + 0.28f * size, damp = 0.35f - 0.15f * size, in = (inL + inR) * 0.015f;
        float l = 0, r = 0;
        for (int n = 0; n < 8; ++n) { l += cl[n].process (in, fb, damp); r += cr[n].process (in, fb, damp); }
        for (int n = 0; n < 4; ++n) { l = al[n].process (l); r = ar[n].process (r); }
        oL = l; oR = r;
    }
};


// ---------------- caja de ritmos: bombo, hi-hat, redoblante y 3 toms ----------------
// sonido setentoso: saturado, muy comprimido y con fase (phaser) en el bus
enum DrumLane { D_Kick = 0, D_Hat, D_Snare, D_TomHi, D_TomMid, D_TomLo, D_Count };

struct DrumVoice
{
    bool active = false; int type = 0; float t = 0, vel = 1, ph = 0, ph2 = 0, hp = 0, prevN = 0, lp = 0; Rng rng;
    float mph[6] {};
    void trigger (int ty, float v) { active = true; type = ty; t = 0; vel = v; ph = ph2 = 0; hp = prevN = lp = 0; for (auto& m : mph) m = rng.uni(); }
    float render (float sr, float tone)
    {
        if (! active) return 0.f;
        const float ts = t / sr; t += 1.f; float out = 0.f;
        const float n = rng.next();
        switch (type)
        {
            case D_Kick:
            {
                const float f = 48.f + 120.f * std::exp (-ts / 0.035f);
                ph += f / sr; if (ph >= 1.f) ph -= 1.f;
                const float body = std::sin (kTwoPi * ph) * std::exp (-ts / 0.32f);
                const float click = n * std::exp (-ts / 0.0015f) * 0.35f;
                out = std::tanh ((body + click) * 1.8f) * 0.95f;
                if (ts > 1.2f) active = false; break;
            }
            case D_Snare:
            {
                const float f = 175.f + 90.f * std::exp (-ts / 0.02f);
                ph += f / sr; if (ph >= 1.f) ph -= 1.f; ph2 += f * 1.87f / sr; if (ph2 >= 1.f) ph2 -= 1.f;
                const float body = (std::sin (kTwoPi * ph) + 0.4f * std::sin (kTwoPi * ph2)) * std::exp (-ts / 0.07f) * 0.55f;
                hp = n - prevN + 0.6f * hp; prevN = n;               // agudos del ruido (cuerdas del redoblante)
                lp += (0.25f + 0.5f * tone) * (hp - lp);
                const float noise = lp * (std::exp (-ts / 0.16f) + 0.45f * std::exp (-std::fabs (ts - 0.012f) / 0.006f)) * 0.75f;
                out = std::tanh ((body + noise) * 2.2f) * 0.75f;
                if (ts > 0.8f) active = false; break;
            }
            case D_Hat:
            {
                static const float r[6] = { 205.3f, 304.4f, 369.6f, 522.7f, 540.f, 800.f };
                float m = 0; for (int k = 0; k < 6; ++k) { mph[k] += r[k] * 2.4f / sr; if (mph[k] >= 1.f) mph[k] -= 1.f; m += mph[k] < 0.5f ? 1.f : -1.f; }
                const float x = m * 0.12f + n * 0.5f;
                hp = x - prevN + 0.2f * hp; prevN = x;
                out = hp * std::exp (-ts / (0.025f + 0.03f * tone)) * 0.45f;
                if (ts > 0.4f) active = false; break;
            }
            default: // toms
            {
                const float base = type == D_TomHi ? 196.f : type == D_TomMid ? 138.f : 92.f;
                const float dec  = type == D_TomHi ? 0.32f : type == D_TomMid ? 0.42f : 0.55f;
                const float f = base * (1.f + 0.45f * std::exp (-ts / 0.05f));
                ph += f / sr; if (ph >= 1.f) ph -= 1.f;
                const float body = std::sin (kTwoPi * ph) * std::exp (-ts / dec);
                lp += 0.2f * (n - lp);
                const float stick = lp * std::exp (-ts / 0.008f) * 0.6f;
                out = std::tanh ((body + stick) * 2.f) * 0.8f;
                if (ts > 2.f) active = false; break;
            }
        }
        return out * vel;
    }
};

struct DrumKit
{
    DrumVoice v[12]; int nextV = 0;
    // bus: saturación + compresor + phaser
    float env = 0, gain = 1, atk = 0, rel = 0, sr = 48000;
    float apL[4] {}, apR[4] {}, phLfo = 0, fbL = 0, fbR = 0, warm = 0, warmR = 0;
    int nextK = 0; double freeT = 0, expectQ = -1; bool running = false;
    std::atomic<int> uiStep { -1 };

    void prepare (float s) { sr = s; atk = 1.f - std::exp (-1.f / (0.002f * sr)); rel = 1.f - std::exp (-1.f / (0.12f * sr)); running = false; for (auto& x : v) x.active = false; }
    void hit (int lane, float vel) { auto& d = v[nextV]; nextV = (nextV + 1) % 12; d.trigger (lane, vel); }
    void triggerStep (int k, const Params& p)
    {
        const int s16 = ((k % 16) + 16) % 16; uiStep.store (s16);
        const float acc = (s16 % 4 == 0) ? 1.f : (s16 % 2 == 0 ? 0.85f : 0.72f);
        for (int lane = 0; lane < D_Count; ++lane)
            if ((p.lanes[lane] >> s16) & 1u) hit (lane, acc);
    }
    // posición del paso k en semicorcheas, con swing en los pasos impares
    static double stepPos (int k, float swing) { return (double) k + ((k & 1) ? swing * 0.5 : 0.0); }

    // avanza una muestra; dawQ = posición del DAW en semicorcheas (o <0 si no hay)
    void clock (const Params& p, float bpm, double dawQ)
    {
        const bool synced = p.drumSync && p.hostPpqValid;
        const bool shouldRun = p.drumsOn && (! synced || p.hostPlaying);
        if (! shouldRun) { running = false; uiStep.store (-1); return; }
        double q;
        if (synced) q = dawQ;
        else { if (! running) freeT = 0; q = freeT * bpm / 60.0 * 4.0 / sr; freeT += 1.0; }
        if (! running || std::fabs (q - expectQ) > 0.5) // arranque o salto de posición
        {
            int k = (int) std::floor (q) - 1; while (stepPos (k, p.swing) < q - 1e-9) ++k; nextK = k;
            running = true;
        }
        while (q >= stepPos (nextK, p.swing)) { triggerStep (nextK, p); ++nextK; }
        expectQ = q + bpm / 60.0 * 4.0 / sr;
    }
    void render (const Params& p, float& outL, float& outR)
    {
        float m = 0, side = 0;
        for (auto& d : v) if (d.active)
        {
            const float x = d.render (sr, p.drumTone);
            m += x;
            if (d.type == D_Hat) side += x * 0.35f; else if (d.type == D_TomHi) side -= x * 0.4f; else if (d.type == D_TomLo) side += x * 0.4f;
        }
        // saturación de cinta y tono cálido
        float l = std::tanh ((m - side) * 1.3f), r = std::tanh ((m + side) * 1.3f);
        const float c = 0.35f + 0.6f * p.drumTone; warm += c * (l - warm); warmR += c * (r - warmR); l = warm; r = warmR;
        // compresor que "respira" (mezcla en paralelo según el knob)
        const float pk = std::max (std::fabs (l), std::fabs (r));
        env += (pk > env ? atk : rel) * (pk - env);
        const float thr = 0.12f, ratio = 6.f;
        const float g = env > thr ? std::pow (env / thr, 1.f / ratio - 1.f) : 1.f;
        const float cmp = g * 2.6f;
        l = l * (1.f - p.drumComp) + l * cmp * p.drumComp; r = r * (1.f - p.drumComp) + r * cmp * p.drumComp;
        // phaser estéreo
        phLfo += 0.22f / sr; if (phLfo >= 1.f) phLfo -= 1.f;
        const float sweep = 0.5f + 0.5f * std::sin (kTwoPi * phLfo);
        const float a = 0.55f + 0.4f * sweep, aR = 0.55f + 0.4f * (1.f - sweep);
        float xl = l + fbL * 0.55f, xr = r + fbR * 0.55f;
        for (int k = 0; k < 4; ++k) { const float yl = -a * xl + apL[k]; apL[k] = xl + a * yl; xl = yl; const float yr = -aR * xr + apR[k]; apR[k] = xr + aR * yr; xr = yr; }
        fbL = xl; fbR = xr;
        l = l * (1.f - 0.5f * p.drumPhase) + xl * 0.5f * p.drumPhase * 2.f;
        r = r * (1.f - 0.5f * p.drumPhase) + xr * 0.5f * p.drumPhase * 2.f;
        const float vol = p.drumVol * p.drumVol * 0.9f;
        outL = l * vol; outR = r * vol;
    }
};

// ---------------- motor ----------------
struct Chord { int n = 0; int v[8] {}; void add (int x) { if (n < 8) v[n++] = x; } };

class Engine
{
public:
    // información para la interfaz (se lee desde otro hilo)
    std::atomic<int> uiRoot { -1 }, uiType { 0 }, uiMinor { 0 }, uiDim { 0 }, uiActivity { 0 }, uiEffType { 0 }, uiKs { -1 };
    std::atomic<uint64_t> uiNotesLo { 0 }, uiNotesHi { 0 }; // notas sonando (0..127)
    int ksType = -1; // tipo elegido con teclas de cambio (anula al parámetro hasta que se toque la matriz)

    void prepare (double sampleRate, int /*maxBlock*/)
    {
        sr = (float) sampleRate;
        for (auto& v : voices) v = Voice();
        bass = Bass();
        chL.init ((int) (sr * 0.05f)); chR.init ((int) (sr * 0.05f));
        dlL.init ((int) (sr * 2.6f)); dlR.init ((int) (sr * 2.6f));
        rev.init (sr); drums.prepare (sr);
        evCount = 0; nowS = 0; tagCounter = 1; heldN = 0; arpOn = false; dlLp = 0; dlRp = 0;
        smK = 1.f - std::exp (-1.f / (0.03f * sr)); smKd = 1.f - std::exp (-1.f / (0.15f * sr));
        limRel = 1.f - std::exp (-1.f / (0.15f * sr)); limGain = 1.f; smInit = false;
    }

    // ---- MIDI ----
    void noteOn (int key, float vel, const Params& p, int offset)
    {
        if (p.keySwitch && p.mode == 0 && key >= 24 && key <= 32) { ksType = key - 24; uiKs.store (ksType); uiActivity.fetch_add (1); return; }
        uiActivity.fetch_add (1);
        if (p.hold && p.mode == 0) // mantener: un acorde nuevo reemplaza al anterior; la misma tecla lo apaga
        {
            const bool same = heldN > 0 && held[heldN - 1].key == key;
            for (int k = 0; k < heldN; ++k) releaseHeld (held[k]);
            heldN = 0;
            if (same) { stopArp(); uiRoot.store (-1); return; }
        }
        removeHeld (key);
        if (heldN >= kMaxHeld) { releaseHeld (held[0]); removeAt (0); }
        Held& H = held[heldN++];
        H.key = key; H.vel = vel; H.tag = tagCounter++; H.pedalHeld = false; H.notes = Chord();
        if (p.mode == 0) H.notes = chordNotes (key, p); else H.notes.add (key + 12 * p.octave);
        const uint64_t t0 = nowS + (uint64_t) offset;
        const int n = H.notes.n;
        if (p.perf == P_Arp) { if (! arpOn) { arpOn = true; arpNext = t0; arpIdx = 0; } }
        else if (p.perf == P_Strum)
        {
            const bool down = strumDown; strumDown = ! strumDown;
            for (int i = 0; i < n; ++i) pushEv (t0 + (uint64_t) (i * p.strumMs * 0.001f * sr), 1, H.notes.v[down ? n - 1 - i : i], vel, H.tag);
        }
        else if (p.perf == P_Slop)
        {
            for (int i = 0; i < n; ++i)
            {
                const float d = rng.uni() * (0.012f + 0.09f * p.slop);
                const float v = std::min (1.f, std::max (0.05f, vel * (1.f + rng.next() * 0.3f * p.slop)));
                pushEv (t0 + (uint64_t) (d * sr), 1, H.notes.v[i], v, H.tag);
            }
        }
        else if (p.perf == P_Harp)
        {
            const float step = 0.025f + p.strumMs * 0.0009f; int k = 0;
            for (int o = 0; o < 3; ++o) for (int i = 0; i < n; ++i, ++k)
                pushEv (t0 + (uint64_t) ((float) k * step * sr), 1, H.notes.v[i] + 12 * o, vel * (1.f - 0.02f * (float) k), H.tag);
        }
        else for (int i = 0; i < n; ++i) pushEv (t0, 1, H.notes.v[i], vel, H.tag);
        if (p.bassOn && p.mode == 0)
        {
            int bn = (p.followOct ? key : 48 + key % 12) + 12 * p.octave - 12 * (p.bassOct + 1);
            while (bn < 28) bn += 12;
            pushEv (t0, 2, bn, vel, H.tag);
        }
        publishChord (key, p);
    }
    void noteOff (int key, const Params& p, int /*offset*/)
    {
        if (p.keySwitch && p.mode == 0 && key >= 24 && key <= 32) return;
        if (sustainPedal) { for (int k = 0; k < heldN; ++k) if (held[k].key == key) held[k].pedalHeld = true; return; }
        if (p.hold && p.mode == 0) return;
        for (int k = 0; k < heldN; ++k) if (held[k].key == key) releaseHeld (held[k]);
        removeHeld (key);
        if (heldN == 0) stopArp();
    }
    void sustain (bool on, const Params& p)
    {
        sustainPedal = on;
        if (! on)
        {
            for (int k = 0; k < heldN;) { if (held[k].pedalHeld) { releaseHeld (held[k]); removeAt (k); } else ++k; }
            if (heldN == 0 && ! p.hold) stopArp();
        }
    }
    void allOff() { for (auto& v : voices) v.stop(); bass.stop(); heldN = 0; evCount = 0; arpOn = false; }
    void pitchBend (float semis) { bend = std::pow (2.f, semis / 12.f); }
    void modWheel (float v) { mod = v; }

    // ---- audio ----
    void render (float* L, float* R, int n, const Params& p)
    {
        const float bpm = p.hostBpm > 0 ? p.hostBpm : p.tempo;
        static const float dTimes[] = { 1.f, 0.75f, 0.5f, 0.25f, 2.f / 3.f };
        const float dTarget = std::min (2.5f, 60.f / bpm * dTimes[std::min (4, std::max (0, p.delayTime))]) * sr;
        const float volTarget = p.volume * p.volume * 1.4f;
        if (! smInit) { smVol = volTarget; smDel = dTarget; smCh = p.chorus; smDm = p.delayMix; smRm = p.reverbMix; smInit = true; }
        uint64_t notesLo = 0, notesHi = 0;
        const float thr = 0.89f; // -1 dBFS

        const double qPerSample = bpm / 60.0 * 4.0 / sr;
        for (int i = 0; i < n; ++i)
        {
            const uint64_t t = nowS + (uint64_t) i;
            drums.clock (p, bpm, p.hostPpqValid ? p.hostPpq * 4.0 + qPerSample * i : -1.0);
            processEvents (t, p);
            if (arpOn) arpTick (t, p, bpm);
            // valores suavizados (sin saltos ni "zipper" al mover knobs)
            smVol += smK * (volTarget - smVol); smCh += smK * (p.chorus - smCh);
            smDm += smK * (p.delayMix - smDm); smRm += smK * (p.reverbMix - smRm); smDel += smKd * (dTarget - smDel);

            lfoPh += 5.6f / sr; if (lfoPh >= 1.f) lfoPh -= 1.f;
            lfo2 += (0.35f + 3.5f * p.movement) / sr; if (lfo2 >= 1.f) lfo2 -= 1.f;
            const float vib = std::sin (kTwoPi * lfoPh) * mod * 0.012f;
            const float ls = std::sin (kTwoPi * lfo2);
            float s = 0.f;
            for (auto& v : voices) if (v.active) s += v.render (p, sr, bend, vib, ls);
            const float b = bass.render (p, sr, bend);

            // chorus estéreo
            chPh += 0.52f / sr; if (chPh >= 1.f) chPh -= 1.f;
            chL.push (s); chR.push (s);
            const float dl = (0.0068f + 0.0019f * std::sin (kTwoPi * chPh)) * sr;
            const float dr = (0.0074f + 0.0019f * std::sin (kTwoPi * (chPh + 0.37f))) * sr;
            float l = s * (1.f - 0.35f * smCh) + chL.tap (dl) * 0.8f * smCh;
            float r = s * (1.f - 0.35f * smCh) + chR.tap (dr) * 0.8f * smCh;

            // delay ping-pong
            const float dIn = (l + r) * 0.5f;
            const float tapL = dlL.tap (smDel), tapR = dlR.tap (smDel);
            dlLp += 0.35f * (tapL - dlLp); dlRp += 0.35f * (tapR - dlRp);
            dlL.push (dIn + dlRp * p.delayFb); dlR.push (dlLp * p.delayFb);
            l += tapL * smDm * 1.2f; r += tapR * smDm * 1.2f;

            // reverb
            float rl, rr; rev.process (l, r, p.reverbSize, rl, rr);
            float dL = 0, dR = 0; drums.render (p, dL, dR);
            l = (l * (1.f - 0.4f * smRm) + rl * smRm * 1.3f + b) * smVol + dL;
            r = (r * (1.f - 0.4f * smRm) + rr * smRm * 1.3f + b) * smVol + dR;

            // limitador de salida: baja el volumen solo en los picos, sin distorsionar
            const float pk = std::max (std::fabs (l), std::fabs (r));
            const float target = pk > thr ? thr / pk : 1.f;
            if (target < limGain) limGain = target; else limGain += limRel * (target - limGain);
            L[i] = std::max (-1.f, std::min (1.f, l * limGain));
            R[i] = std::max (-1.f, std::min (1.f, r * limGain));
        }
        nowS += (uint64_t) n;
        for (auto& v : voices) if (v.active && ! v.released) { if (v.note < 64) notesLo |= (1ull << v.note); else if (v.note < 128) notesHi |= (1ull << (v.note - 64)); }
        uiNotesLo.store (notesLo); uiNotesHi.store (notesHi); uiLimit.store (limGain);
    }
    std::atomic<float> uiLimit { 1.f };
    DrumKit drums;

    Chord chordNotes (int key, const Params& p) const
    {
        const int pc = key % 12;
        const int type = effectiveType (p);
        int iv[5] = { 0, 4, 7, -1, -1 }; int ni = 3;
        static const int SCL[2][7] = { { 0, 2, 4, 5, 7, 9, 11 }, { 0, 2, 3, 5, 7, 8, 10 } };
        auto set = [&] (std::initializer_list<int> l) { ni = 0; for (int x : l) iv[ni++] = x; };
        switch (type)
        {
            case CT_Maj: set ({ 0, 4, 7 }); break;     case CT_Min: set ({ 0, 3, 7 }); break;
            case CT_Sus2: set ({ 0, 2, 7 }); break;    case CT_Sus4: set ({ 0, 5, 7 }); break;
            case CT_Dom7: set ({ 0, 4, 7, 10 }); break; case CT_Maj7: set ({ 0, 4, 7, 11 }); break;
            case CT_Min7: set ({ 0, 3, 7, 10 }); break; case CT_Dim: set ({ 0, 3, 6 }); break;
            default:
            {
                const int* sc = SCL[p.scale ? 1 : 0];
                const int rel = (pc - p.key + 12) % 12;
                int d = -1; for (int k = 0; k < 7; ++k) if (sc[k] == rel) d = k;
                if (d < 0) set ({ 0, 4, 7 });
                else set ({ 0, (sc[(d + 2) % 7] - rel + 12) % 12, (sc[(d + 4) % 7] - rel + 12) % 12 });
            }
        }
        if (p.add9) iv[ni++] = 14;
        // la raíz sale de la tecla tocada (con su octava) o, si se desactiva, siempre en la misma zona
        const int root = (p.followOct ? key : 48 + pc) + 12 * p.octave;
        int arr[8]; int n = ni;
        for (int k = 0; k < n; ++k) arr[k] = root + iv[k];
        std::sort (arr, arr + n);
        int v = p.voicing;
        while (v > 0) { const int x = arr[0]; for (int k = 0; k < n - 1; ++k) arr[k] = arr[k + 1]; arr[n - 1] = x + 12; --v; }
        while (v < 0) { const int x = arr[n - 1]; for (int k = n - 1; k > 0; --k) arr[k] = arr[k - 1]; arr[0] = x - 12; ++v; }
        Chord c; for (int k = 0; k < n; ++k) c.add (std::min (120, std::max (12, arr[k])));
        return c;
    }
    int effectiveType (const Params& p) const { return ksType >= 0 ? ksType : p.chordType; }

private:
    static constexpr int kMaxHeld = 16;
    struct Ev { uint64_t t; int type; int note; float vel; uint32_t tag; };
    struct Held { int key = 0; float vel = 0; uint32_t tag = 0; Chord notes; bool pedalHeld = false; };

    float sr = 48000.f, bend = 1.f, mod = 0.f, lfoPh = 0, lfo2 = 0, chPh = 0, dlLp = 0, dlRp = 0;
    float smK = 0.001f, smKd = 0.0001f, smVol = 1, smDel = 0, smCh = 0, smDm = 0, smRm = 0; bool smInit = false;
    float limGain = 1.f, limRel = 0.0001f;
    uint64_t nowS = 0, ageCtr = 0; uint32_t tagCounter = 1;
    std::array<Voice, kMaxVoices> voices; Bass bass;
    Ev evs[kMaxEvents]; int evCount = 0;
    Held held[kMaxHeld]; int heldN = 0;
    bool sustainPedal = false, strumDown = false;
    bool arpOn = false; uint64_t arpNext = 0, arpOffAt = 0; int arpIdx = 0; uint32_t arpVoiceTag = 0;
    DelayLine chL, chR, dlL, dlR; Reverb rev; Rng rng;

    void stopArp() { arpOn = false; if (arpVoiceTag) { stopTag (arpVoiceTag); arpVoiceTag = 0; } }
    void pushEv (uint64_t t, int type, int note, float vel, uint32_t tag)
    {
        if (evCount >= kMaxEvents) return;
        evs[evCount++] = { t, type, note, vel, tag };
    }
    void processEvents (uint64_t t, const Params& p)
    {
        for (int k = 0; k < evCount;)
        {
            if (evs[k].t <= t)
            {
                const Ev e = evs[k]; evs[k] = evs[--evCount];
                if (e.type == 1) startVoice (e.note, e.vel, e.tag, p);
                else if (e.type == 2) bass.start (e.note, e.vel, e.tag, sr);
            }
            else ++k;
        }
    }
    void startVoice (int note, float vel, uint32_t tag, const Params& p)
    {
        // 1) la misma nota del mismo acorde, 2) una voz libre, 3) la voz soltada más baja, 4) la más baja de todas
        Voice* best = nullptr;
        for (auto& v : voices) if (v.active && v.note == note && v.tag == tag) { best = &v; break; }
        if (! best) for (auto& v : voices) if (! v.active) { best = &v; break; }
        if (! best) { float lo = 1e9f; for (auto& v : voices) if (v.released && v.amp.v < lo) { lo = v.amp.v; best = &v; } }
        if (! best) { float lo = 1e9f; for (auto& v : voices) if (v.amp.v < lo) { lo = v.amp.v; best = &v; } }
        best->gainMul = 0.3f;
        best->start (note, vel, tag, ++ageCtr, p, sr);
    }
    void stopTag (uint32_t tag) { for (auto& v : voices) if (v.active && v.tag == tag) v.stop(); if (bass.active && bass.tag == tag) bass.stop(); }
    void releaseHeld (Held& h)
    {
        stopTag (h.tag);
        for (int k = 0; k < evCount;) { if (evs[k].tag == h.tag) evs[k] = evs[--evCount]; else ++k; } // cancela notas pendientes de un strum
    }
    void removeAt (int i) { for (int k = i; k < heldN - 1; ++k) held[k] = held[k + 1]; --heldN; }
    void removeHeld (int key) { for (int k = 0; k < heldN;) { if (held[k].key == key) removeAt (k); else ++k; } }

    void arpTick (uint64_t t, const Params& p, float bpm)
    {
        if (arpVoiceTag && t >= arpOffAt) { stopTag (arpVoiceTag); arpVoiceTag = 0; }
        if (t < arpNext) return;
        // notas disponibles: todas las de los acordes sostenidos, ordenadas y sin repetir, en N octavas
        bool has[128] {}; int pool[128]; int pc = 0;
        for (int k = 0; k < heldN; ++k) for (int i = 0; i < held[k].notes.n; ++i) has[held[k].notes.v[i] & 127] = true;
        for (int m = 0; m < 128; ++m) if (has[m]) pool[pc++] = m;
        if (pc == 0) { arpOn = false; return; }
        const int oct = std::max (1, std::min (4, p.arpOct)), n = pc * oct;
        int idx = 0;
        switch (p.arpPattern)
        {
            case 1: idx = (n - 1) - (arpIdx % n); ++arpIdx; break;
            case 2: { if (n < 2) { idx = 0; break; } const int per = 2 * n - 2; const int k = arpIdx % per; idx = k < n ? k : per - k; ++arpIdx; break; }
            case 3: idx = (int) (rng.uni() * (float) n) % n; break;
            default: idx = arpIdx % n; ++arpIdx; break;
        }
        const int note = std::min (120, pool[idx % pc] + 12 * (idx / pc));
        static const float rates[] = { 1.f, 0.5f, 1.f / 3.f, 0.25f, 1.f / 6.f, 0.125f };
        const float stepS = 60.f / bpm * rates[std::min (5, std::max (0, p.arpRate))];
        const uint32_t tag = tagCounter++;
        startVoice (note, heldN ? held[heldN - 1].vel : 0.8f, tag, p);
        arpVoiceTag = tag;
        arpOffAt = t + (uint64_t) (stepS * p.arpGate * sr);
        arpNext = t + (uint64_t) (stepS * sr);
    }

    void publishChord (int key, const Params& p)
    {
        if (p.mode != 0) { uiRoot.store (key); uiType.store (-1); return; }
        const int pc = key % 12; const int type = effectiveType (p);
        uiRoot.store (pc); uiEffType.store (type);
        if (type == CT_Auto)
        {
            const Chord c = chordNotes (key, p); bool m3 = false, d5 = false;
            for (int i = 0; i < c.n; ++i) { const int r = ((c.v[i] % 12) - pc + 12) % 12; if (r == 3) m3 = true; if (r == 6) d5 = true; }
            uiMinor.store (m3 ? 1 : 0); uiDim.store (m3 && d5 ? 1 : 0);
        }
        uiType.store (type);
    }
};

} // namespace lirio
