#include "PluginEditor.h"
#include "BinaryData.h"

using namespace juce;
static String U (const char* s) { return String::fromUTF8 (s); }
static StringArray SA (std::initializer_list<const char*> l) { StringArray a; for (auto* s : l) a.add (U (s)); return a; }

// ======================= aspecto =======================
LirioLook::LirioLook()
{
    tDisplay = Typeface::createSystemTypefaceFor (BinaryData::ShrikhandRegular_ttf, (size_t) BinaryData::ShrikhandRegular_ttfSize);
    tLabel   = Typeface::createSystemTypefaceFor (BinaryData::RighteousRegular_ttf, (size_t) BinaryData::RighteousRegular_ttfSize);
    setDefaultSansSerifTypeface (tLabel);
    setColour (PopupMenu::backgroundColourId, pal::cream);
    setColour (PopupMenu::textColourId, pal::ink);
    setColour (PopupMenu::highlightedBackgroundColourId, pal::pink);
    setColour (PopupMenu::highlightedTextColourId, Colours::white);
    setColour (ComboBox::textColourId, pal::ink);
    setColour (Label::textColourId, pal::ink);
    setColour (TooltipWindow::backgroundColourId, pal::ink);
}
Font LirioLook::display (float h) const { return Font (tDisplay).withHeight (h); }
Font LirioLook::label (float h) const   { return Font (tLabel).withHeight (h); }

void LirioLook::drawRotarySlider (Graphics& g, int x, int y, int w, int h, float pos, float a0, float a1, Slider& s)
{
    const auto c = s.findColour (Slider::rotarySliderFillColourId);
    const float r = jmin (w, h) * 0.5f - 3.f;
    const Point<float> ctr ((float) x + w * 0.5f, (float) y + h * 0.5f);
    const float ang = a0 + pos * (a1 - a0);

    // pétalos (flor) alrededor del knob
    for (int i = 0; i < 8; ++i)
    {
        const float pa = (float) i / 8.f * MathConstants<float>::twoPi + 0.2f;
        Path petal; petal.addEllipse (-r * 0.21f, -r * 0.98f, r * 0.42f, r * 0.62f);
        petal.applyTransform (AffineTransform::rotation (pa).translated (ctr));
        g.setColour (c.interpolatedWith (pal::cream, 0.55f)); g.fillPath (petal);
        g.setColour (pal::ink.withAlpha (0.85f)); g.strokePath (petal, PathStrokeType (1.6f));
    }
    // arco de valor
    Path track; track.addCentredArc (ctr.x, ctr.y, r * 0.78f, r * 0.78f, 0, a0, a1, true);
    g.setColour (pal::ink); g.strokePath (track, PathStrokeType (r * 0.24f, PathStrokeType::curved, PathStrokeType::rounded));
    Path val; val.addCentredArc (ctr.x, ctr.y, r * 0.78f, r * 0.78f, 0, a0, ang, true);
    g.setColour (c); g.strokePath (val, PathStrokeType (r * 0.15f, PathStrokeType::curved, PathStrokeType::rounded));
    // cuerpo
    const float br = r * 0.56f;
    g.setColour (pal::ink); g.fillEllipse (ctr.x - br + 2.f, ctr.y - br + 3.f, br * 2, br * 2);
    g.setColour (c); g.fillEllipse (ctr.x - br, ctr.y - br, br * 2, br * 2);
    g.setColour (pal::cream); g.fillEllipse (ctr.x - br * 0.55f, ctr.y - br * 0.55f, br * 1.1f, br * 1.1f);
    g.setColour (pal::ink); g.drawEllipse (ctr.x - br, ctr.y - br, br * 2, br * 2, 2.2f);
    // indicador
    const Point<float> tip = ctr.getPointOnCircumference (br * 0.78f, ang);
    g.setColour (pal::ink); g.fillEllipse (tip.x - r * 0.1f, tip.y - r * 0.1f, r * 0.2f, r * 0.2f);
    g.drawLine (Line<float> (ctr, ctr.getPointOnCircumference (br * 0.5f, ang)), 2.4f);
}

void LirioLook::drawButtonBackground (Graphics& g, Button& b, const Colour&, bool over, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced (2.f, 3.f).withTrimmedRight (2.f).withTrimmedBottom (2.f);
    const bool on = b.getToggleState();
    const auto fill = on ? b.findColour (TextButton::buttonOnColourId) : pal::cream;
    if (! down) { g.setColour (pal::ink); g.fillRoundedRectangle (r.translated (2.f, 3.f), r.getHeight() * 0.5f); }
    else r = r.translated (1.f, 2.f);
    g.setColour (over && ! on ? fill.darker (0.06f) : fill); g.fillRoundedRectangle (r, r.getHeight() * 0.5f);
    g.setColour (pal::ink); g.drawRoundedRectangle (r, r.getHeight() * 0.5f, 2.f);
}
void LirioLook::drawButtonText (Graphics& g, TextButton& b, bool, bool down)
{
    g.setFont (label (jmin (16.f, b.getHeight() * 0.42f)));
    const bool on = b.getToggleState();
    const auto fill = b.findColour (TextButton::buttonOnColourId);
    g.setColour (on ? (fill.getPerceivedBrightness() > 0.62f ? pal::ink : Colours::white) : pal::ink);
    auto r = b.getLocalBounds().reduced (4, 2).translated (0, down ? 1 : -1);
    g.drawFittedText (b.getButtonText(), r, Justification::centred, 1, 0.8f);
}
void LirioLook::drawToggleButton (Graphics& g, ToggleButton& b, bool over, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced (2.f, 3.f).withTrimmedRight (2.f).withTrimmedBottom (2.f);
    const bool on = b.getToggleState();
    const auto c = b.findColour (ToggleButton::tickColourId);
    if (! down) { g.setColour (pal::ink); g.fillRoundedRectangle (r.translated (2.f, 3.f), r.getHeight() * 0.5f); } else r = r.translated (1.f, 2.f);
    g.setColour (on ? c.interpolatedWith (pal::cream, 0.25f) : (over ? pal::cream.darker (0.05f) : pal::cream)); g.fillRoundedRectangle (r, r.getHeight() * 0.5f);
    g.setColour (pal::ink); g.drawRoundedRectangle (r, r.getHeight() * 0.5f, 2.f);
    const float d = r.getHeight() * 0.48f; auto lamp = Rectangle<float> (r.getX() + r.getHeight() * 0.28f, r.getCentreY() - d * 0.5f, d, d);
    g.setColour (on ? c : pal::cream.darker (0.25f)); g.fillEllipse (lamp);
    if (on) { g.setColour (Colours::white.withAlpha (0.8f)); g.fillEllipse (lamp.reduced (d * 0.3f).translated (-d * 0.12f, -d * 0.12f)); }
    g.setColour (pal::ink); g.drawEllipse (lamp, 1.8f);
    g.setFont (label (jmin (15.f, r.getHeight() * 0.45f))); g.setColour (pal::ink);
    g.drawFittedText (b.getButtonText(), r.withTrimmedLeft (lamp.getRight() - r.getX() + 4.f).toNearestInt(), Justification::centredLeft, 1, 0.7f);
}
void LirioLook::drawComboBox (Graphics& g, int w, int h, bool, int, int, int, int, ComboBox&)
{
    auto r = Rectangle<float> (0, 0, (float) w, (float) h).reduced (2.f, 2.f).withTrimmedRight (2.f).withTrimmedBottom (2.f);
    g.setColour (pal::ink); g.fillRoundedRectangle (r.translated (2.f, 2.f), r.getHeight() * 0.5f);
    g.setColour (pal::cream); g.fillRoundedRectangle (r, r.getHeight() * 0.5f);
    g.setColour (pal::ink); g.drawRoundedRectangle (r, r.getHeight() * 0.5f, 2.f);
    Path tri; const float cx = r.getRight() - r.getHeight() * 0.6f, cy = r.getCentreY();
    tri.addTriangle (cx - 5.f, cy - 3.f, cx + 5.f, cy - 3.f, cx, cy + 4.f); g.setColour (pal::pink); g.fillPath (tri);
}
Label* LirioLook::createSliderTextBox (Slider& s)
{
    auto* l = LookAndFeel_V4::createSliderTextBox (s);
    l->setColour (Label::textColourId, pal::ink); l->setColour (Label::backgroundColourId, Colours::transparentBlack);
    l->setColour (Label::outlineColourId, Colours::transparentBlack); l->setFont (label (13.f)); l->setJustificationType (Justification::centred);
    return l;
}
void LirioLook::drawLabel (Graphics& g, Label& l)
{
    if (! l.isBeingEdited())
    {
        g.setColour (l.findColour (Label::textColourId)); g.setFont (label (13.f));
        g.drawFittedText (l.getText(), l.getLocalBounds(), l.getJustificationType(), 1, 0.8f);
    }
}

// ======================= knob =======================
Knob::Knob (AudioProcessorValueTreeState& s, const String& id, const String& text, Colour c) : name (text), colour (c)
{
    slider.setColour (Slider::textBoxTextColourId, pal::ink); slider.setColour (Slider::textBoxOutlineColourId, Colours::transparentBlack); slider.setColour (Slider::textBoxBackgroundColourId, Colours::transparentBlack);
    slider.setSliderStyle (Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle (Slider::TextBoxBelow, false, 70, 16);
    slider.setColour (Slider::rotarySliderFillColourId, c);
    slider.setRotaryParameters (MathConstants<float>::pi * 1.2f, MathConstants<float>::pi * 2.8f, true);
    slider.setPopupDisplayEnabled (false, false, nullptr);
    addAndMakeVisible (slider);
    att = std::make_unique<AudioProcessorValueTreeState::SliderAttachment> (s, id, slider);
    slider.setDoubleClickReturnValue (true, s.getParameter (id)->convertFrom0to1 (s.getParameter (id)->getDefaultValue()));
}
void Knob::resized() { slider.setBounds (getLocalBounds().withTrimmedTop (18)); }
void Knob::paint (Graphics& g)
{
    auto* lf = dynamic_cast<LirioLook*> (&getLookAndFeel());
    g.setFont (lf ? lf->label (13.5f) : Font (13.5f)); g.setColour (pal::ink);
    g.drawFittedText (name, getLocalBounds().removeFromTop (18), Justification::centred, 1, 0.75f);
}

// ======================= píldoras =======================
Pills::Pills (AudioProcessorValueTreeState& s, const String& id, const StringArray& items, int columns, bool rainbow, std::function<void()> onPick)
    : param (s.getParameter (id)), cols (columns), picked (std::move (onPick))
{
    for (int i = 0; i < items.size(); ++i)
    {
        auto* b = buttons.add (new TextButton (items[i]));
        b->setClickingTogglesState (false);
        b->setColour (TextButton::buttonOnColourId, rainbow ? pal::rainbow (i) : pal::pink);
        b->onClick = [this, i] {
            const int n = buttons.size();
            param->beginChangeGesture(); param->setValueNotifyingHost (n > 1 ? (float) i / (float) (n - 1) : 0.f); param->endChangeGesture();
            if (picked) picked(); sync(); };
        addAndMakeVisible (b);
    }
    sync();
}
void Pills::resized()
{
    const int n = buttons.size(), rows = (n + cols - 1) / cols;
    const float bw = getWidth() / (float) cols, bh = getHeight() / (float) rows;
    for (int i = 0; i < n; ++i) buttons[i]->setBounds (Rectangle<float> ((i % cols) * bw, (i / cols) * bh, bw, bh).reduced (3.f, 2.f).toNearestInt());
}
void Pills::sync()
{
    const int n = buttons.size();
    const int idx = n > 1 ? roundToInt (param->getValue() * (n - 1)) : 0;
    for (int i = 0; i < n; ++i) if (buttons[i]->getToggleState() != (i == idx)) buttons[i]->setToggleState (i == idx, dontSendNotification);
}

// ======================= teclado =======================
static bool isBlack (int m) { const int k = m % 12; return k == 1 || k == 3 || k == 6 || k == 8 || k == 10; }
void Keys::paint (Graphics& g)
{
    const auto lo64 = proc.engine.uiNotesLo.load(), hi64 = proc.engine.uiNotesHi.load();
    auto sounding = [&] (int m) { return m < 64 ? ((lo64 >> m) & 1ull) : ((hi64 >> (m - 64)) & 1ull); };
    auto r = getLocalBounds().toFloat();
    g.setColour (pal::ink); g.fillRoundedRectangle (r, 14.f);
    r = r.reduced (8.f, 7.f);
    int whites = 0; for (int m = lo; m <= hi; ++m) if (! isBlack (m)) ++whites;
    const float kw = r.getWidth() / (float) whites;
    int wi = 0;
    for (int m = lo; m <= hi; ++m) if (! isBlack (m))
    {
        auto k = Rectangle<float> (r.getX() + wi * kw, r.getY(), kw - 2.f, r.getHeight());
        const bool on = sounding (m) || proc.keyboardState.isNoteOnForChannels (0xffff, m);
        g.setColour (on ? pal::rainbow (m % 12) : pal::cream); g.fillRoundedRectangle (k, 5.f);
        if (m % 12 == 0) { g.setColour (pal::ink.withAlpha (0.5f)); g.setFont (Font (10.f)); g.drawText ("C" + String (m / 12 - 1), k.removeFromBottom (14.f), Justification::centred); }
        ++wi;
    }
    wi = 0;
    for (int m = lo; m <= hi; ++m)
    {
        if (! isBlack (m)) { ++wi; continue; }
        auto k = Rectangle<float> (r.getX() + wi * kw - kw * 0.32f, r.getY(), kw * 0.62f, r.getHeight() * 0.6f);
        const bool on = sounding (m) || proc.keyboardState.isNoteOnForChannels (0xffff, m);
        g.setColour (on ? pal::rainbow (m % 12) : pal::ink.brighter (0.15f)); g.fillRoundedRectangle (k, 4.f);
        g.setColour (pal::ink); g.drawRoundedRectangle (k, 4.f, 1.5f);
    }
}
int Keys::noteAt (Point<float> p) const
{
    auto r = getLocalBounds().toFloat().reduced (8.f, 7.f);
    int whites = 0; for (int m = lo; m <= hi; ++m) if (! isBlack (m)) ++whites;
    const float kw = r.getWidth() / (float) whites;
    if (p.y < r.getY() + r.getHeight() * 0.6f)
    {
        int wi = 0; for (int m = lo; m <= hi; ++m) { if (! isBlack (m)) { ++wi; continue; }
            const float x0 = r.getX() + wi * kw - kw * 0.32f; if (p.x >= x0 && p.x <= x0 + kw * 0.62f) return m; }
    }
    const int idx = jlimit (0, whites - 1, (int) ((p.x - r.getX()) / kw));
    int wi = 0; for (int m = lo; m <= hi; ++m) if (! isBlack (m)) { if (wi == idx) return m; ++wi; }
    return -1;
}
void Keys::mouseDown (const MouseEvent& e) { down = noteAt (e.position); if (down >= 0) proc.keyboardState.noteOn (1, down, 0.8f); }
void Keys::mouseDrag (const MouseEvent& e) { const int n = noteAt (e.position); if (n != down && n >= 0) { if (down >= 0) proc.keyboardState.noteOff (1, down, 0.f); down = n; proc.keyboardState.noteOn (1, n, 0.8f); } }
void Keys::mouseUp (const MouseEvent&) { if (down >= 0) proc.keyboardState.noteOff (1, down, 0.f); down = -1; }

// ======================= grilla de ritmo =======================
void DrumGrid::paint (Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    const int L = LirioProcessor::kLanes; const float lh = r.getHeight() / (float) L;
    const float cw = (r.getWidth() - labelW) / 16.f;
    const int cur = proc.engine.drums.uiStep.load();
    auto* lf = dynamic_cast<LirioLook*> (&getLookAndFeel());
    for (int l = 0; l < L; ++l)
    {
        const float y = r.getY() + l * lh;
        g.setColour (pal::ink); g.setFont (lf ? lf->label (12.5f) : Font (12.5f));
        g.drawText (LirioProcessor::laneNames[l], Rectangle<float> (0.f, y, (float) labelW - 6.f, lh), Justification::centredRight);
        const uint16_t mask = proc.lanes[l].load();
        for (int s = 0; s < 16; ++s)
        {
            auto c = Rectangle<float> (labelW + s * cw, y, cw, lh).reduced (1.5f, 1.5f);
            const bool on = (mask >> s) & 1u;
            const auto col = pal::rainbow (l == 0 ? 0 : l == 1 ? 4 : l == 2 ? 6 : l + 0);
            g.setColour (on ? col : (s / 4) % 2 ? pal::cream.darker (0.12f) : pal::cream.darker (0.04f));
            g.fillRoundedRectangle (c, 4.f);
            g.setColour (s == cur ? pal::ink : pal::ink.withAlpha (on ? 0.9f : 0.35f));
            g.drawRoundedRectangle (c, 4.f, s == cur ? 2.6f : 1.2f);
        }
    }
}
bool DrumGrid::cellAt (Point<float> p, int& lane, int& step) const
{
    const int L = LirioProcessor::kLanes; const float lh = getHeight() / (float) L, cw = (getWidth() - labelW) / 16.f;
    if (p.x < labelW) return false;
    lane = jlimit (0, L - 1, (int) (p.y / lh)); step = jlimit (0, 15, (int) ((p.x - labelW) / cw)); return true;
}
void DrumGrid::mouseDown (const MouseEvent& ev)
{
    int l, s; if (! cellAt (ev.position, l, s)) return;
    paintValue = ! ((proc.lanes[l].load() >> s) & 1u);
    proc.toggleStep (l, s); lastLane = l; lastStep = s; repaint();
}
void DrumGrid::mouseDrag (const MouseEvent& ev)
{
    int l, s; if (! cellAt (ev.position, l, s) || (l == lastLane && s == lastStep)) return;
    lastLane = l; lastStep = s;
    const bool on = (proc.lanes[l].load() >> s) & 1u;
    if (on != paintValue) proc.toggleStep (l, s);
    repaint();
}

// ======================= tempo =======================
TempoBox::TempoBox (LirioProcessor& p) : proc (p), param (p.apvts.getParameter ("tempo"))
{
    for (auto* b : { &minus, &tap, &plus }) { addAndMakeVisible (b); b->setColour (TextButton::buttonOnColourId, pal::purple); }
    minus.setRepeatSpeed (450, 70); plus.setRepeatSpeed (450, 70);
    minus.onClick = [this] { setBpm ((float) std::round (bpm()) - 1.f); };
    plus.onClick  = [this] { setBpm ((float) std::round (bpm()) + 1.f); };
    tap.onClick   = [this] { tapped(); };
    minus.setTooltip (U ("Bajar 1 BPM (mantené apretado para bajar rápido)"));
    plus.setTooltip (U ("Subir 1 BPM (mantené apretado para subir rápido)"));
    tap.setTooltip (U ("Tocalo varias veces al ritmo que quieras y Lirio toma ese tempo"));
    typer.setJustification (Justification::centred);
    typer.setInputRestrictions (5, "0123456789.,");
    typer.setColour (TextEditor::backgroundColourId, pal::ink);
    typer.setColour (TextEditor::textColourId, pal::lemon);
    typer.setColour (TextEditor::outlineColourId, pal::pink);
    typer.setColour (TextEditor::focusedOutlineColourId, pal::pink);
    typer.setColour (TextEditor::highlightColourId, pal::pink.withAlpha (0.5f));
    typer.setColour (CaretComponent::caretColourId, pal::lemon);
    auto close = [this] (bool apply)
    {
        if (! typer.isVisible()) return;
        if (apply) { const float v = typer.getText().replaceCharacter (',', '.').getFloatValue(); if (v > 0.f) setBpm (v); }
        typer.setVisible (false); repaint();
    };
    typer.onReturnKey = [close] { close (true); };
    typer.onEscapeKey = [close] { close (false); };
    typer.onFocusLost = [close] { close (true); };
    addChildComponent (typer);
    setTooltip (U ("Tempo de Lirio: arrastrá el número arriba/abajo, usá la rueda del mouse o hacé doble clic para escribirlo. Mueve el ritmo, el arpegio y el delay."));
}
bool TempoBox::editable() const { return proc.wrapperType == AudioProcessor::wrapperType_Standalone || ! proc.hasHostTempo(); }
float TempoBox::bpm() const { return editable() ? param->convertFrom0to1 (param->getValue()) : proc.hostBpm(); }
void TempoBox::setBpm (float v)
{
    if (! editable()) return;
    v = jlimit (40.f, 220.f, std::round (v * 10.f) / 10.f);
    param->beginChangeGesture(); param->setValueNotifyingHost (param->convertTo0to1 (v)); param->endChangeGesture();
    refresh(); repaint();
}
void TempoBox::tapped()
{
    const double now = Time::getMillisecondCounterHiRes();
    if (tapN > 0 && now - taps[tapN - 1] > 2000.0) tapN = 0; // pausa larga: empieza de nuevo
    if (tapN == 6) { for (int i = 1; i < 6; ++i) taps[i - 1] = taps[i]; tapN = 5; }
    taps[tapN++] = now;
    if (tapN >= 2) setBpm ((float) std::round (60000.0 * (tapN - 1) / (taps[tapN - 1] - taps[0])));
}
void TempoBox::resized()
{
    const int w = getWidth(), y = 64, h = getHeight() - y;
    minus.setBounds (0, y, 40, h); tap.setBounds (40, y, w - 80, h); plus.setBounds (w - 40, y, 40, h);
    typer.setBounds (numberArea().reduced (8, 3));
    if (auto* lf = dynamic_cast<LirioLook*> (&getLookAndFeel())) typer.setFont (lf->display (24.f));
}
void TempoBox::paint (Graphics& g)
{
    auto* lf = dynamic_cast<LirioLook*> (&getLookAndFeel());
    auto font = [lf] (bool disp, float h) { return lf ? (disp ? lf->display (h) : lf->label (h)) : Font (h); };
    const bool ed = editable();
    g.setFont (font (false, 13.5f)); g.setColour (pal::ink);
    g.drawText ("TEMPO", Rectangle<int> (0, 0, getWidth(), 18), Justification::centred);
    auto r = numberArea().toFloat().reduced (2.f, 2.f);
    g.setColour (pal::ink); g.fillRoundedRectangle (r.translated (2.f, 3.f), 12.f);
    g.setColour (pal::ink.brighter (0.1f)); g.fillRoundedRectangle (r, 12.f);
    g.setColour (ed ? pal::purple : pal::cream.withAlpha (0.4f)); g.drawRoundedRectangle (r.reduced (3.f), 9.f, 2.f);
    if (typer.isVisible()) return;
    const float v = bpm();
    const String num = v <= 0.f ? String ("—") : (std::abs (v - std::round (v)) < 0.05f ? String (roundToInt (v)) : String (v, 1));
    auto txt = r.reduced (8.f, 0.f);
    auto unit = txt.removeFromRight (40.f);
    g.setFont (font (true, 28.f));
    g.setColour (ed ? pal::lemon : pal::cream.withAlpha (0.75f)); g.drawText (num, txt.translated (0.f, 2.f), Justification::centredRight);
    g.setFont (font (false, ed ? 12.f : 10.5f)); g.setColour (pal::cream.withAlpha (0.8f));
    g.drawFittedText (ed ? String ("BPM") : String ("DEL\nDAW"), unit.toNearestInt().withTrimmedLeft (6), Justification::centredLeft, 2, 0.8f);
}
void TempoBox::mouseDown (const MouseEvent& e)
{
    dragging = editable() && numberArea().contains (e.getPosition());
    if (dragging) { dragStart = bpm(); param->beginChangeGesture(); }
}
void TempoBox::mouseDrag (const MouseEvent& e)
{
    if (! dragging) return;
    const float per = e.mods.isShiftDown() ? 0.1f : 0.5f; // con Shift: ajuste fino
    float v = dragStart - (float) e.getDistanceFromDragStartY() * per;
    v = e.mods.isShiftDown() ? std::round (v * 10.f) / 10.f : std::round (v);
    param->setValueNotifyingHost (param->convertTo0to1 (jlimit (40.f, 220.f, v)));
    repaint();
}
void TempoBox::mouseUp (const MouseEvent&) { if (dragging) param->endChangeGesture(); dragging = false; }
void TempoBox::mouseDoubleClick (const MouseEvent& e)
{
    if (! editable() || ! numberArea().contains (e.getPosition())) return;
    typer.setText (String (roundToInt (bpm())), false);
    typer.setVisible (true); typer.grabKeyboardFocus(); typer.selectAll(); repaint();
}
void TempoBox::mouseWheelMove (const MouseEvent& e, const MouseWheelDetails& w)
{
    if (! editable()) return;
    const float step = e.mods.isShiftDown() ? 0.1f : 1.f;
    const float dir = (w.deltaY != 0 ? w.deltaY : w.deltaX) * (w.isReversed ? -1.f : 1.f);
    if (dir != 0) setBpm (bpm() + (dir > 0 ? step : -step));
}
void TempoBox::refresh()
{
    const bool ed = editable();
    const String s = String (bpm(), 1);
    if (ed != lastEditable)
    {
        lastEditable = ed;
        for (auto* b : { &minus, &tap, &plus }) { b->setEnabled (ed); b->setAlpha (ed ? 1.f : 0.45f); }
        setTooltip (ed ? U ("Tempo de Lirio: arrastrá el número arriba/abajo, usá la rueda del mouse o hacé doble clic para escribirlo. Mueve el ritmo, el arpegio y el delay.")
                       : U ("Dentro del DAW, Lirio sigue el tempo del proyecto. Para cambiarlo, cambiá el tempo en Sonar."));
        repaint();
    }
    if (s != shown) { shown = s; repaint(); }
}

// ======================= contenido =======================
Content::Content (LirioProcessor& p) : proc (p), keys (p), grid (p), tempoBox (p)
{
    setLookAndFeel (&look);
    auto& s = proc.apvts;
    mode   = std::make_unique<Pills> (s, "mode", SA ({ "ACORDES", "NOTAS" }), 2, false);
    chord  = std::make_unique<Pills> (s, "chord", SA ({ "AUTO", "MAYOR", "MENOR", "SUS2", "SUS4", "7", "MAJ7", "m7", "DIM" }), 3, true, [this] { proc.clearKeySwitch = true; });
    perf   = std::make_unique<Pills> (s, "perf", SA ({ "ACORDE", "STRUM", "SLOP", "ARPEGIO", "ARPA" }), 5, true);
    engine = std::make_unique<Pills> (s, "engine", SA ({ "ANALÓGICO", "FM", "LENGÜETA" }), 3, true);
    for (auto* c : { mode.get(), chord.get(), perf.get(), engine.get() }) addAndMakeVisible (c);

    auto tog = [&] (ToggleButton& b, const char* id, Colour c) { b.setColour (ToggleButton::tickColourId, c); addAndMakeVisible (b); btnAtt.push_back (std::make_unique<AudioProcessorValueTreeState::ButtonAttachment> (s, id, b)); };
    tog (add9, "add9", pal::lemon); tog (hold, "hold", pal::pink); tog (keyswitch, "keyswitch", pal::turq); tog (bassOn, "bassOn", pal::lime); tog (followOct, "followOct", pal::lime);
    followOct.setTooltip (U ("Encendido: el acorde suena en la octava de la tecla que tocás (los botones de octava del teclado lo suben o bajan). Apagado: siempre en la misma zona."));
    keyswitch.setTooltip ("Las teclas MIDI 24 a 32 (Do1 a Sol#1) eligen el tipo de acorde: Auto, Mayor, Menor, Sus2, Sus4, 7, Maj7, m7, Dim");
    hold.setTooltip ("El acorde queda sonando al soltar la tecla. Tocá la misma tecla para apagarlo.");

    auto box = [&] (ComboBox& b, const char* id, const StringArray& items)
    {
        b.addItemList (items, 1); addAndMakeVisible (b);
        boxAtt.push_back (std::make_unique<AudioProcessorValueTreeState::ComboBoxAttachment> (s, id, b));
    };
    box (keyBox, "key", LirioProcessor::keyNames); box (scaleBox, "scale", SA ({ "Mayor", "Menor" }));
    box (rateBox, "arpRate", LirioProcessor::rateNames); box (patternBox, "arpPattern", LirioProcessor::patternNames);
    box (delayBox, "delayTime", LirioProcessor::delayNames); box (bassOctBox, "bassOct", SA ({ "-1", "-2" })); bassOctBox.setTooltip ("Octava del bajo respecto del acorde");
    for (int i = 0; i < proc.getNumPrograms(); ++i) presetBox.addItem (proc.getProgramName (i), i + 1);
    presetBox.setSelectedId (proc.getCurrentProgram() + 1, dontSendNotification);
    presetBox.onChange = [this] { const int i = presetBox.getSelectedId() - 1; if (i >= 0) proc.setCurrentProgram (i); };
    addAndMakeVisible (presetBox);

    auto knob = [&] (const char* id, const char* name, Colour c) { auto* k = knobs.add (new Knob (s, id, U (name), c)); k->setName (id); addAndMakeVisible (k); return k; };
    knob ("voicing", "VOICING", pal::pink); knob ("octave", "REGISTRO", pal::orange); knob ("velsens", "DINÁMICA", pal::turq);
    knob ("strum", "VELOCIDAD", pal::pink); knob ("slop", "HUMANO", pal::orange); knob ("arpOct", "OCTAVAS", pal::lime); knob ("arpGate", "DURACIÓN", pal::turq);
    addAndMakeVisible (tempoBox);
    knob ("bright", "BRILLO", pal::lemon); kTone2 = knob ("tone2", "RESONANCIA", pal::pink); kChar = knob ("character", "ENVOLVENTE", pal::orange); kMove = knob ("movement", "MOVIMIENTO", pal::turq);
    knob ("attack", "ATAQUE", pal::lime); knob ("decay", "CAÍDA", pal::sky); knob ("sustain", "SOSTÉN", pal::purple); knob ("release", "SUELTA", pal::pink);
    knob ("bassLevel", "NIVEL", pal::lime); knob ("bassTone", "TONO", pal::orange);
    knob ("chorus", "CHORUS", pal::turq); knob ("delayMix", "DELAY", pal::pink); knob ("delayFb", "REPETIR", pal::orange); knob ("reverbMix", "REVERB", pal::purple);
    knob ("reverbSize", "TAMAÑO", pal::sky); knob ("volume", "VOLUMEN", pal::lemon);
    addAndMakeVisible (keys);
    // ---- ritmo ----
    knob ("drumVol", "VOLUMEN", pal::pink); knob ("swing", "SWING", pal::orange); knob ("drumComp", "COMPRESIÓN", pal::lime);
    knob ("drumPhase", "FASE", pal::turq); knob ("drumTone", "TONO", pal::lemon);
    drumPlay.setClickingTogglesState (true); drumPlay.setColour (TextButton::buttonOnColourId, pal::lime);
    btnAtt.push_back (std::make_unique<AudioProcessorValueTreeState::ButtonAttachment> (s, "drumsOn", drumPlay)); addAndMakeVisible (drumPlay);
    tog (drumSync, "drumSync", pal::turq);
    drumSync.setTooltip (U ("Encendido: dentro de Sonar el ritmo arranca y para con el play del proyecto y sigue su tempo."));
    box (drumPatternBox, "drumPattern", LirioProcessor::drumPatternNames);
    addAndMakeVisible (grid); grid.setTooltip (U ("Clic en los cuadros para poner o quitar golpes (podés arrastrar). Con SEGUIR AL DAW, en Sonar arranca con el play."));
    // ---- grabar demo ----
    recBtn.setColour (TextButton::buttonOnColourId, pal::pink);
    recBtn.onClick = [this] { if (proc.isRecording()) proc.stopRecording(); else if (! proc.startRecording()) recText = U ("No se pudo crear el archivo"); };
    folderBtn.onClick = [this] { auto f = proc.recordFolder(); f.createDirectory(); if (proc.lastRecording.existsAsFile()) proc.lastRecording.revealToUser(); else f.startAsProcess(); };
    addAndMakeVisible (recBtn); addAndMakeVisible (folderBtn);
    // teclado de la compu: QWE/ASD/ZXC eligen el acorde, R prende/apaga el +9
    setWantsKeyboardFocus (true);
    add9.setTooltip (U ("Suma la novena al acorde · tecla R"));
    // los botones, listas y knobs no se quedan con el foco: así las letras llegan siempre a Lirio
    // y la barra espaciadora sigue yendo al DAW en vez de apretar el último botón tocado
    std::function<void (Component&)> noFocus = [&] (Component& c)
    {
        for (auto* ch : c.getChildren())
        {
            if (dynamic_cast<Button*> (ch) || dynamic_cast<ComboBox*> (ch) || dynamic_cast<Slider*> (ch)) ch->setWantsKeyboardFocus (false);
            if (dynamic_cast<ComboBox*> (ch) == nullptr && dynamic_cast<Slider*> (ch) == nullptr) noFocus (*ch);
        }
    };
    noFocus (*this);
    setMouseClickGrabsKeyboardFocus (true);
    startTimerHz (20);
}
Content::~Content() { stopTimer(); setLookAndFeel (nullptr); }

void Content::timerCallback()
{
    // programa independiente: toma el teclado al abrir (en el DAW, al hacer clic en Lirio)
    if (proc.wrapperType == AudioProcessor::wrapperType_Standalone && focusTries < 40 && isShowing())
    { if (hasKeyboardFocus (true)) focusTries = 40; else { ++focusTries; grabKeyboardFocus(); } }
    phase += 0.03f; // solo gira la flor; el fondo es fijo para no gastar CPU
    for (auto* pl : { mode.get(), chord.get(), perf.get(), engine.get() }) pl->sync();
    // si se eligió el tipo con las teclas de cambio, la matriz lo muestra
    const int ks = proc.engine.uiKs.load();
    if (ks >= 0) for (int i = 0; i < chord->buttons.size(); ++i) chord->buttons[i]->setToggleState (i == ks, dontSendNotification);
    // rótulos según el motor
    const int e = (int) std::lround (proc.apvts.getRawParameterValue ("engine")->load());
    if (e != lastEngine)
    {
        lastEngine = e;
        if (e == 0) { kTone2->setText (U ("RESONANCIA")); kChar->setText (U ("ENVOLVENTE")); kMove->setText (U ("MOVIMIENTO")); }
        else if (e == 1) { kTone2->setText (U ("RELACIÓN")); kChar->setText (U ("ÍNDICE")); kMove->setText (U ("TRÉMOLO")); }
        else { kTone2->setText (U ("MECÁNICA")); kChar->setText (U ("MORDIDA")); kMove->setText (U ("TRÉMOLO")); }
    }
    // pantalla
    static const char* L[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    static const char* S[] = { "Do", "Do#", "Re", "Re#", "Mi", "Fa", "Fa#", "Sol", "Sol#", "La", "La#", "Si" };
    const int root = proc.engine.uiRoot.load(), type = proc.engine.uiType.load();
    const int pf = (int) std::lround (proc.apvts.getRawParameterValue ("perf")->load());
    const bool add9 = proc.apvts.getRawParameterValue ("add9")->load() > .5f;
    if (root < 0) chordText = U ("¡Tocá!");
    else if (type < 0) chordText = String (L[root % 12]) + String (root / 12 - 1);
    else chordText = String (L[root % 12]) + lirio::chordSuffix (type, proc.engine.uiMinor.load() != 0, proc.engine.uiDim.load() != 0) + (add9 ? "add9" : "");
    String tempo = proc.wrapperType == AudioProcessor::wrapperType_Standalone || ! proc.hasHostTempo()
                     ? String (roundToInt (proc.apvts.getRawParameterValue ("tempo")->load())) + " BPM"
                     : String (roundToInt (proc.hostBpm())) + " BPM del DAW";
    subText = (root >= 0 && type >= 0 ? String (S[root % 12]) + "  ·  " : String()) + LirioProcessor::perfNames[pf].toUpperCase() + "  ·  " + tempo;
    const int act = proc.engine.uiActivity.load(); if (act != lastActivity) { lastActivity = act; led = 1.f; } else led *= 0.8f;
    const int pi = proc.getCurrentProgram(); if (presetBox.getSelectedId() != pi + 1) presetBox.setSelectedId (pi + 1, dontSendNotification);
    // redibujar solo lo que cambia (pantalla, flor y teclado): mucho menos trabajo para el procesador
    const String sig = chordText + subText + String (roundToInt (led * 20.f));
    if (sig != lastSig) { lastSig = sig; repaint (476, 10, 312, 102); }
    repaint (8, 6, 106, 106);
    keys.repaint(); grid.repaint(); tempoBox.refresh();
    // ritmo y grabación
    const bool playing = proc.apvts.getRawParameterValue ("drumsOn")->load() > .5f;
    drumPlay.setButtonText (playing ? U ("PARAR RITMO") : U ("TOCAR RITMO"));
    const bool rec = proc.isRecording();
    recBtn.setToggleState (rec, dontSendNotification);
    recBtn.setButtonText (rec ? U ("PARAR Y GUARDAR") : U ("GRABAR DEMO"));
    String rt;
    if (rec) { const int s = (int) proc.recordedSeconds(); rt = U ("GRABANDO  ") + String (s / 60) + ":" + String (s % 60).paddedLeft ('0', 2); }
    else if (proc.lastRecording.existsAsFile()) rt = U ("Guardado: ") + proc.lastRecording.getFileName();
    else rt = U ("WAV 24 bits en Documentos\\Lirio");
    if (rt != recText) { recText = rt; repaint (882, 734, 176, 40); }
}

void Content::flower (Graphics& g, Point<float> c, float r, float rot)
{
    for (int ring = 0; ring < 2; ++ring)
        for (int i = 0; i < 6; ++i)
        {
            const float a = rot + (float) i / 6.f * MathConstants<float>::twoPi + ring * 0.52f;
            const float rr = ring == 0 ? r : r * 0.66f;
            Path pt; pt.addEllipse (-rr * 0.26f, -rr, rr * 0.52f, rr * 0.95f);
            pt.applyTransform (AffineTransform::rotation (a).translated (c));
            g.setColour (ring == 0 ? pal::pink : pal::orange); g.fillPath (pt);
            g.setColour (pal::ink); g.strokePath (pt, PathStrokeType (2.f));
        }
    g.setColour (pal::lemon); g.fillEllipse (c.x - r * 0.3f, c.y - r * 0.3f, r * 0.6f, r * 0.6f);
    g.setColour (pal::ink); g.drawEllipse (c.x - r * 0.3f, c.y - r * 0.3f, r * 0.6f, r * 0.6f, 2.f);
    for (int i = 0; i < 5; ++i) { auto d = c.getPointOnCircumference (r * 0.14f, (float) i * 1.256f + rot); g.fillEllipse (d.x - 2.f, d.y - 2.f, 4.f, 4.f); }
}

void Content::panel (Graphics& g, Rectangle<float> r, const String& title, Colour accent)
{
    g.setColour (pal::ink); g.fillRoundedRectangle (r.translated (5.f, 6.f), 24.f);
    g.setColour (pal::cream); g.fillRoundedRectangle (r, 24.f);
    // banda ondulada de color arriba
    Path wave; const float top = r.getY() + 8.f;
    wave.startNewSubPath (r.getX() + 24.f, top);
    for (float x = r.getX() + 24.f; x <= r.getRight() - 24.f; x += 6.f) wave.lineTo (x, top + 4.f * std::sin ((x - r.getX()) * 0.06f));
    g.setColour (accent.withAlpha (0.55f)); g.strokePath (wave, PathStrokeType (4.f, PathStrokeType::curved, PathStrokeType::rounded));
    g.setColour (pal::ink); g.drawRoundedRectangle (r, 24.f, 3.f);
    // título tipo calcomanía
    g.setFont (look.display (25.f));
    const float tw = look.display (25.f).getStringWidthFloat (title) + 30.f;
    auto tag = Rectangle<float> (r.getX() + 18.f, r.getY() - 17.f, tw, 34.f);
    g.setColour (pal::ink); g.fillRoundedRectangle (tag.translated (3.f, 3.f), 17.f);
    g.setColour (accent); g.fillRoundedRectangle (tag, 17.f);
    g.setColour (pal::ink); g.drawRoundedRectangle (tag, 17.f, 2.5f);
    g.setColour (accent.getPerceivedBrightness() > 0.6f ? pal::ink : Colours::white);
    g.drawText (title, tag.translated (0.f, -1.f), Justification::centred);
}

void Content::paint (Graphics& g)
{
    const float W = (float) getWidth(), H = (float) getHeight();
    // fondo: bandas ondulantes en arcoíris
    g.fillAll (pal::purple);
    const int N = 16;
    for (int k = N; k >= 0; --k)
    {
        Path band; const float base = -60.f + (float) k * (H + 120.f) / N;
        band.startNewSubPath (0.f, H + 10.f); band.lineTo (0.f, base);
        for (float x = 0; x <= W + 20.f; x += 16.f)
            band.lineTo (x, base + 26.f * std::sin (x * 0.008f + k * 0.55f) + 0.18f * x);
        band.lineTo (W + 20.f, H + 10.f); band.closeSubPath();
        g.setColour (pal::rainbow (k)); g.fillPath (band);
        g.setColour (pal::ink.withAlpha (0.35f)); g.strokePath (band, PathStrokeType (2.f));
    }
    // círculos concéntricos (op-art) detrás del título
    for (int i = 9; i >= 0; --i) { const float rr = 18.f + i * 14.f; g.setColour (i % 2 ? pal::cream : pal::ink); g.fillEllipse (60.f - rr, 58.f - rr, rr * 2, rr * 2); }
    flower (g, { 60.f, 58.f }, 40.f, phase * 0.6f);

    // título
    g.setFont (look.display (78.f));
    auto tr = Rectangle<float> (120.f, 0.f, 360.f, 110.f);
    g.setColour (pal::ink);  g.drawText ("Lirio", tr.translated (7.f, 7.f), Justification::centredLeft);
    g.setColour (pal::pink); g.drawText ("Lirio", tr.translated (3.5f, 3.5f), Justification::centredLeft);
    g.setColour (pal::lemon); g.drawText ("Lirio", tr, Justification::centredLeft);
    auto sub = Rectangle<float> (300.f, 70.f, 160.f, 28.f);
    g.setColour (pal::ink); g.fillRoundedRectangle (sub.translated (2.f, 2.f), 14.f); g.setColour (pal::cream); g.fillRoundedRectangle (sub, 14.f);
    g.setColour (pal::ink); g.drawRoundedRectangle (sub, 14.f, 2.f); g.setFont (look.label (14.f)); g.drawText (U ("MÁQUINA DE ACORDES"), sub, Justification::centred);

    // pantalla
    auto d = Rectangle<float> (480.f, 14.f, 300.f, 92.f);
    g.setColour (pal::ink); g.fillRoundedRectangle (d.translated (4.f, 5.f), 22.f);
    g.setColour (pal::ink.brighter (0.1f)); g.fillRoundedRectangle (d, 22.f);
    g.setColour (pal::pink); g.drawRoundedRectangle (d.reduced (5.f), 18.f, 2.5f);
    g.setFont (look.display (46.f));
    g.setColour (pal::pink); g.drawText (chordText, d.withTrimmedBottom (26.f).translated (2.f, 4.f), Justification::centred);
    g.setColour (pal::lemon); g.drawText (chordText, d.withTrimmedBottom (26.f).translated (0.f, 2.f), Justification::centred);
    g.setFont (look.label (12.5f)); g.setColour (pal::cream); g.drawText (subText, d.removeFromBottom (28.f), Justification::centred);
    g.setColour (pal::lime.withAlpha (0.25f + 0.75f * led)); g.fillEllipse (760.f, 26.f, 11.f, 11.f);

    // etiqueta de preset
    g.setFont (look.label (13.f)); g.setColour (pal::cream);
    g.drawText ("PRESET", Rectangle<float> (800.f, 8.f, 120.f, 18.f), Justification::centredLeft);

    panel (g, { 18.f, 140.f, 360.f, 252.f }, "Acorde", pal::pink);
    panel (g, { 392.f, 140.f, 214.f, 252.f }, "Tono", pal::orange);
    panel (g, { 620.f, 140.f, 442.f, 252.f }, U ("Interpretación"), pal::turq);
    panel (g, { 18.f, 420.f, 588.f, 220.f }, "Sonido", pal::lemon);
    panel (g, { 620.f, 420.f, 150.f, 220.f }, "Bajo", pal::lime);
    panel (g, { 784.f, 420.f, 278.f, 220.f }, "Efectos", pal::purple);
    panel (g, { 18.f, 656.f, 1044.f, 190.f }, "Ritmo", pal::orange);
    g.setFont (look.label (12.5f)); g.setColour (pal::ink.withAlpha (0.75f));
    g.drawFittedText (U ("En AUTO, cada tecla arma el acorde de esta escala."), Rectangle<int> (404, 350, 190, 36), Justification::centredLeft, 2);
    g.drawFittedText (U ("Arrastrá los knobs arriba/abajo · doble clic vuelve al valor inicial · la octava más grave del teclado (Do1 a Sol#1) cambia el tipo de acorde."), Rectangle<int> (34, 596, 560, 36), Justification::centredLeft, 2);
    g.drawFittedText (U ("Toca la raíz\nmás abajo"), Rectangle<int> (632, 592, 130, 38), Justification::centred, 2);
    g.setFont (look.label (12.5f)); g.setColour (pal::ink.withAlpha (0.75f));
    g.setColour (proc.isRecording() ? pal::pink : pal::ink); g.setFont (look.label (12.5f));
    g.drawFittedText (recText, Rectangle<int> (884, 736, 172, 36), Justification::centred, 2);
    g.setColour (pal::ink.withAlpha (0.75f));
    g.drawText ("RITMO DEL ARPEGIO", Rectangle<float> (646.f, 314.f, 180.f, 18.f), Justification::centredLeft);
    g.drawText (U ("PATRÓN"), Rectangle<float> (850.f, 314.f, 180.f, 18.f), Justification::centredLeft);
    g.drawText ("TIEMPO DEL DELAY", Rectangle<float> (938.f, 546.f, 120.f, 18.f), Justification::centredLeft);
}

void Content::pickChord (int index)
{
    if (auto* prm = proc.apvts.getParameter ("chord"))
    {
        prm->beginChangeGesture(); prm->setValueNotifyingHost (prm->convertTo0to1 ((float) index)); prm->endChangeGesture();
    }
    proc.clearKeySwitch = true;
    chord->sync();
}

bool Content::keyPressed (const KeyPress& k)
{
    const auto m = k.getModifiers();
    if (m.isCommandDown() || m.isCtrlDown() || m.isAltDown()) return false; // atajos del sistema o del DAW
    const juce_wchar c = CharacterFunctions::toLowerCase (k.getTextCharacter());
    static const char keys[] = "qweasdzxc";
    for (int i = 0; i < 9; ++i)
        if (c == (juce_wchar) keys[i]) { pickChord (i); return true; }
    if (c == 'r')
    {
        if (auto* prm = proc.apvts.getParameter ("add9"))
        {
            prm->beginChangeGesture(); prm->setValueNotifyingHost (prm->getValue() > 0.5f ? 0.f : 1.f); prm->endChangeGesture();
        }
        return true;
    }
    return false; // las demás teclas siguen de largo (por ejemplo, al DAW)
}

void Content::paintOverChildren (Graphics& g)
{
    // letrita de la tecla en la esquina de cada botón de acorde y del +9
    static const char* keys[] = { "Q", "W", "E", "A", "S", "D", "Z", "X", "C" };
    auto badge = [&] (Rectangle<int> b, const char* t)
    {
        auto r = Rectangle<float> ((float) b.getRight() - 21.f, (float) b.getY() + 1.f, 17.f, 15.f);
        g.setColour (pal::ink); g.fillRoundedRectangle (r, 5.f);
        g.setColour (pal::cream); g.setFont (look.label (11.f)); g.drawText (t, r.translated (0.f, -0.5f), Justification::centred);
    };
    for (int i = 0; i < chord->buttons.size() && i < 9; ++i)
        badge (getLocalArea (chord.get(), chord->buttons[i]->getBounds()), keys[i]);
    badge (add9.getBounds(), "R");
}

void Content::resized()
{
    auto K = [this] (const char* id) -> Knob* { for (auto* k : knobs) if (k->getName() == id) return k; return nullptr; };
    auto put = [&] (const char* id, int x, int y) { if (auto* k = K (id)) k->setBounds (x, y, 70, 84); };

    presetBox.setBounds (800, 26, 262, 32);
    mode->setBounds (800, 64, 262, 40);
    // Acorde
    chord->setBounds (30, 166, 336, 156);
    add9.setBounds (30, 334, 70, 38); hold.setBounds (102, 334, 116, 38); keyswitch.setBounds (220, 334, 150, 38);
    // Tono
    put ("voicing", 400, 166); put ("octave", 466, 166); put ("velsens", 532, 166);
    keyBox.setBounds (404, 266, 92, 32); scaleBox.setBounds (500, 266, 96, 32);
    followOct.setBounds (400, 306, 200, 36);
    // Interpretación
    perf->setBounds (630, 164, 422, 40);
    put ("strum", 630, 210); put ("slop", 700, 210); put ("arpOct", 770, 210); put ("arpGate", 840, 210);
    tempoBox.setBounds (916, 208, 138, 96);
    rateBox.setBounds (636, 334, 196, 32); patternBox.setBounds (840, 334, 210, 32);
    // Sonido
    engine->setBounds (30, 444, 360, 40);
    const char* snd[] = { "bright", "tone2", "character", "movement", "attack", "decay", "sustain", "release" };
    for (int i = 0; i < 8; ++i) put (snd[i], 28 + i * 72, 500);
    // Bajo
    bassOn.setBounds (626, 440, 78, 36); bassOctBox.setBounds (706, 442, 58, 30);
    put ("bassLevel", 628, 500); put ("bassTone", 694, 500);
    // Efectos
    put ("chorus", 790, 444); put ("delayMix", 856, 444); put ("delayFb", 922, 444); put ("reverbMix", 988, 444);
    put ("reverbSize", 790, 534); put ("volume", 856, 534);
    delayBox.setBounds (930, 566, 124, 30);
    // Ritmo
    drumPlay.setBounds (28, 684, 150, 40); drumSync.setBounds (28, 726, 150, 34); drumPatternBox.setBounds (28, 764, 150, 32);
    { auto putS = [&] (const char* id, int x, int y) { if (auto* k = K (id)) k->setBounds (x, y, 62, 74); };
      putS ("drumVol", 186, 676); putS ("swing", 250, 676); putS ("drumComp", 314, 676);
      putS ("drumPhase", 218, 750); putS ("drumTone", 282, 750); }
    grid.setBounds (384, 676, 492, 158);
    recBtn.setBounds (884, 682, 172, 44); folderBtn.setBounds (884, 778, 172, 38);
    keys.setBounds (18, 856, 1044, 46);
}

// ======================= editor =======================
LirioEditor::LirioEditor (LirioProcessor& p) : AudioProcessorEditor (p), content (p)
{
    addAndMakeVisible (content);
    content.setBounds (0, 0, W, H);
    setResizable (true, true);
    setResizeLimits (W * 6 / 10, H * 6 / 10, W * 3 / 2, H * 3 / 2);
    if (auto* c = getConstrainer()) c->setFixedAspectRatio ((double) W / H);
    // si la pantalla es baja (notebook), arranca más chico para que entre entero
    float sc = 1.f;
    if (auto* d = Desktop::getInstance().getDisplays().getPrimaryDisplay())
        sc = jlimit (0.6f, 1.f, (float) (d->userArea.getHeight() - 90) / (float) H);
    setSize (roundToInt (W * sc), roundToInt (H * sc));
}
void LirioEditor::resized()
{
    content.setTransform (AffineTransform::scale ((float) getWidth() / (float) W));
}
