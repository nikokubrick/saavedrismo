#!/bin/bash
# Lirio para Mac: instala los plugins y quita el bloqueo de macOS (la app no está firmada por Apple).
cd "$(dirname "$0")"
echo "Instalando Lirio..."
mkdir -p ~/Library/Audio/Plug-Ins/Components ~/Library/Audio/Plug-Ins/VST3
rm -rf ~/Library/Audio/Plug-Ins/Components/Lirio.component ~/Library/Audio/Plug-Ins/VST3/Lirio.vst3
cp -R Lirio.component ~/Library/Audio/Plug-Ins/Components/
cp -R Lirio.vst3 ~/Library/Audio/Plug-Ins/VST3/
rm -rf /Applications/Lirio.app 2>/dev/null
cp -R Lirio.app /Applications/ 2>/dev/null || { mkdir -p ~/Applications; rm -rf ~/Applications/Lirio.app; cp -R Lirio.app ~/Applications/; }
xattr -cr ~/Library/Audio/Plug-Ins/Components/Lirio.component ~/Library/Audio/Plug-Ins/VST3/Lirio.vst3 /Applications/Lirio.app ~/Applications/Lirio.app 2>/dev/null
killall -9 AudioComponentRegistrar 2>/dev/null
echo ""
echo "Listo. Lirio quedó en Aplicaciones y los plugins (AU y VST3) en tu carpeta de plugins."
echo "Abrí (o reiniciá) Ableton para que lo encuentre. Podés cerrar esta ventana."
