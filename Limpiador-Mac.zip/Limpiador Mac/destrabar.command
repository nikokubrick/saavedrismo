#!/bin/bash
# Limpiador para Mac: instala los plugins (AU y VST3) y les quita el bloqueo de macOS.
cd "$(dirname "$0")"
echo "Instalando Limpiador..."
mkdir -p ~/Library/Audio/Plug-Ins/Components ~/Library/Audio/Plug-Ins/VST3
rm -rf ~/Library/Audio/Plug-Ins/Components/Limpiador.component ~/Library/Audio/Plug-Ins/VST3/Limpiador.vst3
cp -R Limpiador.component ~/Library/Audio/Plug-Ins/Components/
cp -R Limpiador.vst3 ~/Library/Audio/Plug-Ins/VST3/
xattr -cr ~/Library/Audio/Plug-Ins/Components/Limpiador.component ~/Library/Audio/Plug-Ins/VST3/Limpiador.vst3
killall -9 AudioComponentRegistrar 2>/dev/null
echo ""
echo "Listo. Limpiador (AU y VST3) quedó en tu carpeta de plugins."
echo "Abrí (o reiniciá) Ableton para que lo encuentre. Podés cerrar esta ventana."
